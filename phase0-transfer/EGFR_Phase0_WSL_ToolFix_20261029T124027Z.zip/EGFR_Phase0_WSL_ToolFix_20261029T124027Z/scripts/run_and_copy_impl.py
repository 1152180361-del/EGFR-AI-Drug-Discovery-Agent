"""Run an argv without a shell; preserve streams/status and copy combined output."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import selectors
import shutil
import subprocess
import sys
import tempfile
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cwd", type=Path, default=Path.cwd())
    parser.add_argument("--log-root", type=Path,
                        default=Path(__file__).resolve().parents[1] / "command-logs")
    parser.add_argument("--label", default="command")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("Use -- followed by an executable and its arguments.")
    args.log_root.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    label = "".join(c if c.isalnum() or c in "-_" else "_" for c in args.label)[:64]
    folder = Path(tempfile.mkdtemp(prefix=stamp + "_" + label + "_",
                                   dir=args.log_root))
    command = [arg.replace("{LOG_DIR}", str(folder.resolve())) for arg in command]
    record = {
        "argv": command, "cwd": str(args.cwd.resolve()),
        "label": args.label,
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "exit_code": None, "clipboard": {"status": "pending"},
    }
    metadata = folder / "command.json"
    metadata.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    start = time.monotonic()
    stdout_path = folder / "stdout.log"
    stderr_path = folder / "stderr.log"
    combined_path = folder / "combined.log"
    with stdout_path.open("xb") as out, stderr_path.open("xb") as err, \
            combined_path.open("xb") as combined:
        try:
            process = subprocess.Popen(command, cwd=args.cwd, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE,
                                       env={**os.environ, "EGFR_RUN_LOG_DIR": str(folder.resolve())})
        except OSError as exc:
            error = (f"{type(exc).__name__}: {exc}\n").encode()
            err.write(error)
            combined.write(error)
            sys.stderr.buffer.write(error)
            code = 127
        else:
            selector = selectors.DefaultSelector()
            selector.register(process.stdout, selectors.EVENT_READ, (out, sys.stdout.buffer))
            selector.register(process.stderr, selectors.EVENT_READ, (err, sys.stderr.buffer))
            try:
                while selector.get_map():
                    for key, _ in selector.select(timeout=0.25):
                        chunk = os.read(key.fd, 65536)
                        if not chunk:
                            selector.unregister(key.fileobj)
                            key.fileobj.close()
                            continue
                        log, terminal = key.data
                        log.write(chunk)
                        log.flush()
                        combined.write(chunk)
                        combined.flush()
                        terminal.write(chunk)
                        terminal.flush()
                code = process.wait()
            except KeyboardInterrupt:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                code = 130
            finally:
                selector.close()
    if code < 0:
        code = 128 - code
    (folder / "exit-code.txt").write_text(str(code) + "\n")
    clipboard = {"status": "UNAVAILABLE", "reason": "No clip.exe/wl-copy/xclip found"}
    command_for_clipboard = None
    encoding = "utf-8"
    if shutil.which("clip.exe"):
        command_for_clipboard = ["clip.exe"]
        encoding = "utf-16le"
    elif shutil.which("wl-copy"):
        command_for_clipboard = ["wl-copy"]
    elif shutil.which("xclip"):
        command_for_clipboard = ["xclip", "-selection", "clipboard"]
    if command_for_clipboard:
        try:
            result = subprocess.run(
                command_for_clipboard,
                input=combined_path.read_text(errors="replace").encode(encoding),
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10,
            )
            clipboard = {"status": "COPIED" if result.returncode == 0 else "FAILED",
                         "program": command_for_clipboard[0],
                         "exit_code": result.returncode}
        except (OSError, subprocess.TimeoutExpired) as exc:
            clipboard = {"status": "FAILED", "error_type": type(exc).__name__}
    record.update(
        exit_code=code, elapsed_seconds=round(time.monotonic() - start, 3),
        finished_utc=datetime.now(timezone.utc).isoformat(), clipboard=clipboard,
        streams={p.name: {"bytes": p.stat().st_size, "sha256": digest(p)}
                 for p in (stdout_path, stderr_path, combined_path)},
    )
    metadata.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    print(f"\n[run_and_copy] exit={code}; logs={folder}; clipboard={clipboard['status']}",
          file=sys.stderr)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
