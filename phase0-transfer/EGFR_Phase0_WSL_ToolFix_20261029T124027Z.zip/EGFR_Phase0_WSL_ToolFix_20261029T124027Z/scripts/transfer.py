"""Hash-gated, backup-first patch application. Never reset/clean/stage/commit."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

BUNDLE = Path(__file__).resolve().parents[1]


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def verify():
    seen = set()
    for line in (BUNDLE / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts or name in seen:
            raise ValueError("Unsafe/duplicate checksum path")
        path = BUNDLE / relative
        if path.is_symlink() or not path.is_file() or digest(path) != expected:
            raise ValueError("Bundle integrity failure: " + name)
        seen.add(name)
    print("PASS: verified", len(seen), "bundle files against SHA256SUMS")


def manifest():
    return json.loads((BUNDLE / "transfer-manifest.json").read_text())


def destination(root, name):
    relative = Path(name)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError("Unsafe target path")
    if relative.parts[0] not in {"egfr_agent", "scripts", "tests"}:
        raise ValueError("Target outside reviewed code/test scope")
    path = root / relative
    if not path.resolve().is_relative_to(root.resolve()) or path.is_symlink():
        raise ValueError("Target resolves outside project or is a symlink")
    return path


def inspect(root):
    if not (root / ".git").exists():
        raise ValueError("Project is not an existing Git checkout")
    rows = []
    for item in manifest()["files"]:
        path = destination(root, item["path"])
        current = digest(path) if path.is_file() else None
        if path.exists() and not path.is_file():
            status = "CONFLICT_NOT_REGULAR_FILE"
        elif current == item["target_sha256"]:
            status = "ALREADY_APPLIED"
        elif any(base["sha256"] == current for base in item["bases"]):
            status = "READY"
        else:
            status = "CONFLICT"
        rows.append({"path": item["path"], "status": status,
                     "actual_sha256": current, "target_sha256": item["target_sha256"]})
    result = {"project": str(root), "rows": rows,
              "can_apply": all(x["status"] in {"READY", "ALREADY_APPLIED"} for x in rows)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


def git(root, *args, data=None):
    result = subprocess.run(["git", *args], cwd=root, input=data,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        sys.stderr.write(result.stderr.decode(errors="replace"))
        raise RuntimeError("Git command failed: " + " ".join(args))
    return result.stdout


def apply(root, backup_root):
    checked = inspect(root)
    if not checked["can_apply"]:
        raise ValueError("BLOCKED: hash conflicts; no project files changed. Preserve both versions.")
    ready = [row for row in checked["rows"] if row["status"] == "READY"]
    if not ready:
        print("PASS: already applied; no project files written")
        return
    entries = {item["path"]: item for item in manifest()["files"]}
    patch_parts = []
    for row in ready:
        entry = entries[row["path"]]
        base = next(x for x in entry["bases"] if x["sha256"] == row["actual_sha256"])
        patch_parts.append((BUNDLE / base["patch"]).read_bytes())
    patch = b"".join(patch_parts)
    git(root, "apply", "--check", "-", data=patch)
    if backup_root.resolve().is_relative_to(root):
        raise ValueError("Backup root must be OUTSIDE the original project")
    backup_root.mkdir(parents=True, exist_ok=True)
    backup = Path(tempfile.mkdtemp(prefix="EGFR_ToolFix_Backup_", dir=backup_root))
    (backup / "applied.patch").write_bytes(patch)
    (backup / "git-status-before.txt").write_bytes(git(root, "status", "--porcelain=v1"))
    (backup / "unstaged-before.patch").write_bytes(git(root, "diff", "--binary"))
    staged = git(root, "diff", "--cached", "--binary")
    (backup / "staged-before.patch").write_bytes(staged)
    for row in ready:
        path = destination(root, row["path"])
        if path.exists():
            target = backup / "original" / row["path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            with path.open("rb") as source, target.open("xb") as output:
                shutil.copyfileobj(source, output)
    # Recheck after backup, before a single atomic default git apply. No --reject,
    # --3way or --index: no conflict markers, partial application, or index writes.
    for row in ready:
        path = destination(root, row["path"])
        actual = digest(path) if path.is_file() else None
        if actual != row["actual_sha256"]:
            raise RuntimeError("Concurrent local change; stopped before apply: " + row["path"])
    git(root, "apply", "-", data=patch)
    for row in ready:
        if digest(destination(root, row["path"])) != row["target_sha256"]:
            raise RuntimeError("Post-apply hash mismatch; retain backup and inspect manually")
    if git(root, "diff", "--cached", "--binary") != staged:
        raise RuntimeError("Unexpected index change; do not reset; inspect backup")
    receipt = {"status": "APPLIED", "project": str(root), "backup": str(backup),
               "created_utc": datetime.now(timezone.utc).isoformat(), "files": ready,
               "git_index_unchanged": True}
    dump(backup / "receipt.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False, indent=2))
    print("Do not reset/clean. Review backup/applied.patch for an explicit future rollback.")


def prepare(root, target):
    if target.exists():
        raise ValueError("Validation destination already exists; choose a NEW directory")
    if target.resolve().is_relative_to(root):
        raise ValueError("Validation copy must be outside the original project")
    required = manifest()["validation_inputs"]
    source_missing = [name for name in manifest()["validation_required_sources"]
                      if not (root / name).is_file()]
    if source_missing:
        print(json.dumps({"status": "BLOCKED", "missing_sources": source_missing}, indent=2))
        raise ValueError("Original source dependencies missing; no placeholders created")
    missing = []
    conflicts = []
    assets = []
    for item in required:
        path = root / item["path"]
        if not path.is_file() or path.is_symlink():
            missing.append(item["path"])
            continue
        actual = digest(path)
        if actual != item["sha256"] and not item["mutable_latest_report"]:
            conflicts.append({"path": item["path"], "actual_sha256": actual,
                              "expected_sha256": item["sha256"]})
        assets.append({**item, "actual_sha256": actual,
                       "reference_matches": actual == item["sha256"]})
    if missing or conflicts:
        print(json.dumps({"status": "BLOCKED", "missing": missing,
                          "immutable_asset_mismatches": conflicts}, indent=2))
        raise ValueError("Scientific input preflight failed; no validation copy created")
    source_paths = []
    for folder in ("egfr_agent", "scripts", "tests", "examples", "phase0"):
        directory = root / folder
        if directory.is_dir():
            source_paths.extend(p for p in directory.rglob("*.py")
                                if "__pycache__" not in p.parts
                                and "evidence" not in p.relative_to(directory).parts)
    source_paths.extend(root.glob("test_*.py"))
    # These are the only known root demos. Unknown root tests need review rather
    # than accidental research execution during full collection.
    known = manifest()["root_test_sha256"]
    for path in root.glob("test_*.py"):
        if known.get(path.name) != digest(path):
            raise ValueError("BLOCKED: unreviewed root test guard: " + path.name)
    for name in ("pytest.ini", "pyproject.toml", "setup.cfg", "conftest.py"):
        path = root / name
        if path.is_file():
            source_paths.append(path)
    target.mkdir(parents=True)
    for path in source_paths:
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise ValueError("Unsafe source symlink: " + str(path))
        relative = path.relative_to(root)
        dest = target / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)
    for item in assets:
        dest = target / item["path"]
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / item["path"], dest)
        if digest(dest) != item["actual_sha256"]:
            raise RuntimeError("Copy integrity failure")
    dump(target / "WSL_VALIDATION_INPUTS.json", {
        "status": "PREPARED_NOT_TESTED", "source_project": str(root),
        "validation_project": str(target), "assets": assets,
        "models_trained": False, "global_predictions_recomputed": False,
        "original_project_outputs_not_targeted": True,
    })
    print("PASS: independent validation copy prepared:", target)
    print("NOT_VERIFIED: no tests or native Agent have been executed by preparation.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("verify", "inspect", "apply", "prepare"))
    parser.add_argument("--project", type=Path)
    parser.add_argument("--backup-root", type=Path)
    parser.add_argument("--destination", type=Path)
    args = parser.parse_args()
    verify()
    if args.action == "verify":
        return 0
    if args.project is None:
        parser.error("--project is required")
    root = args.project.resolve()
    if args.action == "inspect":
        return 0 if inspect(root)["can_apply"] else 2
    if args.action == "apply":
        if args.backup_root is None:
            parser.error("--backup-root is required")
        apply(root, args.backup_root.resolve())
    else:
        if args.destination is None:
            parser.error("--destination is required")
        state = inspect(root)
        if not state["can_apply"] or any(
                row["status"] != "ALREADY_APPLIED" for row in state["rows"]):
            raise ValueError("Apply the reviewed patch before preparing validation")
        prepare(root, args.destination.resolve())
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, RuntimeError, OSError) as error:
        print(f"BLOCKED/FAIL: {type(error).__name__}: {error}", file=sys.stderr)
        raise SystemExit(2)
