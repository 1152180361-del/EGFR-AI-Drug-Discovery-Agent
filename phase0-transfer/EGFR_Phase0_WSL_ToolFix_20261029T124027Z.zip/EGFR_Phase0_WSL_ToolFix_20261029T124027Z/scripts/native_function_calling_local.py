"""WSL-only real Ollama verification. Never downloads models or uses a fake."""
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path.cwd()))
import requests
from egfr_agent.function_calling import EGFRFunctionCaller
from egfr_agent.llm_client import OllamaClient
from egfr_agent.tool_registry import TOOLS

folder = Path(os.environ["EGFR_RUN_LOG_DIR"])
base = "http://127.0.0.1:11434"
model = "qwen2.5:7b"
preflight = {"endpoint": base, "model": model, "status": "NOT_VERIFIED"}
try:
    version = requests.get(base + "/api/version", timeout=10)
    version.raise_for_status()
    tags = requests.get(base + "/api/tags", timeout=10)
    tags.raise_for_status()
    preflight["version"] = version.json().get("version")
    preflight["model_present"] = any(
        item.get("name") == model for item in tags.json().get("models", [])
    )
    if not preflight["model_present"]:
        raise RuntimeError("Required existing model not found; no pull attempted")
    preflight["status"] = "PASS"
except Exception as exc:
    preflight.update(status="BLOCKED", error_type=type(exc).__name__, error=str(exc))
(folder / "ollama-preflight.json").write_text(json.dumps(preflight, indent=2) + "\n")
if preflight["status"] != "PASS":
    print(json.dumps(preflight, indent=2))
    raise SystemExit(3)

assert "pk_dmpnn_prediction" not in TOOLS, "Production PK shadow isolation violated"
cases = [
    ("Analyze EGFR QSAR activity and docking evidence for existing candidates",
     {"qsar_prediction", "structure_analysis"}),
    ("Do not predict SMILES: CCO and analyze docking poses", {"structure_analysis"}),
    ("不要预测SMILES: CCO，同时分析 docking poses", {"structure_analysis"}),
]
records = []
for index, (query, required) in enumerate(cases, 1):
    caller = EGFRFunctionCaller(TOOLS)
    caller.client = OllamaClient(model=model, base_url=base)
    try:
        result = caller.run(query)
        if set(result["executed_tools"]) != required:
            raise RuntimeError("Executed tools differ from the authorized expected set")
        records.append({"query": query, "status": "PASS_REAL_NATIVE_FUNCTION_CALLING",
                        "executed_tools": result["executed_tools"],
                        "argument_retries": caller.last_audit["argument_retries"]})
    except Exception as exc:
        records.append({"query": query, "status": "FAIL_REAL_NATIVE_FUNCTION_CALLING",
                        "error_type": type(exc).__name__, "error": str(exc)})
    (folder / f"native-audit-{index}.json").write_text(
        json.dumps(caller.last_audit, indent=2, ensure_ascii=False) + "\n")
(folder / "native-results.json").write_text(
    json.dumps(records, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(records, indent=2, ensure_ascii=False))
print("Native calls are separate from full Agent/Trace/report acceptance.")
raise SystemExit(0 if all(row["status"].startswith("PASS_") for row in records) else 1)
