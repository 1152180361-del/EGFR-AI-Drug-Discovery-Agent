"""Summarize actual WSL logs; do not equate an exit-zero with Phase 0 acceptance."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--validation", required=True, type=Path)
args = parser.parse_args()
validation = args.validation.resolve()
bundle = Path(__file__).resolve().parents[1]
output = Path(os.environ["EGFR_RUN_LOG_DIR"])
records = []
case_results = []
archive_sources = []
for log_root in (bundle / "wsl-command-logs", validation / "evidence"):
    if not log_root.exists():
        continue
    for metadata in sorted(log_root.glob("*/command.json")):
        if metadata.parent.resolve() == output.resolve():
            continue
        entry = json.loads(metadata.read_text())
        entry["metadata"] = str(metadata)
        code = entry.get("exit_code")
        if code is None:
            entry["status"] = "NOT_VERIFIED_RUNNING_OR_INTERRUPTED"
        else:
            entry["status"] = "PASS_COMMAND_EXIT_ONLY" if code == 0 else "FAIL"
        if entry.get("label", "").startswith("native"):
            stderr = (metadata.parent / "stderr.log").read_text(errors="replace")
            stdout = (metadata.parent / "stdout.log").read_text(errors="replace")
            if "Ollama connection failed" in stderr + stdout:
                entry["status"] = "BLOCKED_OLLAMA_CONNECTION"
            elif code == 3:
                entry["status"] = "BLOCKED_NATIVE_PREFLIGHT"
            elif code == 0:
                entry["status"] = "PASS_ENTRY_EXIT_ONLY_TRACE_REVIEW_REQUIRED"
        records.append(entry)
        for xml in metadata.parent.glob("*.xml"):
            for testcase in ET.parse(xml).findall(".//testcase"):
                status = next((label for tag, label in (
                    ("failure", "FAIL"), ("error", "ERROR"), ("skipped", "SKIP")
                ) if testcase.find(tag) is not None), "PASS")
                case_results.append({
                    "junit": str(xml), "classname": testcase.get("classname"),
                    "name": testcase.get("name"), "status": status,
                    "evidence_kind": "automated_test_not_native_E2E",
                })
        for path in metadata.parent.iterdir():
            if path.is_file() and path.suffix in {".json", ".log", ".txt", ".xml"}:
                archive_sources.append((path, "logs/" + log_root.name + "/"
                                        + metadata.parent.name + "/" + path.name))
inputs = json.loads((validation / "WSL_VALIDATION_INPUTS.json").read_text())
original = Path(inputs["source_project"])
preservation = []
for asset in inputs["assets"]:
    path = original / asset["path"]
    actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
    isolated_path = validation / asset["path"]
    isolated_hash = (hashlib.sha256(isolated_path.read_bytes()).hexdigest()
                     if isolated_path.is_file() else None)
    preservation.append({
        "path": asset["path"],
        "original_project_unchanged": actual == asset["actual_sha256"],
        "isolated_immutable_input_unchanged": (
            None if asset["mutable_latest_report"]
            else isolated_hash == asset["actual_sha256"]),
    })
native_required = {"native-function-calling", "native-agent", "native-multiobjective"}
native_records = [row for row in records if row.get("label") in native_required]
missing = sorted(native_required - {row.get("label") for row in native_records})
ledger = {
    "status": "NOT_VERIFIED_PHASE0_REQUIRES_EVIDENCE_REVIEW",
    "missing_native_steps": missing,
    "commands": records, "test_case_results": case_results,
    "original_asset_preservation": preservation,
    "native_success_is_not_assumed_from_exit_code": True,
    "scientific_limitations": [
        "CCO OUT_OF_DOMAIN; seed SD is not calibrated confidence.",
        "PK experimental label origin/units not independently verified.",
        "Historical checkpoint byte identity not proven by matching numbers.",
    ],
}
test_labels = {row.get("label") for row in records if row.get("label") in {"targeted", "full"}}
ledger["missing_test_steps"] = sorted({"targeted", "full"} - test_labels)
if ledger["missing_test_steps"]:
    ledger["status"] = "NOT_VERIFIED_MISSING_TEST_RUNS"
if missing or any(row.get("exit_code") != 0 for row in native_records):
    ledger["status"] = "BLOCKED_OR_FAIL_NATIVE_REVIEW_REQUIRED"
if any(row["status"] in {"FAIL", "ERROR"} for row in case_results) or any(
        row.get("exit_code") != 0 for row in records
        if row.get("label") in {"targeted", "full"}):
    ledger["status"] = "FAIL_AUTOMATED_TESTS"
elif any(row["status"] == "SKIP" for row in case_results):
    ledger["status"] = "NOT_VERIFIED_SKIPS_REQUIRE_EXPLANATION"
if any(not row["original_project_unchanged"] for row in preservation):
    ledger["status"] = "FAIL_ORIGINAL_ASSET_PRESERVATION"
if any(row["isolated_immutable_input_unchanged"] is False for row in preservation):
    ledger["status"] = "FAIL_ISOLATED_SCIENTIFIC_INPUT_PRESERVATION"
ledger_path = output / "WSL_ACCEPTANCE_LEDGER.json"
ledger_path.write_text(json.dumps(ledger, indent=2, ensure_ascii=False) + "\n")
archive_sources.append((ledger_path, "WSL_ACCEPTANCE_LEDGER.json"))
archive_sources.append((validation / "WSL_VALIDATION_INPUTS.json",
                        "WSL_VALIDATION_INPUTS.json"))
# Only reports/logs, never model/data/cache/.env. Existing report copies remain
# clearly identified as historical inputs by WSL_VALIDATION_INPUTS.json.
for path in (validation / "reports").rglob("*"):
    if path.is_file() and path.suffix in {".json", ".md"}:
        archive_sources.append((path, "reports/" + str(path.relative_to(validation / "reports"))))
stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
archive = validation / ("EGFR_WSL_Phase0_Results_" + stamp + ".zip")
hashes = {}
with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED) as handle:
    for path, name in archive_sources:
        if name in hashes:
            continue
        content = path.read_bytes()
        hashes[name] = hashlib.sha256(content).hexdigest()
        handle.writestr(name, content)
    handle.writestr("SHA256_MANIFEST.json", json.dumps(hashes, indent=2) + "\n")
(Path(str(archive) + ".sha256")).write_text(
    hashlib.sha256(archive.read_bytes()).hexdigest() + "  " + archive.name + "\n")
print("Actual local evidence summary:", ledger_path)
print("Status:", ledger["status"])
print("Results archive:", archive)
print("Phase 0 is NOT automatically accepted by this collector.")
raise SystemExit(0 if ledger["status"].startswith("NOT_VERIFIED_") else 2)
