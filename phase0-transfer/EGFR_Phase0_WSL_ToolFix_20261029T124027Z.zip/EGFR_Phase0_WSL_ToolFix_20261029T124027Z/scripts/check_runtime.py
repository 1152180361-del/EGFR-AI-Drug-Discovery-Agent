"""Record the chosen WSL Python; never install dependencies."""
from importlib import metadata
import json
import os
from pathlib import Path
import platform
import sys

versions = {}
missing = []
for package in ("scikit-learn", "numpy", "pandas", "scipy", "joblib",
                "rdkit", "requests", "pytest"):
    try:
        versions[package] = metadata.version(package)
    except metadata.PackageNotFoundError:
        missing.append(package)
record = {"python": sys.executable, "python_version": platform.python_version(),
          "packages": versions, "missing": missing,
          "RF_training_sklearn_version": "1.9.1",
          "sklearn_compatible": versions.get("scikit-learn") == "1.9.1",
          "models_or_packages_downloaded": False}
record["status"] = "PASS_RUNTIME_CHECK_ONLY" if not missing and record["sklearn_compatible"] else "BLOCKED"
if os.environ.get("EGFR_RUN_LOG_DIR"):
    (Path(os.environ["EGFR_RUN_LOG_DIR"]) / "runtime.json").write_text(
        json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
raise SystemExit(0 if record["status"].startswith("PASS_") else 2)
