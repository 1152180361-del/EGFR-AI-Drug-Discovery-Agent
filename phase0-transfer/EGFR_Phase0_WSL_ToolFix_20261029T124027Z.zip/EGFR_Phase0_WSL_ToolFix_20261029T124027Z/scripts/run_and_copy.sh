#!/usr/bin/env bash
# Export-bundle helper; does not replace the user's original WSL helper.
set -u
toolfix_runner_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
exec python3 "$toolfix_runner_dir/run_and_copy_impl.py" "$@"
