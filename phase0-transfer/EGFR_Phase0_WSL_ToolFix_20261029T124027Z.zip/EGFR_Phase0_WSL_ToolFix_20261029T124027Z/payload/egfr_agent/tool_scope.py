import re
import unicodedata


class EGFRToolScopeResolver:
    """Deterministic, fail-closed EGFR tool authorization."""

    ALL_TOOLS = (
        "qsar_prediction",
        "qsar_inference",
        "structure_analysis",
        "candidate_evaluation",
        "pk_dmpnn_prediction",
    )

    @staticmethod
    def _matches(text, patterns):
        return any(
            re.search(pattern, text, re.IGNORECASE)
            for pattern in patterns
        )

    @staticmethod
    def _operation_clauses(text, negation):
        """Separate explicit operations without splitting molecular punctuation.

        A bare list following a denial inherits the denial. An explicit new
        command starts its own scope; denial of a capability still wins if the
        same capability is both requested and prohibited elsewhere.
        """
        protected = re.sub(
            r"(\bsmiles\s*[:：]?\s*)([a-z0-9@+\-\[\]()=#\\/%:*.]+)",
            lambda match: match.group(1) + "MOLECULE"
            + ("." if match.group(2).endswith(".") else ""),
            text, flags=re.IGNORECASE,
        )
        action = (
            r"(?:\b(?:analy[sz]e|review|retrieve|read|show|inspect|assess|"
            r"predict|estimate|calculate|infer|run|perform|evaluate|do|need)\b|"
            r"分析|检查|查看|读取|预测|预估|估算|计算|推断|评估|进行|只做|请做)"
        )
        # "no QSAR and docking" is one denied list; "and analyze docking"
        # is an independent affirmative command. Do not split Chinese 和 lists.
        protected = re.sub(
            r"(?:\b(?:and|but|then|also|while|yet)\b|同时|然后|但是|但|并且|以及|并)"
            r"\s*(?=(?:(?:(?:please|only|just)\s+)*|(?:请|只|仅)*)"
            r"(?:" + action + "|" + negation + "))",
            ";", protected, flags=re.IGNORECASE,
        )
        clauses = []
        inherited_denial = False
        for clause in re.split(r"[,;.!?\n，；。！？]+", protected):
            if not clause.strip():
                continue
            has_denial = bool(re.search(negation, clause, re.IGNORECASE))
            postfix_denial = bool(re.search(
                r"\b(?:not\s+(?:needed|required)|excluded)\b", clause,
                re.IGNORECASE,
            ))
            if re.search(action, clause, re.IGNORECASE):
                inherited_denial = False
            if inherited_denial and not has_denial:
                clause = "no " + clause
            clauses.append(clause)
            inherited_denial = inherited_denial or has_denial or postfix_denial
        return clauses

    @staticmethod
    def _result(allowed, no_structure, no_qsar, method):
        return {
            "allowed_tools": list(allowed),
            "prohibited_tools": [
                tool for tool in EGFRToolScopeResolver.ALL_TOOLS
                if tool not in allowed
            ],
            "explicit_structure_exclusion": bool(no_structure),
            "explicit_qsar_exclusion": bool(no_qsar),
            "authorization_method": method,
        }

    def resolve(self, user_request):
        if not isinstance(user_request, str):
            raise TypeError("user_request must be a string.")

        text = unicodedata.normalize("NFKC", user_request).strip().lower()

        if not text:
            raise ValueError("user_request cannot be empty.")

        # Explicitly excluded capabilities.
        negation = (
            r"(?:\bno\b|\bwithout\b|\bdo\s+not\b|\bdon['’]t\b|"
            r"\bdont\b|\bavoid\b|\bskip\b|\bexclude\b|"
            r"\bexcluding\b|\bnot\s+using\b|\bnever\b|"
            r"\bnot(?=\s+(?:predict|estimate|calculate|infer|analy[sz]e|run)\b))"
        )

        cn_negation = (
            r"(?:\u4e0d\u505a|\u4e0d\u8981\u505a|\u65e0\u9700|"
            r"\u4e0d\u9700\u8981|\u4e0d\u8fdb\u884c|\u4e0d\u5305\u542b|"
            r"\u4e0d\u4f7f\u7528|\u4e0d\u7528|\u6392\u9664|"
            r"\u8df3\u8fc7|\u4e0d\u91c7\u7528|\u4e0d\u60f3\u505a|"
            r"\u4e0d\u8981|禁止|(?:不|别)(?=预测|预估|估算|计算|推断|分析|评估|运行))"
        )

        qsar_terms = (
            r"(?:\bqsar\b|\bp\s*ic50\b|\bic50\b|"
            r"\bactivity(?:\s+prediction)?\b|"
            r"\bpotency(?:\s+prediction)?\b|\bzinc\b|"
            r"\u6d3b\u6027(?:\u9884\u6d4b)?|"
            r"\u6548\u529b(?:\u9884\u6d4b)?|"
            r"\u6291\u5236\u6d3b\u6027|"
            r"\b(?:predict|estimate|calculate|infer)\s+smiles\b|"
            r"(?:预测|预估|估算|计算|推断)\s*smiles\b)"
        )

        structure_terms = (
            r"(?:\bstructure(?:\s+analysis|\s+prediction)?\b|"
            r"\bstructural\b|\bhinge\b|\bpocket\b|\bmet793\b|"
            r"\bdocking\b|\bdock(?:ed|ing)?\b|"
            r"\bposes?\b|\bbinding\s+mode\b|"
            r"\u7ed3\u6784\u5206\u6790|\u7ed3\u6784\u9884\u6d4b|"
            r"\u7ed3\u6784|\u5206\u5b50\u5bf9\u63a5|"
            r"\u5bf9\u63a5\u5206\u6790|\u5bf9\u63a5|"
            r"\u7ed3\u5408\u6a21\u5f0f|\u7ed3\u5408\u53e3\u888b|\u94f0\u94fe\u533a)"
        )

        combined_negation = "(?:" + negation + "|" + cn_negation + ")"
        clauses = self._operation_clauses(text, combined_negation)

        def excluded(terms):
            return any(self._matches(clause, [
                combined_negation + r".*?" + terms,
                terms + r".*?\b(?:not\s+(?:needed|required)|excluded)\b",
            ]) for clause in clauses)

        no_qsar = excluded(qsar_terms)
        no_structure = excluded(structure_terms)

        # Complete candidate evaluation is a protected composite tool.
        candidate_patterns = [
            r"\b(?:(?:full|complete|comprehensive|new)\s+)?"
            r"(?:egfr\s+)?candidate\s+evaluation\b",
            r"\bevaluate\s+(?:this|the|a|new)\s+candidate\b",
            r"\bdevelopability\s+evaluation\b",
            r"\bfull\s+(?:egfr\s+)?(?:candidate\s+)?evaluation\b",

            r"(?:\u5019\u9009\u5206\u5b50|\u5019\u9009\u5316\u5408\u7269|"
            r"\u5019\u9009\u836f\u7269|\u5019\u9009\u7269)"
            r".{0,30}(?:\u5b8c\u6574|\u5168\u9762|\u7efc\u5408)?"
            r"(?:\u8bc4\u4f30|\u8bc4\u4ef7)",

            r"(?:\u8bf7)?\u5bf9.{0,20}"
            r"(?:\u5019\u9009\u5206\u5b50|\u5019\u9009\u5316\u5408\u7269|"
            r"\u5019\u9009\u836f\u7269|\u5019\u9009\u7269)"
            r".{0,20}(?:\u8fdb\u884c|\u505a)?"
            r".{0,10}(?:\u5b8c\u6574|\u5168\u9762|\u7efc\u5408)?"
            r"(?:\u8bc4\u4f30|\u8bc4\u4ef7)",

            r"\u6210\u836f\u6027(?:\u8bc4\u4f30|\u8bc4\u4ef7)",
        ]

        candidate_requested = self._matches(text, candidate_patterns) and not any(
            excluded(pattern) for pattern in candidate_patterns
        )

        # Isolated shadow PK D-MPNN inference.
        pk_patterns = [
            r"\bpk[\s_-]*d[\s_-]*mpnn\b",
            r"\bd[\s_-]*mpnn\b",
            r"\bmicrosomal\s+clearance\b",
            r"\bclearance_microsome_az\b",
            r"\bclint(?:_log10)?\b",
            r"\u5fae\u7c92\u4f53\u6e05\u9664\u7387",
            r"\u5fae\u7c92\u4f53\u6e05\u9664",
        ]

        no_pk = any(excluded(pattern) for pattern in pk_patterns)
        pk_requested = self._matches(text, pk_patterns) and not no_pk

        if candidate_requested and pk_requested:
            raise ValueError(
                "Complete candidate evaluation and isolated PK D-MPNN "
                "must be run as separate audited operations."
            )

        if candidate_requested:
            if no_qsar:
                raise ValueError(
                    "candidate_evaluation includes QSAR, but the request "
                    "explicitly excludes QSAR. Evaluation was not authorized."
                )

            return self._result(
                ["candidate_evaluation"],
                no_structure,
                no_qsar,
                "deterministic_candidate_evaluation_scope_guard",
            )

        if pk_requested:
            return self._result(
                ["pk_dmpnn_prediction"],
                no_structure,
                no_qsar,
                "deterministic_pk_dmpnn_shadow_scope_guard",
            )

        # Ordinary QSAR and structure requests.
        qsar_patterns = [
            r"\bqsar\b",
            r"\bp\s*ic50\b",
            r"\bic50\b",
            r"\bactivity\b",
            r"\bpotency\b",
            r"\bzinc\b",
            r"\u6d3b\u6027",
            r"\u6548\u529b",
            r"\u6291\u5236\u6d3b\u6027",
        ]

        inference_patterns = [
            # Generic live-input shorthand; a bare SMILES grants no tool.
            r"\b(?:predict|estimate|calculate|infer)\s+smiles\s*[:：]?",
            r"(?:预测|预估|估算|计算|推断)\s*smiles\s*[:：]?",
            r"\b(?:predict|estimate|calculate|infer)\b"
            r"[^.!?\n]{0,80}"
            r"\b(?:p\s*ic50|ic50|activity|potency|qsar)\b",

            r"\b(?:p\s*ic50|ic50)\b"
            r"[^.!?\n]{0,50}"
            r"\b(?:predict|estimate|calculate|infer)\b",

            r"\bqsar\s+(?:prediction|inference)\b",

            r"\b(?:predict|estimate|calculate)\b"
            r"[^.!?\n]{0,60}\b(?:activity|potency)\b",

            r"(?:\u9884\u6d4b|\u9884\u4f30|\u4f30\u7b97|"
            r"\u8ba1\u7b97|\u63a8\u65ad)"
            r".{0,50}(?:p\s*ic50|ic50|qsar|"
            r"\u6d3b\u6027|\u6548\u529b|\u6291\u5236\u80fd\u529b)",

            r"(?:p\s*ic50|ic50|qsar)"
            r".{0,30}(?:\u9884\u6d4b|\u9884\u4f30|\u4f30\u7b97|\u8ba1\u7b97)",

            r"(?:\u6d3b\u6027|\u6548\u529b)(?:\u9884\u6d4b|\u9884\u4f30)",
        ]

        has_qsar = self._matches(text, qsar_patterns)
        has_inference = self._matches(text, inference_patterns)
        has_structure = self._matches(text, [structure_terms])

        allowed = []

        if has_inference and not no_qsar:
            allowed.append("qsar_inference")
        elif has_qsar and not no_qsar:
            allowed.append("qsar_prediction")

        if has_structure and not no_structure:
            allowed.append("structure_analysis")

        if not allowed:
            raise ValueError(
                "No tool can be safely authorized. Specify QSAR inference, "
                "precomputed QSAR evidence, structure analysis, candidate "
                "evaluation, or PK D-MPNN."
            )

        return self._result(
            allowed,
            no_structure,
            no_qsar,
            "deterministic_request_scope_guard",
        )
