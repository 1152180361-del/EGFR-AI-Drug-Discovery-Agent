"""Scripted model responses test Python guards only; never native E2E evidence."""
import copy,json
from pathlib import Path
import pandas as pd
import pytest
from unittest.mock import patch
from egfr_agent.function_calling import EGFRFunctionCaller
from egfr_agent.run_agent import save_failure_audit

class ScriptedClient:
 model='scripted-unit-test-not-ollama'
 def __init__(self,responses,check=None):self.responses=list(responses);self.requests=[];self.check=check
 def chat(self,messages,tools=None):
  if self.check:self.check(len(self.requests))
  self.requests.append(copy.deepcopy({'messages':messages,'tools':tools}))
  assert self.responses,'Unexpected request after scripted response budget'
  return {'message':self.responses.pop(0)}
class RecordingTool:
 def __init__(self):self.calls=[]
 def run(self):self.calls.append({});return pd.DataFrame([{'zinc_id':'UNIT_FIXTURE','value':1.0}])
 def run_with_args(self,**args):self.calls.append(args);return {'smiles':args['smiles'],'predicted_pIC50':6.0}
def call(name,args=None):return {'function':{'name':name,'arguments':{} if args is None else args}}
def response(*calls):return {'role':'assistant','content':'','tool_calls':list(calls)}
def setup(responses,check=None):
 tools={name:RecordingTool() for name in ('qsar_prediction','structure_analysis','qsar_inference')}
 caller=EGFRFunctionCaller(tools);caller.client=ScriptedClient(responses,check);return caller,tools

def test_no_argument_error_reprompts_without_discarding_fields():
 caller,tools=setup([response(call('qsar_prediction',{'smiles':'CCO','toolchain':'legacy'})),response(call('qsar_prediction')),response()])
 result=caller.run('Retrieve QSAR predictions')
 assert tools['qsar_prediction'].calls==[{}]
 assert result['executed_tools']==['qsar_prediction']
 assert any(x.get('event')=='argument_validation_failed' for x in result['call_log'])
 assert any(x.get('event')=='argument_retry' for x in result['call_log'])
 requests=[x for x in result['call_log'] if x.get('event')=='model_request']
 assert len(requests)==3 and len(requests[0]['request']['messages'])==2
 assert requests[0]['response']['message']['tool_calls'][0]['function']['arguments']=={'smiles':'CCO','toolchain':'legacy'}
 assert caller.last_audit['status']=='completed'
 assert 'accept no arguments' in caller.client.requests[0]['messages'][0]['content']

def test_rejected_batch_executes_nothing_even_with_valid_sibling():
 holder={}
 def check(index):
  if index==1:assert all(not t.calls for t in holder['tools'].values())
 caller,tools=setup([response(call('structure_analysis'),call('qsar_prediction',{'toolchain':'x'})),response(call('structure_analysis'),call('qsar_prediction')),response()],check)
 holder['tools']=tools
 result=caller.run('Analyze QSAR activity and docking poses')
 assert set(result['executed_tools'])=={'qsar_prediction','structure_analysis'}
 assert tools['qsar_prediction'].calls==tools['structure_analysis'].calls==[{}]

@pytest.mark.parametrize('arguments',[{'smiles':'CCO','toolchain':'x'},'{broken json',42])
def test_argument_retry_exhaustion_fails_closed_with_complete_audit(arguments):
 caller,tools=setup([response(call('qsar_prediction',arguments)) for _ in range(3)])
 with pytest.raises(RuntimeError,match='argument.*retry|Argument.*retry') as failure:caller.run('Retrieve QSAR predictions')
 assert all(not x.calls for x in tools.values())
 audit=failure.value.function_calling_audit
 assert audit['status']=='failed' and len(caller.client.requests)==3
 assert sum(x.get('event')=='argument_retry' for x in audit['call_log'])==2
 assert sum(x.get('event')=='argument_validation_failed' for x in audit['call_log'])==3

def test_unauthorized_tool_during_retry_is_immediately_fatal():
 caller,tools=setup([response(call('qsar_prediction',{'smiles':'CCO'})),response(call('structure_analysis'))])
 with pytest.raises(RuntimeError,match='unapproved'):caller.run('Retrieve QSAR predictions')
 assert all(not x.calls for x in tools.values())
 assert len(caller.client.requests)==2

def test_unauthorized_sibling_cannot_hide_behind_argument_error():
 caller,tools=setup([response(call('qsar_prediction',{'smiles':'CCO'}),call('structure_analysis'))])
 with pytest.raises(RuntimeError,match='unapproved'):caller.run('Retrieve QSAR predictions')
 assert all(not x.calls for x in tools.values())
 assert len(caller.client.requests)==1

def test_smiles_in_correction_history_never_becomes_original_user_authority():
 caller,tools=setup([response(call('qsar_inference',{'smiles':'CCN','toolchain':'x'})),response(call('qsar_inference',{'smiles':'CCN'}))])
 with pytest.raises(RuntimeError,match='not found verbatim'):caller.run('Predict SMILES: CCO')
 assert all(not x.calls for x in tools.values())

def test_missing_smiles_can_be_corrected_only_to_original_input():
 caller,tools=setup([response(call('qsar_inference')),response(call('qsar_inference',{'smiles':'CCO'})),response()])
 caller.run('Predict SMILES: CCO')
 assert tools['qsar_inference'].calls==[{'smiles':'CCO'}]

def test_executed_tool_stays_single_execution_across_recovery_rounds():
 caller,tools=setup([response(call('qsar_prediction')),response(call('structure_analysis',{'toolchain':'x'})),response(call('qsar_prediction'),call('structure_analysis'),call('structure_analysis')),response()])
 result=caller.run('Analyze QSAR and docking poses')
 assert tools['qsar_prediction'].calls==tools['structure_analysis'].calls==[{}]
 assert sum(x.get('status')=='duplicate_blocked' for x in result['call_log'])==2
 assert [s['function']['name'] for s in caller.client.requests[1]['tools']]==['structure_analysis']

def test_original_scope_revalidated_on_model_rounds():
 caller,tools=setup([response(call('qsar_prediction',{'smiles':'CCO'})),response(call('qsar_prediction')),response()])
 with patch.object(caller.scope_resolver,'resolve',wraps=caller.scope_resolver.resolve) as resolve:
  caller.run('Retrieve QSAR predictions')
 assert resolve.call_count>=len(caller.client.requests)
 assert all(c.args==('Retrieve QSAR predictions',) for c in resolve.call_args_list)

@pytest.mark.parametrize('query',['Do not predict SMILES: CCO and analyze docking poses','不要预测SMILES: CCO，同时分析 docking poses'])
def test_negated_smiles_never_advertised_or_executed(query):
 caller,tools=setup([response(call('structure_analysis')),response()])
 result=caller.run(query)
 assert result['executed_tools']==['structure_analysis']
 assert not tools['qsar_prediction'].calls and not tools['qsar_inference'].calls
 assert [s['function']['name'] for s in caller.client.requests[0]['tools']]==['structure_analysis']

def test_failure_audit_persists_retries_without_success_report(tmp_path,monkeypatch):
 monkeypatch.chdir(tmp_path)
 caller,tools=setup([response(call('qsar_prediction',{'toolchain':'x'})) for _ in range(3)])
 with pytest.raises(RuntimeError) as error:caller.run('Retrieve QSAR predictions')
 path=save_failure_audit('Retrieve QSAR predictions',error.value,'agent_execution')
 record=json.loads(path.read_text())
 assert record['function_calling_audit']['status']=='failed'
 assert len([x for x in record['function_calling_audit']['call_log'] if x.get('event')=='model_request'])==3
 assert not record['trusted_decision_generated']
 assert not Path('reports/EGFR_AI_Agent_Report.md').exists()

def test_schema_retry_budget_is_global_across_tools():
 caller,tools=setup([response(call('qsar_prediction',{'toolchain':'x'})),response(call('structure_analysis',{'smiles':'CCO'})),response(call('qsar_prediction',{'toolchain':'x'}))])
 with pytest.raises(RuntimeError,match='retry limit'):caller.run('Analyze QSAR and docking poses')
 assert all(not x.calls for x in tools.values())
 assert caller.last_audit['argument_retries']==2

def test_success_trace_retains_model_rounds_rejection_and_final_status(tmp_path,monkeypatch):
 from egfr_agent.agent import EGFRAgent
 monkeypatch.chdir(tmp_path)
 caller,tools=setup([response(call('qsar_prediction',{'toolchain':'x'})),response(call('qsar_prediction')),response()])
 result=caller.run('Retrieve QSAR predictions')
 path=EGFRAgent._save_trace('Retrieve QSAR predictions',result)
 trace=json.loads(path.read_text())
 assert sum(x.get('event')=='model_request' for x in trace['call_log'])==3
 assert sum(x.get('event')=='argument_retry' for x in trace['call_log'])==1
 assert trace['call_log'][-1]['status']=='completed'
 assert trace['call_log'][-1]['event']=='function_calling_finished'

def test_rejected_tool_result_records_actual_attempt_and_original_error():
 caller,tools=setup([response(call('qsar_inference',{'smiles':'CCO'}))])
 with patch.object(tools['qsar_inference'],'run_with_args',return_value={'smiles':'CCN','predicted_pIC50':6.0}):
  with pytest.raises(RuntimeError,match='different SMILES identity') as failure:caller.run('Predict SMILES: CCO')
 audit=failure.value.function_calling_audit
 assert audit['attempted_tools']==['qsar_inference']
 assert audit['executed_tools']==[]
 assert any(x.get('event')=='tool_execution_started' and x['status']=='failed' for x in audit['call_log'])

def test_llm_connection_failure_preserves_round_request_and_failed_status():
 caller,tools=setup([])
 with patch.object(caller.client,'chat',side_effect=ConnectionError('unit-test connection failure')):
  with pytest.raises(ConnectionError) as failure:caller.run('Retrieve QSAR predictions')
 audit=failure.value.function_calling_audit
 assert audit['status']=='failed' and not audit['attempted_tools']
 requests=[x for x in audit['call_log'] if x.get('event')=='model_request']
 assert len(requests)==1 and requests[0]['status']=='failed'

@pytest.mark.parametrize('name',['qsar_inference','candidate_evaluation','pk_dmpnn_prediction'])
def test_smiles_tool_parameter_contract_is_not_loosened(name):
 with pytest.raises(RuntimeError,match='Unexpected tool arguments'):
  EGFRFunctionCaller._validate_arguments(name,{'smiles':'CCO','toolchain':'x'},'SMILES: CCO')
 with pytest.raises(RuntimeError,match='not found verbatim'):
  EGFRFunctionCaller._validate_arguments(name,{'smiles':'CC'},'SMILES: CCO.CCN')
 assert EGFRFunctionCaller._validate_arguments(name,{'smiles':'CCO.CCN'},'SMILES: CCO.CCN')=={'smiles':'CCO.CCN'}
