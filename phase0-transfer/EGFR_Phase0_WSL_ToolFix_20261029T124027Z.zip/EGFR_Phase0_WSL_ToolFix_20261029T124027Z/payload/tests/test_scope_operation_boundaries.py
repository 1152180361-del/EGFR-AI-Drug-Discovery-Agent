"""Deterministic authorization regression; no LLM/model execution."""
import pytest
from egfr_agent.tool_scope import EGFRToolScopeResolver

@pytest.mark.parametrize('query,allowed', [
 ('Do not predict SMILES: CCO and analyze docking poses', ['structure_analysis']),
 ('不要预测SMILES: CCO，同时分析 docking poses', ['structure_analysis']),
 ('Do not analyze docking and predict SMILES: CCO', ['qsar_inference']),
 ('不要分析对接，同时预测SMILES: CCO', ['qsar_inference']),
 ('No QSAR and analyze docking poses', ['structure_analysis']),
 ('QSAR is not required and analyze docking poses', ['structure_analysis']),
 ('不要预测活性；请分析结构', ['structure_analysis']),
 ('Analyze docking poses and do not predict SMILES: CCO', ['structure_analysis']),
 ('Do not predict SMILES: [Na+].[Cl-] but analyze docking poses', ['structure_analysis']),
 ('Do not predict SMILES: F/C=C/F and analyze docking poses', ['structure_analysis']),
 ('Do not predict SMILES: N[C@@H](C)O and analyze docking poses', ['structure_analysis']),
 ('Do not predict SMILES: c1:c:c:c:c:c:1 and analyze docking poses', ['structure_analysis']),
 ('Do not run candidate evaluation; analyze docking poses', ['structure_analysis']),
 ('不要进行候选分子完整评估，同时分析对接', ['structure_analysis']),
 ('Do not run PK D-MPNN; analyze docking poses', ['structure_analysis']),
])
def test_independent_affirmative_operation_survives_negation(query,allowed):
 result=EGFRToolScopeResolver().resolve(query)
 assert result['allowed_tools']==allowed
 assert all(t in result['prohibited_tools'] for t in EGFRToolScopeResolver.ALL_TOOLS if t not in allowed)

@pytest.mark.parametrize('separator',[', ','，','; ','；','. ','。','\n',' and ',' but ',' then '])
def test_negated_live_smiles_followed_by_explicit_analysis(separator):
 result=EGFRToolScopeResolver().resolve('Do not predict SMILES: CCO'+separator+'analyze docking poses')
 assert result['allowed_tools']==['structure_analysis']
 assert result['explicit_qsar_exclusion']
 assert not result['explicit_structure_exclusion']

@pytest.mark.parametrize('query',[
 'Do not predict SMILES: CCO', '不要预测SMILES: CCO',
 'Do not predict QSAR and docking poses', 'No QSAR, docking poses',
 '不要预测活性和分析对接', 'No QSAR and no docking poses',
 'Do not predict SMILES: CCO and docking poses',
 'SMILES: CCO.CCN', 'SMILES: c1ccccc1',
 'Do not predict SMILES: CCO; predict activity for SMILES: CCN',
])
def test_negative_or_ambiguous_requests_fail_closed(query):
 with pytest.raises(ValueError):EGFRToolScopeResolver().resolve(query)

def test_long_negative_phrase_is_not_a_window_based_permission_bypass():
 query='Do not '+('carefully '*15)+'predict SMILES: CCO and analyze docking poses'
 assert EGFRToolScopeResolver().resolve(query)['allowed_tools']==['structure_analysis']

@pytest.mark.parametrize('query',[
 'Don’t predict SMILES: CCO and analyze docking poses',
 'Never predict SMILES: CCO and analyze docking poses',
 '不预测SMILES: CCO，同时分析 docking poses',
 '禁止预测SMILES: CCO，同时分析 docking poses',
 'Do not predict SMILES: CCO and only analyze docking poses',
 '不要预测SMILES: CCO，并只分析 docking poses',
])
def test_explicit_command_modifiers_keep_negative_boundary(query):
 assert EGFRToolScopeResolver().resolve(query)['allowed_tools']==['structure_analysis']

@pytest.mark.parametrize('query,allowed',[
 ('Do not read ZINC; analyze docking poses',['structure_analysis']),
 ('Do not inspect pocket; retrieve QSAR evidence',['qsar_prediction']),
 ('Do not review poses; retrieve QSAR evidence',['qsar_prediction']),
 ('Do not analyze hinge; retrieve QSAR evidence',['qsar_prediction']),
 ('Analyze poses',['structure_analysis']),
])
def test_positive_and_negative_capability_terms_do_not_drift(query,allowed):
 assert EGFRToolScopeResolver().resolve(query)['allowed_tools']==allowed
