"""Offline EGFR Function Calling integration tests; no Ollama or model files."""
import unittest
from unittest.mock import patch

import pandas as pd

from egfr_agent.function_calling import EGFRFunctionCaller


class FakeTableTool:
    def __init__(self, name):
        self.name = name
        self.calls = 0

    def run(self):
        self.calls += 1
        return pd.DataFrame([{"tool": self.name, "value": 1.0}])


class FakeInferenceTool:
    def __init__(self):
        self.calls = []

    def run(self, smiles):
        self.calls.append(smiles)
        if smiles == "INVALID_SMILES":
            raise ValueError("Invalid SMILES")
        return {"smiles": smiles, "predicted_pIC50": float(sum(ord(c) for c in smiles)) / 1000.0}


class FakeWrapper:
    def __init__(self, tool):
        self.tool = tool

    def run(self):
        return self.tool.run()

    def run_with_args(self, **kwargs):
        return self.tool.run(**kwargs)


class FakeLLM:
    model = "offline_stub"

    def __init__(self, messages):
        self.responses = list(messages)
        self.tool_messages = []

    def chat(self, messages, tools=None):
        self.tool_messages.append(tools)
        if not self.responses:
            raise AssertionError("Fake LLM response sequence exhausted")
        return {"message": self.responses.pop(0)}


def msg(calls=None, content=""):
    return {"role": "assistant", "content": content, "tool_calls": calls or []}


def call(name, arguments=None):
    return {
        "function": {
            "name": name,
            "arguments": {} if arguments is None else arguments,
        }
    }


class TestAgentFlowV2(unittest.TestCase):
    def make_caller(self, messages):
        snapshot = FakeTableTool("qsar_prediction")
        structure = FakeTableTool("structure_analysis")
        inference = FakeInferenceTool()
        registry = {
            "qsar_prediction": FakeWrapper(snapshot),
            "structure_analysis": FakeWrapper(structure),
            "qsar_inference": FakeWrapper(inference),
        }
        caller = EGFRFunctionCaller(registry)
        caller.client = FakeLLM(messages)
        return caller, snapshot, structure, inference

    def test_new_smiles_passed_through_to_predictor(self):
        caller, snapshot, structure, inference = self.make_caller([
            msg([call("qsar_inference", {"smiles": "CCO"})]),
            msg(content="Prediction completed"),
        ])
        result = caller.run("Predict EGFR pIC50 for SMILES: CCO")
        self.assertEqual(result["executed_tools"], ["qsar_inference"])
        self.assertEqual(inference.calls, ["CCO"])
        self.assertEqual(result["results"]["qsar_inference"]["smiles"], "CCO")
        self.assertEqual(snapshot.calls, 0)
        self.assertEqual(structure.calls, 0)
        execution = next(event for event in result["call_log"]
                         if event.get("tool") == "qsar_inference"
                         and event.get("status") == "executed")
        self.assertEqual(execution["arguments"]["smiles"], "CCO")

    def test_second_smiles_changes_tool_input(self):
        caller, _, _, inference = self.make_caller([
            msg([call("qsar_inference", '{"smiles":"CCN"}')]),
            msg(content="Done"),
        ])
        result = caller.run("Predict EGFR pIC50 for SMILES: CCN")
        self.assertEqual(inference.calls, ["CCN"])
        self.assertEqual(result["results"]["qsar_inference"]["smiles"], "CCN")

    def test_invalid_smiles_propagates_failure(self):
        caller, _, _, inference = self.make_caller([
            msg([call("qsar_inference", {"smiles": "INVALID_SMILES"})]),
        ])
        with self.assertRaisesRegex(ValueError, "Invalid SMILES"):
            caller.run("Predict SMILES: INVALID_SMILES")
        self.assertEqual(inference.calls, ["INVALID_SMILES"])

    def test_llm_cannot_substitute_molecule(self):
        caller, snapshot, structure, inference = self.make_caller([
            msg([call("qsar_inference", {"smiles": "CCN"})]),
        ])
        with self.assertRaisesRegex(RuntimeError, "not found verbatim"):
            caller.run("Predict SMILES: CCO")
        self.assertEqual(inference.calls, [])
        self.assertEqual(snapshot.calls, 0)
        self.assertEqual(structure.calls, 0)

    def test_argument_injection_rejected_before_execution(self):
        caller, snapshot, _, inference = self.make_caller([
            msg([
                call("qsar_inference", {"smiles": "CCO"}),
                call("qsar_inference", {"smiles": "CCO", "shell": "whoami"}),
            ]),
        ] * (EGFRFunctionCaller.MAX_ARGUMENT_RETRIES + 1))
        with self.assertRaisesRegex(RuntimeError, "Unexpected tool arguments"):
            caller.run("Predict SMILES: CCO")
        self.assertEqual(inference.calls, [])
        self.assertEqual(snapshot.calls, 0)
        self.assertEqual(caller.last_audit["argument_retries"], 2)
        self.assertEqual(caller.last_audit["status"], "failed")

    def test_precomputed_qsar_and_structure_remain_independent(self):
        caller, snapshot, structure, inference = self.make_caller([
            msg([call("qsar_prediction"), call("structure_analysis")]),
            msg(content="Compared precomputed sources"),
        ])
        result = caller.run("Analyze EGFR QSAR activity and docking poses")
        self.assertEqual(set(result["executed_tools"]), {
            "qsar_prediction", "structure_analysis",
        })
        self.assertEqual(snapshot.calls, 1)
        self.assertEqual(structure.calls, 1)
        self.assertEqual(inference.calls, [])

    def test_dont_merge_new_smiles_with_precomputed_docking(self):
        caller, snapshot, structure, inference = self.make_caller([])
        with self.assertRaisesRegex(ValueError, "Cannot combine live SMILES"):
            caller.run("Predict SMILES: CCO and analyze docking poses")
        self.assertEqual(snapshot.calls, 0)
        self.assertEqual(structure.calls, 0)
        self.assertEqual(inference.calls, [])

    def test_wrong_tool_arguments_rejected(self):
        caller, snapshot, _, _ = self.make_caller([
            msg([call("qsar_prediction", {"smiles": "CCO"})]),
        ] * (EGFRFunctionCaller.MAX_ARGUMENT_RETRIES + 1))
        with self.assertRaisesRegex(RuntimeError, "Unexpected tool arguments"):
            caller.run("Retrieve EGFR QSAR predictions")
        self.assertEqual(snapshot.calls, 0)
        self.assertEqual(caller.last_audit["argument_retries"], 2)

    def test_duplicate_tool_runs_once(self):
        caller, snapshot, _, _ = self.make_caller([
            msg([call("qsar_prediction"), call("qsar_prediction")]),
            msg(content="Done"),
        ])
        result = caller.run("Retrieve EGFR QSAR predictions")
        self.assertEqual(snapshot.calls, 1)
        self.assertTrue(any(
            event.get("status") == "duplicate_blocked"
            for event in result["call_log"]
        ))

    def test_disallowed_tool_rejected_before_execution(self):
        caller, snapshot, structure, _ = self.make_caller([
            msg([call("delete_project_files")]),
        ])
        with self.assertRaisesRegex(RuntimeError, "Rejected unapproved LLM tool"):
            caller.run("Retrieve EGFR docking poses")
        self.assertEqual(snapshot.calls, 0)
        self.assertEqual(structure.calls, 0)

    def test_qsar_result_identity_must_match_input(self):
        caller, _, _, inference = self.make_caller([
            msg([call("qsar_inference", {"smiles": "CCO"})]),
        ])
        with patch.object(inference, "run", return_value={"smiles": "CCN", "predicted_pIC50": 6.0}):
            with self.assertRaisesRegex(RuntimeError, "different SMILES identity"):
                caller.run("Predict SMILES: CCO")

    def test_qsar_result_must_be_finite_numeric(self):
        for value in (float("nan"), float("inf"), True, "6.0"):
            with self.subTest(value=value):
                caller, _, _, inference = self.make_caller([
                    msg([call("qsar_inference", {"smiles": "CCO"})]),
                ])
                with patch.object(inference, "run", return_value={"smiles": "CCO", "predicted_pIC50": value}):
                    with self.assertRaisesRegex(RuntimeError, "invalid predicted_pIC50"):
                        caller.run("Predict SMILES: CCO")

    def test_partial_molecule_cannot_pass_verbatim_guard(self):
        for request, substituted in [
            ("Predict SMILES: CCO", "CC"),
            ("Predict SMILES: CCO.CCN", "CCO"),
        ]:
            with self.subTest(request=request):
                caller, _, _, inference = self.make_caller([
                    msg([call("qsar_inference", {"smiles": substituted})]),
                ])
                with self.assertRaisesRegex(RuntimeError, "not found verbatim"):
                    caller.run(request)
                self.assertEqual(inference.calls, [])


if __name__ == "__main__":
    unittest.main()
