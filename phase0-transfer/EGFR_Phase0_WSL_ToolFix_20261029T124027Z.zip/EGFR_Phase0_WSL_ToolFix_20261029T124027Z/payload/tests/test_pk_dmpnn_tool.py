import csv
import math
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import egfr_agent.tools.pk_dmpnn_tool as module


class PKDMPNNToolTests(unittest.TestCase):

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

        self.relative_paths = dict(
            module.CHECKPOINT_RELATIVE_PATHS
        )

        for relative_path in self.relative_paths.values():
            checkpoint = self.root / relative_path
            checkpoint.parent.mkdir(parents=True, exist_ok=True)
            checkpoint.write_text("mock checkpoint", encoding="utf-8")

        self.chemprop = self.root / "bin" / "chemprop"
        self.chemprop.parent.mkdir(parents=True, exist_ok=True)
        self.chemprop.write_text("#!/bin/sh\n", encoding="utf-8")
        self.chemprop.chmod(0o755)

        self.values = {
            42: -1.0,
            43: 0.0,
            44: 1.0,
            45: 2.0,
            46: 3.0,
        }

        self.mismatch_seed = None

    def tearDown(self):
        self.temp.cleanup()

    def fake_run(self, command, **kwargs):
        input_path = Path(
            command[command.index("--test-path") + 1]
        )
        output_path = Path(
            command[command.index("--preds-path") + 1]
        )
        checkpoint = Path(
            command[command.index("--model-paths") + 1]
        ).resolve()

        seed = next(
            seed
            for seed, relative_path in self.relative_paths.items()
            if (self.root / relative_path).resolve() == checkpoint
        )

        with input_path.open(
            "r",
            encoding="utf-8",
            newline="",
        ) as handle:
            input_smiles = next(csv.DictReader(handle))["smiles"]

        output_smiles = input_smiles

        if seed == self.mismatch_seed:
            output_smiles = input_smiles + "C"

        output_path.parent.mkdir(parents=True, exist_ok=True)

        with output_path.open(
            "w",
            encoding="utf-8",
            newline="",
        ) as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=["smiles", "clint_log10"],
            )
            writer.writeheader()
            writer.writerow({
                "smiles": output_smiles,
                "clint_log10": self.values[seed],
            })

        return SimpleNamespace(
            returncode=0,
            stdout="mock inference succeeded",
            stderr="",
        )

    def run_with_patches(self, smiles="CCO"):
        with (
            patch.object(module, "ROOT", self.root),
            patch.object(module, "CHEMPROP_BIN", self.chemprop),
            patch.object(
                module,
                "CHECKPOINT_RELATIVE_PATHS",
                self.relative_paths,
            ),
            patch.object(
                module.subprocess,
                "run",
                side_effect=self.fake_run,
            ) as mocked_run,
        ):
            result = module.PKDMPNNTool().run(smiles)

        return result, mocked_run

    def test_five_seed_ensemble_averages_in_log10_space(self):
        result, mocked_run = self.run_with_patches()

        self.assertEqual(result["status"], "OK")
        self.assertEqual(result["n_models"], 5)
        self.assertEqual(mocked_run.call_count, 5)
        self.assertEqual(result["seed_predictions_log10"], {str(k): v for k, v in self.values.items()})
        # Sample SD uses n-1: sum of squared deviations is 10, n-1 is 4.
        self.assertAlmostEqual(result["sample_sd_log10"], math.sqrt(2.5))

        # Mean(-1, 0, 1, 2, 3) = 1; 10**1 = 10.
        self.assertAlmostEqual(
            result["mean_log10_prediction"],
            1.0,
        )
        self.assertAlmostEqual(
            result["predicted_clearance_mL_min_g"],
            10.0,
        )

    def test_invalid_smiles_does_not_launch_model(self):
        with patch.object(module.subprocess, "run") as mocked_run:
            result = module.PKDMPNNTool().run("INVALID_SMILES")

        self.assertEqual(result["status"], "ERROR")
        self.assertEqual(result["stage"], "input_validation")
        mocked_run.assert_not_called()

    def test_missing_checkpoint_fails_closed(self):
        missing_root = self.root / "missing_root"

        with (
            patch.object(module, "ROOT", missing_root),
            patch.object(module, "CHEMPROP_BIN", self.chemprop),
            patch.object(
                module,
                "CHECKPOINT_RELATIVE_PATHS",
                self.relative_paths,
            ),
            patch.object(module.subprocess, "run") as mocked_run,
        ):
            result = module.PKDMPNNTool().run("CCO")

        self.assertEqual(result["status"], "ERROR")
        self.assertEqual(result["stage"], "checkpoint_validation")
        mocked_run.assert_not_called()

    def test_smiles_mismatch_fails_closed(self):
        self.mismatch_seed = 42
        result, _ = self.run_with_patches()

        self.assertEqual(result["status"], "ERROR")
        self.assertEqual(result["stage"], "prediction_validation")
        self.assertEqual(result["failed_seed"], 42)

    def test_nonfinite_prediction_fails_closed(self):
        self.values[44] = float("nan")
        result, _ = self.run_with_patches()

        self.assertEqual(result["status"], "ERROR")
        self.assertEqual(result["stage"], "prediction_validation")
        self.assertEqual(result["failed_seed"], 44)

    def test_inverse_transform_overflow_returns_error(self):
        self.values = {seed: 400.0 for seed in self.values}
        result, _ = self.run_with_patches()
        self.assertEqual(result["status"], "ERROR")
        self.assertEqual(result["stage"], "aggregation")
        self.assertNotIn("predicted_clearance_mL_min_g", result)

    def test_partial_ensemble_cannot_return_ok(self):
        self.mismatch_seed = 44
        result, _ = self.run_with_patches()
        self.assertEqual(result["status"], "ERROR")
        self.assertEqual(result["failed_seed"], 44)
        self.assertEqual(set(result["partial_seed_predictions_log10"]), {"42", "43"})
        self.assertNotIn("mean_log10_prediction", result)


if __name__ == "__main__":
    unittest.main()
