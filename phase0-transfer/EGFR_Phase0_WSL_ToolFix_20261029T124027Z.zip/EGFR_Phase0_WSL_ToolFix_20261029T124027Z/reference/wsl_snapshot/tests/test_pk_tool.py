import unittest
from unittest.mock import patch

from egfr_agent.tools.pk_tool import PKTool


class TestPKTool(unittest.TestCase):

    def run_with_descriptors(
        self,
        mw=300.0,
        logp=2.0,
        tpsa=80.0,
        rotatable=5,
        rings=2,
        smiles="CCO",
    ):
        """Test scoring deterministically with controlled descriptors."""
        with (
            patch(
                "egfr_agent.tools.pk_tool.Descriptors.MolWt",
                return_value=mw,
            ),
            patch(
                "egfr_agent.tools.pk_tool.Crippen.MolLogP",
                return_value=logp,
            ),
            patch(
                "egfr_agent.tools.pk_tool.rdMolDescriptors.CalcTPSA",
                return_value=tpsa,
            ),
            patch(
                "egfr_agent.tools.pk_tool.rdMolDescriptors.CalcNumRotatableBonds",
                return_value=rotatable,
            ),
            patch(
                "egfr_agent.tools.pk_tool.rdMolDescriptors.CalcNumRings",
                return_value=rings,
            ),
        ):
            return PKTool().run(smiles)

    def test_no_risk_flags(self):
        result = self.run_with_descriptors()

        self.assertEqual(result["pk_risk_score"], 0)
        self.assertEqual(
            result["pk_risk_category"],
            "LOW_PK_RISK",
        )
        self.assertEqual(result["risk_factors"], [])

    def test_low_logp_adds_one_point(self):
        result = self.run_with_descriptors(logp=-0.1)

        self.assertEqual(result["pk_risk_score"], 1)
        self.assertEqual(
            result["pk_risk_category"],
            "LOW_PK_RISK",
        )

    def test_high_molecular_weight_adds_two_points(self):
        result = self.run_with_descriptors(mw=500.1)

        self.assertEqual(result["pk_risk_score"], 2)
        self.assertEqual(
            result["pk_risk_category"],
            "MODERATE_PK_RISK",
        )

    def test_high_logp_adds_two_points(self):
        result = self.run_with_descriptors(logp=5.1)

        self.assertEqual(result["pk_risk_score"], 2)
        self.assertEqual(
            result["pk_risk_category"],
            "MODERATE_PK_RISK",
        )

    def test_high_tpsa_adds_two_points(self):
        result = self.run_with_descriptors(tpsa=140.1)

        self.assertEqual(result["pk_risk_score"], 2)
        self.assertEqual(
            result["pk_risk_category"],
            "MODERATE_PK_RISK",
        )

    def test_low_tpsa_adds_one_point(self):
        result = self.run_with_descriptors(tpsa=19.9)

        self.assertEqual(result["pk_risk_score"], 1)
        self.assertEqual(
            result["pk_risk_category"],
            "LOW_PK_RISK",
        )

    def test_high_rotatable_bonds_adds_one_point(self):
        result = self.run_with_descriptors(rotatable=11)

        self.assertEqual(result["pk_risk_score"], 1)

    def test_high_ring_count_adds_one_point(self):
        result = self.run_with_descriptors(rings=6)

        self.assertEqual(result["pk_risk_score"], 1)

    def test_score_three_is_moderate(self):
        result = self.run_with_descriptors(
            mw=501.0,
            logp=-0.1,
        )

        self.assertEqual(result["pk_risk_score"], 3)
        self.assertEqual(
            result["pk_risk_category"],
            "MODERATE_PK_RISK",
        )

    def test_score_four_is_high(self):
        result = self.run_with_descriptors(
            mw=501.0,
            logp=5.1,
        )

        self.assertEqual(result["pk_risk_score"], 4)
        self.assertEqual(
            result["pk_risk_category"],
            "HIGH_PK_RISK",
        )

    def test_threshold_boundaries_are_strict(self):
        result = self.run_with_descriptors(
            mw=500.0,
            logp=0.0,
            tpsa=20.0,
            rotatable=10,
            rings=5,
        )

        self.assertEqual(result["pk_risk_score"], 0)

        upper_tpsa = self.run_with_descriptors(tpsa=140.0)
        self.assertEqual(upper_tpsa["pk_risk_score"], 0)

    def test_invalid_smiles_raises_value_error(self):
        with patch(
            "egfr_agent.tools.pk_tool.Chem.MolFromSmiles",
            return_value=None,
        ):
            with self.assertRaisesRegex(
                ValueError,
                "Invalid SMILES",
            ):
                PKTool().run("INVALID_SMILES")

    def test_output_contains_scientific_limitations(self):
        result = self.run_with_descriptors()

        self.assertEqual(result["tool"], "pk_prediction")
        self.assertIn("properties", result)
        self.assertIn("No experimental ADME/PK validation.",
                      result["limitations"])
        self.assertIn(
            "Not a substitute for animal or clinical "
            "pharmacokinetic studies.",
            result["limitations"],
        )


if __name__ == "__main__":
    unittest.main()
