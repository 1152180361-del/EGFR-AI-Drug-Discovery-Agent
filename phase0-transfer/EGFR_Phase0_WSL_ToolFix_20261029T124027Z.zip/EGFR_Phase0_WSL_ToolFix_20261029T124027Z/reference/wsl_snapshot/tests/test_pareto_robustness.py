"""Offline tests for the independent Pareto robustness extension."""
import unittest

import numpy as np
import pandas as pd

from scripts.audit_pareto_robustness import (
    SCENARIOS,
    compare_saved,
    pareto_independent,
    sensitivity_audit,
    validate_profiles,
)


class TestIndependentParetoRobustness(unittest.TestCase):
    def setUp(self):
        self.frame = pd.DataFrame([
            ("A", "ZINC0001", "CCO", 13, 1, 5.5),
            ("B", "ZINC0002", "CCN", 10, 0, 8.0),
            ("C", "ZINC0003", "CCC", 6, 0, 6.0),
            ("D", "ZINC0004", "CCCl", 6, 0, 6.0),
            ("E", "ZINC0005", "COC", 9, 0, 9.0),
        ], columns=[
            "candidate_id", "zinc_id", "smiles", "baseline_score",
            "pk_risk_score", "complexity_score",
        ])

    def test_expected_full_pareto_with_equal_vectors(self):
        result = pareto_independent(self.frame, SCENARIOS["full"])
        front = set(result.loc[result.pareto_front, "candidate_id"])
        self.assertEqual(front, {"A", "B", "C", "D"})
        self.assertEqual(result.loc[4, "dominated_by_count"], 1)
        self.assertEqual(result.loc[2, "dominated_by_count"], 0)
        self.assertEqual(result.loc[3, "dominated_by_count"], 0)

    def test_no_pk_dominant_high_baseline_low_complexity(self):
        result = pareto_independent(self.frame, SCENARIOS["without_pk"])
        front = result.loc[result.pareto_front, "candidate_id"].tolist()
        self.assertEqual(front, ["A"])

    def test_no_complexity(self):
        result = pareto_independent(self.frame, SCENARIOS["without_complexity"])
        front = set(result.loc[result.pareto_front, "candidate_id"])
        self.assertEqual(front, {"A", "B"})

    def test_no_baseline(self):
        result = pareto_independent(self.frame, SCENARIOS["without_baseline"])
        front = set(result.loc[result.pareto_front, "candidate_id"])
        self.assertEqual(front, {"A", "C", "D"})

    def test_monotonic_baseline_transformation(self):
        original = pareto_independent(self.frame, SCENARIOS["full"])
        changed = self.frame.copy()
        changed["baseline_score"] = changed["baseline_score"] * 10 + 100
        transformed = pareto_independent(changed, SCENARIOS["full"])
        self.assertTrue((original.pareto_front == transformed.pareto_front).all())

    def test_reject_duplicate_and_nan(self):
        bad = self.frame.copy()
        bad.loc[1, "candidate_id"] = "A"
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            validate_profiles(bad)
        bad = self.frame.copy()
        bad.loc[0, "complexity_score"] = np.nan
        with self.assertRaisesRegex(ValueError, "Nonfinite"):
            validate_profiles(bad)

    def test_reproduce_saved_and_reject_stale(self):
        checked = validate_profiles(self.frame)
        expected = pareto_independent(checked, SCENARIOS["full"])
        self.assertTrue(compare_saved(checked, expected.copy(), expected))
        stale = expected.copy()
        stale.loc[0, "pareto_front"] = False
        with self.assertRaisesRegex(ValueError, "Pareto membership"):
            compare_saved(checked, stale, expected)
        stale = expected.copy()
        stale.loc[0, "zinc_id"] = "ZINC_FAKE"
        with self.assertRaisesRegex(ValueError, "zinc_id mismatch"):
            compare_saved(checked, stale, expected)

    def test_ablations_and_loo_have_valid_bounds(self):
        audit, fronts = sensitivity_audit(self.frame)
        self.assertEqual(len(fronts), len(SCENARIOS))
        self.assertEqual(set(fronts["full"]), {"A", "B", "C", "D"})
        self.assertTrue((audit["loo_present"] == len(self.frame) - 1).all())
        self.assertTrue((audit["loo_front_fraction"].between(0, 1)).all())
        self.assertTrue((audit["ablation_front_count"] <= len(SCENARIOS)).all())


if __name__ == "__main__":
    unittest.main()
