import unittest

from egfr_agent.tools.qsar_inference_tool import (
    QSARInferenceTool
)


class TestQSARInferenceTool(unittest.TestCase):


    def test_valid_smiles_prediction(self):

        tool = QSARInferenceTool()


        smiles = (
            "COc1cc2ncnc"
            "(Nc3cccc(Cl)c3F)"
            "c2cc1N1CC2(CN(C)C2)OC1=O"
        )


        result = tool.run(
            smiles
        )


        self.assertIn(
            "predicted_pIC50",
            result
        )


        self.assertIn(
            "model",
            result
        )


        self.assertIsInstance(
            result["predicted_pIC50"],
            float
        )


        self.assertEqual(
            result["model"]["algorithm"],
            "RandomForestRegressor"
        )


    def test_invalid_smiles(self):

        tool = QSARInferenceTool()


        with self.assertRaises(
            ValueError
        ):

            tool.run(
                "INVALID_SMILES"
            )


if __name__ == "__main__":

    unittest.main()
