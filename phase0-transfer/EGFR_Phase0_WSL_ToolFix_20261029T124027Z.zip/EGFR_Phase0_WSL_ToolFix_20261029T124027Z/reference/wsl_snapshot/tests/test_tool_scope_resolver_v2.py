import unittest

from egfr_agent.tool_scope import EGFRToolScopeResolver


class TestToolScopeResolverV2(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.resolver = EGFRToolScopeResolver()

    def resolve(self, request):
        return self.resolver.resolve(request)

    def test_english_full_candidate_evaluation(self):
        result = self.resolve(
            "Run a full EGFR candidate evaluation for SMILES CCO"
        )
        self.assertEqual(result["allowed_tools"], ["candidate_evaluation"])
        self.assertFalse(result["explicit_qsar_exclusion"])
        self.assertFalse(result["explicit_structure_exclusion"])

    def test_chinese_full_candidate_evaluation(self):
        request = (
            "\u8bf7\u5bf9\u8fd9\u4e2a\u65b0\u5019\u9009\u5206\u5b50"
            "\u8fdb\u884c\u5b8c\u6574\u8bc4\u4f30\uff0cSMILES: CCO"
        )
        self.assertEqual(
            self.resolve(request)["allowed_tools"],
            ["candidate_evaluation"],
        )

    def test_chinese_developability_evaluation(self):
        request = (
            "\u8bf7\u5bf9\u8fd9\u4e2a\u5019\u9009\u5206\u5b50"
            "\u505a\u6210\u836f\u6027\u8bc4\u4f30\uff0cSMILES: CCO"
        )
        self.assertEqual(
            self.resolve(request)["allowed_tools"],
            ["candidate_evaluation"],
        )

    def test_qsar_only_excludes_structure(self):
        result = self.resolve(
            "Predict pIC50 for this molecule only, "
            "no structure analysis. SMILES: CCO"
        )
        self.assertEqual(result["allowed_tools"], ["qsar_inference"])
        self.assertTrue(result["explicit_structure_exclusion"])

    def test_chinese_qsar_only_excludes_structure(self):
        request = (
            "\u53ea\u9884\u6d4b\u8fd9\u4e2a\u5206\u5b50\u7684 pIC50\uff0c"
            "\u4e0d\u505a\u7ed3\u6784\u5206\u6790\uff0cSMILES: CCO"
        )
        result = self.resolve(request)
        self.assertEqual(result["allowed_tools"], ["qsar_inference"])
        self.assertTrue(result["explicit_structure_exclusion"])

    def test_structure_only_excludes_qsar(self):
        result = self.resolve("Only do structure analysis, no QSAR.")
        self.assertEqual(result["allowed_tools"], ["structure_analysis"])
        self.assertTrue(result["explicit_qsar_exclusion"])

    def test_chinese_structure_only_excludes_qsar(self):
        request = (
            "\u53ea\u505a\u7ed3\u6784\u5206\u6790\uff0c"
            "\u4e0d\u505a QSAR"
        )
        result = self.resolve(request)
        self.assertEqual(result["allowed_tools"], ["structure_analysis"])
        self.assertTrue(result["explicit_qsar_exclusion"])

    def test_full_evaluation_rejects_no_qsar(self):
        with self.assertRaisesRegex(ValueError, "explicitly excludes QSAR"):
            self.resolve(
                "Run a full EGFR candidate evaluation for SMILES CCO, "
                "but no QSAR"
            )

    def test_dmpnn_is_isolated(self):
        result = self.resolve(
            "Run PK D-MPNN microsomal clearance prediction for SMILES CCO"
        )
        self.assertEqual(result["allowed_tools"], ["pk_dmpnn_prediction"])
        self.assertFalse(result["explicit_structure_exclusion"])
        self.assertFalse(result["explicit_qsar_exclusion"])

    def test_chinese_dmpnn_is_isolated(self):
        request = (
            "\u8bf7\u505a D-MPNN "
            "\u5fae\u7c92\u4f53\u6e05\u9664\u7387\u9884\u6d4b\uff0c"
            "SMILES: CCO"
        )
        self.assertEqual(
            self.resolve(request)["allowed_tools"],
            ["pk_dmpnn_prediction"],
        )

    def test_qsar_and_structure_can_both_be_authorized(self):
        result = self.resolve(
            "Find promising EGFR inhibitors. Need QSAR ranking, "
            "docking pose and structural analysis."
        )
        self.assertEqual(
            result["allowed_tools"],
            ["qsar_prediction", "structure_analysis"],
        )

    def test_smiles_without_task_fails_closed(self):
        with self.assertRaises(ValueError):
            self.resolve("SMILES: CCO")

    def test_empty_request_fails(self):
        with self.assertRaises(ValueError):
            self.resolve("   ")

    def test_non_string_request_fails(self):
        with self.assertRaises(TypeError):
            self.resolve(None)

    def test_candidate_and_dmpnn_must_be_separated(self):
        with self.assertRaisesRegex(ValueError, "separate audited operations"):
            self.resolve(
                "Run full candidate evaluation and PK D-MPNN "
                "microsomal clearance prediction for SMILES CCO"
            )


if __name__ == "__main__":
    unittest.main()
