import unittest

from egfr_agent.function_calling import EGFRFunctionCaller
from egfr_agent.tool_registry import TOOLS
from egfr_agent.tool_scope import EGFRToolScopeResolver
from egfr_agent.tools.pk_dmpnn_tool import PKDMPNNTool


class PKDMPNNFunctionCallingTests(unittest.TestCase):

    def test_tool_is_registered_and_has_schema(self):
        self.assertIn("pk_dmpnn_prediction", TOOLS)
        self.assertIsInstance(
            TOOLS["pk_dmpnn_prediction"].tool,
            PKDMPNNTool,
        )

        schemas = {
            item["function"]["name"]: item
            for item in EGFRFunctionCaller.TOOL_SCHEMAS
        }
        self.assertIn("pk_dmpnn_prediction", schemas)
        self.assertEqual(
            schemas["pk_dmpnn_prediction"]["function"]["parameters"]
            ["required"],
            ["smiles"],
        )

    def test_explicit_pk_request_authorizes_only_shadow_tool(self):
        resolver = EGFRToolScopeResolver()

        requests = [
            "Predict microsomal clearance for SMILES CCO.",
            "Run PK D-MPNN for SMILES CCO.",
        ]

        for request in requests:
            with self.subTest(request=request):
                scope = resolver.resolve(request)
                self.assertEqual(
                    scope["allowed_tools"],
                    ["pk_dmpnn_prediction"],
                )
                self.assertIn(
                    "candidate_evaluation",
                    scope["prohibited_tools"],
                )

    def test_candidate_evaluation_scope_is_unchanged(self):
        scope = EGFRToolScopeResolver().resolve(
            "Run a full EGFR candidate evaluation for SMILES CCO."
        )
        self.assertEqual(
            scope["allowed_tools"],
            ["candidate_evaluation"],
        )

    def test_smiles_must_match_user_request_exactly(self):
        request = "Predict microsomal clearance for SMILES CCO."

        self.assertEqual(
            EGFRFunctionCaller._validate_arguments(
                "pk_dmpnn_prediction",
                {"smiles": "CCO"},
                request,
            ),
            {"smiles": "CCO"},
        )

        with self.assertRaises(RuntimeError):
            EGFRFunctionCaller._validate_arguments(
                "pk_dmpnn_prediction",
                {"smiles": "CCC"},
                request,
            )

    def test_unexpected_arguments_are_rejected(self):
        with self.assertRaises(RuntimeError):
            EGFRFunctionCaller._validate_arguments(
                "pk_dmpnn_prediction",
                {"smiles": "CCO", "run_docking": True},
                "Predict microsomal clearance for SMILES CCO.",
            )

    def test_successful_prediction_is_summarized(self):
        result = {
            "tool": "pk_dmpnn_prediction",
            "status": "OK",
            "input_smiles": "CCO",
            "target": "Clearance_Microsome_AZ",
            "target_column": "clint_log10",
            "model_seeds": [42, 43, 44, 45, 46],
            "n_models": 5,
            "mean_log10_prediction": 1.0,
            "sample_sd_log10": 1.5811388301,
            "predicted_clearance_mL_min_g": 10.0,
            "scientific_limitations": [
                "Not experimental validation."
            ],
        }

        summary = EGFRFunctionCaller._summarize_frame(
            "pk_dmpnn_prediction",
            result,
        )

        self.assertEqual(summary["status"], "OK")
        self.assertEqual(
            summary["result_type"],
            "pk_dmpnn_shadow_prediction",
        )
        self.assertEqual(summary["input_smiles"], "CCO")
        self.assertAlmostEqual(
            summary["predicted_clearance_mL_min_g"],
            10.0,
        )

    def test_failed_prediction_remains_an_error(self):
        result = {
            "tool": "pk_dmpnn_prediction",
            "status": "ERROR",
            "stage": "checkpoint_validation",
            "error_type": "FileNotFoundError",
            "error": "Mock missing checkpoint.",
            "input_smiles": "CCO",
            "scientific_limitations": [
                "A failed ensemble is not a valid prediction."
            ],
        }

        summary = EGFRFunctionCaller._summarize_frame(
            "pk_dmpnn_prediction",
            result,
        )
        self.assertEqual(summary["status"], "ERROR")
        self.assertEqual(summary["input_smiles"], "CCO")


if __name__ == "__main__":
    unittest.main()
