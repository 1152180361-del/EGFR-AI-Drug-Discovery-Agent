import unittest

import numpy as np
import pandas as pd

from scripts.run_egfr_admet_multiobjective_agent import (
    OBJECTIVES,
    get_active_objectives,
    parse_boolean_series,
    recompute_pareto_flags,
    validate_aggregate_maxima,
)


class TestAdmetMultiobjectiveAgent(unittest.TestCase):

    def setUp(self):
        self.frame = pd.DataFrame({
            "candidate_id": ["A", "B", "C"],
            "baseline_score": [10.0, 8.0, 6.0],
            "pk_risk_score": [3.0, 1.0, 2.0],
            "complexity_score": [8.0, 5.0, 6.0],
            "admet_ai_safety_max_score": [0.9, 0.2, 0.5],
            "admet_ai_tox21_max_score": [0.8, 0.2, 0.5],
            "admet_ai_cyp_inhibition_max_score": [0.8, 0.2, 0.5],
        })

    def test_all_six_objectives_are_detected(self):
        active = get_active_objectives(self.frame)
        self.assertEqual(active, list(OBJECTIVES.keys()))

    def test_pareto_front_is_recomputed_correctly(self):
        active = get_active_objectives(self.frame)
        front, dominated_by = recompute_pareto_flags(
            self.frame, active
        )

        selected = set(
            self.frame.loc[front, "candidate_id"]
        )

        self.assertEqual(selected, {"A", "B"})
        self.assertEqual(
            int(
                dominated_by[
                    self.frame.index[
                        self.frame["candidate_id"] == "C"
                    ][0]
                ]
            ),
            1,
        )

    def test_boolean_parser_accepts_explicit_values(self):
        values = parse_boolean_series(
            pd.Series(["True", "false", True, False, "1", "0"])
        )

        np.testing.assert_array_equal(
            values,
            np.array([True, False, True, False, True, False]),
        )

    def test_boolean_parser_rejects_ambiguous_values(self):
        with self.assertRaisesRegex(ValueError, "Invalid boolean"):
            parse_boolean_series(pd.Series(["yes"]))

    def test_aggregate_maximum_is_validated(self):
        frame = pd.DataFrame({
            "candidate_id": ["A", "B"],
            "admet_ai__AMES": [0.2, 0.4],
            "admet_ai__hERG": [0.3, 0.1],
            "admet_ai_safety_max_score": [0.3, 0.4],
            "admet_ai_safety_max_endpoint": ["hERG", "AMES"],
        })

        validate_aggregate_maxima(
            frame,
            {"safety": ["AMES", "hERG"]},
        )

    def test_incorrect_aggregate_maximum_is_rejected(self):
        frame = pd.DataFrame({
            "candidate_id": ["A"],
            "admet_ai__AMES": [0.2],
            "admet_ai__hERG": [0.3],
            "admet_ai_safety_max_score": [0.2],
            "admet_ai_safety_max_endpoint": ["AMES"],
        })

        with self.assertRaisesRegex(
            ValueError, "does not match raw endpoint maximum"
        ):
            validate_aggregate_maxima(
                frame,
                {"safety": ["AMES", "hERG"]},
            )


if __name__ == "__main__":
    unittest.main()
