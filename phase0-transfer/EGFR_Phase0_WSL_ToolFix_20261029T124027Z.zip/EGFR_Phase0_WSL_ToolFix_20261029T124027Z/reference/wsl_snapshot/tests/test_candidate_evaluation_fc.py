import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from egfr_agent.agent import EGFRAgent
from egfr_agent.function_calling import EGFRFunctionCaller
from egfr_agent.tool_registry import TOOLS
from egfr_agent.tool_scope import EGFRToolScopeResolver
from egfr_agent.tools.candidate_evaluation_tool import CandidateEvaluationTool


TOOL_NAMES = (
    "qsar_rf",
    "pk_descriptor_heuristic",
    "admet_descriptor_heuristic",
    "synthesis_complexity_heuristic",
    "applicability_domain",
)


def make_report(smiles="CCO", evaluation_status="CORE_COMPLETE"):
    tools = {}
    for name in TOOL_NAMES:
        tools[name] = {
            "status": "OK",
            "result": {"smiles": smiles},
        }

    return {
        "schema_version": "egfr_candidate_evaluation_v1",
        "run_id": "TEST_RUN",
        "generated_utc": "2026-10-28T00:00:00+00:00",
        "candidate_label": "user_candidate",
        "evaluation_status": evaluation_status,
        "input_smiles": smiles,
        "canonical_smiles": smiles,
        "molecular_descriptors": {"molecular_formula": "C2H6O"},
        "activity_estimate": {
            "status": "OK",
            "predicted_pIC50": 5.0,
        },
        "tools": tools,
        "recommendation": "Computational prioritization only.",
        "scientific_limitations": [
            "No experimental activity validation.",
            "No new docking or model training.",
        ],
    }


class CandidateEvaluationFunctionCallingTests(unittest.TestCase):
    def test_full_candidate_evaluation_authorizes_only_composite_tool(self):
        scope = EGFRToolScopeResolver().resolve(
            "Run a full EGFR candidate evaluation for SMILES CCO."
        )
        self.assertEqual(scope["allowed_tools"], ["candidate_evaluation"])
        self.assertIn("qsar_inference", scope["prohibited_tools"])
        self.assertIn("structure_analysis", scope["prohibited_tools"])

    def test_plain_pic50_request_keeps_existing_qsar_only_scope(self):
        scope = EGFRToolScopeResolver().resolve(
            "Predict pIC50 for this SMILES: CCO"
        )
        self.assertEqual(scope["allowed_tools"], ["qsar_inference"])

    def test_full_evaluation_conflicting_with_no_qsar_fails_closed(self):
        with self.assertRaises(ValueError):
            EGFRToolScopeResolver().resolve(
                "Run a full candidate evaluation for SMILES CCO without QSAR."
            )

    def test_candidate_evaluation_requires_exact_user_smiles(self):
        request = "Run a full EGFR candidate evaluation for SMILES CCO."
        self.assertEqual(
            EGFRFunctionCaller._validate_arguments(
                "candidate_evaluation",
                {"smiles": "CCO"},
                request,
            ),
            {"smiles": "CCO"},
        )
        with self.assertRaises(RuntimeError):
            EGFRFunctionCaller._validate_arguments(
                "candidate_evaluation",
                {"smiles": "CCC"},
                request,
            )

    def test_candidate_evaluation_rejects_extra_arguments(self):
        with self.assertRaises(RuntimeError):
            EGFRFunctionCaller._validate_arguments(
                "candidate_evaluation",
                {"smiles": "CCO", "run_docking": True},
                "Run a full EGFR candidate evaluation for SMILES CCO.",
            )

    def test_partial_report_is_a_valid_auditable_tool_result(self):
        report = make_report(evaluation_status="PARTIAL")
        report["status"] = "PARTIAL"
        report["report_paths"] = {}
        report["tools"]["applicability_domain"] = {
            "status": "ERROR",
            "error": "mocked domain failure",
        }

        summary = EGFRFunctionCaller._summarize_frame(
            "candidate_evaluation",
            report,
        )
        self.assertEqual(summary["result_type"], "candidate_evaluation_report")
        self.assertEqual(summary["status"], "PARTIAL")
        self.assertEqual(
            summary["tool_statuses"]["applicability_domain"],
            "ERROR",
        )

    def test_composite_tool_is_registered(self):
        self.assertIn("candidate_evaluation", TOOLS)

    def test_invalid_smiles_does_not_launch_cli(self):
        tool = CandidateEvaluationTool()
        with patch(
            "egfr_agent.tools.candidate_evaluation_tool.subprocess.run"
        ) as mocked_run:
            result = tool.run("INVALID_SMILES")
        self.assertEqual(result["status"], "ERROR")
        self.assertEqual(result["stage"], "input_validation")
        mocked_run.assert_not_called()

    def test_cli_report_is_checked_for_identity_and_five_tools(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            script = root / "scripts" / "evaluate_new_candidate.py"
            script.parent.mkdir(parents=True)
            script.write_text("# mocked script path\n", encoding="utf-8")

            report_dir = root / "reports" / "candidate_evaluations"
            report_dir.mkdir(parents=True)

            report = make_report("CCO")
            json_path = report_dir / "EGFR_candidate_eval_TEST_RUN.json"
            markdown_path = report_dir / "EGFR_candidate_eval_TEST_RUN.md"
            json_path.write_text(
                json.dumps(report),
                encoding="utf-8",
            )
            markdown_path.write_text("# mocked report\n", encoding="utf-8")

            stdout = (
                f"JSON_REPORT: {json_path}\n"
                f"MARKDOWN_REPORT: {markdown_path}\n"
            )
            completed = SimpleNamespace(
                returncode=0,
                stdout=stdout,
                stderr="",
            )

            with patch(
                "egfr_agent.tools.candidate_evaluation_tool.ROOT",
                root,
            ), patch(
                "egfr_agent.tools.candidate_evaluation_tool.subprocess.run",
                return_value=completed,
            ) as mocked_run:
                result = CandidateEvaluationTool().run("CCO")

            mocked_run.assert_called_once()
            self.assertEqual(result["status"], "OK")
            self.assertEqual(result["input_smiles"], "CCO")
            self.assertEqual(result["report_paths"]["json"], str(json_path))
            self.assertEqual(set(result["tools"]), set(TOOL_NAMES))

    def test_trace_preserves_candidate_report_and_qsar_status(self):
        report = make_report("CCO")
        report.update({
            "status": "OK",
            "report_paths": {
                "json": "/tmp/mock_candidate.json",
                "markdown": "/tmp/mock_candidate.md",
            },
        })

        function_result = {
            "model": "test-model",
            "mode": "ollama_native_tool_calling",
            "scope": {
                "allowed_tools": ["candidate_evaluation"],
                "prohibited_tools": [
                    "qsar_prediction",
                    "qsar_inference",
                    "structure_analysis",
                ],
            },
            "required_tools": ["candidate_evaluation"],
            "executed_tools": ["candidate_evaluation"],
            "model_requested_tools": ["candidate_evaluation"],
            "call_log": [
                {
                    "tool": "candidate_evaluation",
                    "status": "executed",
                }
            ],
            "results": {"candidate_evaluation": report},
            "llm_summary": "test summary",
        }

        original_cwd = os.getcwd()
        try:
            with tempfile.TemporaryDirectory() as temp:
                os.chdir(temp)
                trace_path = EGFRAgent._save_trace(
                    "Run a full candidate evaluation for SMILES CCO.",
                    function_result,
                )
                trace = json.loads(
                    Path(trace_path).read_text(encoding="utf-8")
                )
                self.assertIn(
                    "candidate_evaluation",
                    trace["tool_results"],
                )
                self.assertEqual(
                    trace["tool_results"]["candidate_evaluation"]
                    ["report_paths"]["json"],
                    "/tmp/mock_candidate.json",
                )
                self.assertTrue(
                    any(
                        "Composite candidate evaluation workflow was invoked"
                        in item
                        for item in trace["scientific_limitations"]
                    )
                )
        finally:
            os.chdir(original_cwd)


if __name__ == "__main__":
    unittest.main()
