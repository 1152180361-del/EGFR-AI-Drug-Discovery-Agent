"""Offline interface/safety tests; no Ollama calls or file writes."""
import unittest

import pandas as pd

from scripts.run_egfr_multiobjective_agent import (
    REQUEST,
    authorize_request,
    check_alignment,
)


class TestMultiobjectiveAgentExtension(unittest.TestCase):
    def make_fixture(self):
        ids = [f"EGFR_CAND_{i:03d}" for i in range(1, 11)]
        zincs = [f"ZINC{i:012d}" for i in range(1, 11)]
        scores = [13.0, 10.0, 10.0, 9.0, 9.0, 7.0, 6.0, 6.0, 6.0, 6.0]
        original = {
            "candidate": ids[0],
            "ranking": pd.DataFrame({"candidate": ids, "score": scores}),
            "function_calling": {"results": {
                "structure_analysis": pd.DataFrame({
                    "phase4C_candidate_id": ids, "zinc_id": zincs,
                })
            }},
        }
        profiles = pd.DataFrame({
            "candidate_id": ids,
            "zinc_id": zincs,
            "smiles": ["CCO"] * 10,
            "baseline_score": scores,
        })
        comparison = pd.DataFrame({
            "candidate_id": ids,
            "baseline_score": scores,
            "pk_risk_score": [0] * 10,
            "complexity_score": [5.5] * 10,
            "pareto_front": [True] + [False] * 9,
            "dominated_by_count": [0] + [1] * 9,
        })
        return original, profiles, comparison

    def test_authorized_default_request(self):
        scope = authorize_request(REQUEST)
        self.assertEqual(
            set(scope["allowed_tools"]),
            {"qsar_prediction", "structure_analysis"},
        )

    def test_reject_unrelated_live_smiles(self):
        with self.assertRaises(ValueError):
            authorize_request(
                "Predict EGFR pIC50 for SMILES: CCO and analyze docking "
                "ADMET PK synthesis"
            )

    def test_reject_explicit_opt_out(self):
        with self.assertRaises(ValueError):
            authorize_request(
                "Analyze EGFR QSAR and docking without ADMET, "
                "and assess PK synthesis"
            )

    def test_aligned_evidence_passes(self):
        self.assertTrue(check_alignment(*self.make_fixture()))

    def test_score_mutation_rejected(self):
        state, profiles, comparison = self.make_fixture()
        profiles.loc[0, "baseline_score"] = 99
        with self.assertRaises(ValueError):
            check_alignment(state, profiles, comparison)

    def test_zinc_identity_mutation_rejected(self):
        state, profiles, comparison = self.make_fixture()
        profiles.loc[0, "zinc_id"] = "ZINC_FAKE"
        with self.assertRaises(ValueError):
            check_alignment(state, profiles, comparison)


if __name__ == "__main__":
    unittest.main()
