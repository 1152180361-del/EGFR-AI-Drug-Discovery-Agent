"""Offline regression tests for immutable and scientifically faithful agent traces."""
import json
import os
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path

import pandas as pd

from egfr_agent.agent import EGFRAgent


@contextmanager
def temporary_project():
    original = Path.cwd()
    with tempfile.TemporaryDirectory() as folder:
        os.chdir(folder)
        try:
            yield Path(folder)
        finally:
            os.chdir(original)


def function_result(name, value):
    return {
        "model": "offline_stub",
        "mode": "offline_unit_test",
        "scope": {"allowed_tools": [name]},
        "required_tools": [name],
        "executed_tools": [name],
        "model_requested_tools": [name],
        "call_log": [{"tool": name, "status": "executed"}],
        "results": {name: value},
        "llm_summary": "Unverified example narrative.",
    }


class TestEGFRV2Trace(unittest.TestCase):
    def test_live_prediction_saved_without_false_no_inference_claim(self):
        with temporary_project():
            result = {
                "smiles": "CCO",
                "predicted_pIC50": 5.859233543078105,
                "model": {"algorithm": "RandomForestRegressor"},
            }
            path = EGFRAgent._save_trace(
                "Predict EGFR pIC50 for SMILES: CCO",
                function_result("qsar_inference", result),
            )
            trace = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(trace["tool_results"]["qsar_inference"], result)
            self.assertIsNone(trace["trusted_decision"])
            self.assertTrue(Path(trace["immutable_trace_path"]).exists())
            limits = " ".join(trace["scientific_limitations"])
            self.assertIn("Live single-SMILES QSAR inference executed", limits)
            self.assertNotIn("No new single-molecule QSAR inference", limits)
            self.assertIn("No structure-based candidate ranking", limits)

    def test_precomputed_structure_is_not_mislabeled_live(self):
        with temporary_project():
            frame = pd.DataFrame({
                "phase4C_candidate_id": ["EGFR_CAND_003", "EGFR_CAND_020"],
                "qsar_predicted_pIC50": [7.0, 6.9],
            })
            path = EGFRAgent._save_trace(
                "Review existing EGFR docking evidence",
                function_result("structure_analysis", frame),
            )
            trace = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(trace["tool_results"]["structure_analysis"]["rows_returned"], 2)
            self.assertNotIn("predicted_pIC50", trace["tool_results"]["structure_analysis"])
            limits = " ".join(trace["scientific_limitations"])
            self.assertIn("precomputed candidate files", limits)
            self.assertIn("No new single-molecule QSAR", limits)

    def test_distinct_runs_are_archived_and_latest_updated(self):
        with temporary_project():
            archives = []
            for smiles, value in (("CCO", 5.8), ("c1ccccc1", 6.1)):
                path = EGFRAgent._save_trace(
                    f"Predict EGFR pIC50 for SMILES: {smiles}",
                    function_result("qsar_inference", {
                        "smiles": smiles, "predicted_pIC50": value
                    }),
                )
                trace = json.loads(path.read_text(encoding="utf-8"))
                archives.append(Path(trace["immutable_trace_path"]))
            self.assertNotEqual(archives[0], archives[1])
            self.assertTrue(all(p.is_file() for p in archives))
            self.assertEqual(
                json.loads(archives[0].read_text())["tool_results"]["qsar_inference"]["smiles"],
                "CCO",
            )
            self.assertEqual(
                json.loads(path.read_text())["tool_results"]["qsar_inference"]["smiles"],
                "c1ccccc1",
            )

    def test_nonfinite_prediction_cannot_be_written(self):
        with temporary_project():
            with self.assertRaises(ValueError):
                EGFRAgent._save_trace(
                    "Predict EGFR pIC50 for SMILES: CCO",
                    function_result("qsar_inference", {
                        "smiles": "CCO", "predicted_pIC50": float("nan")
                    }),
                )
            self.assertFalse(Path("reports/EGFR_AI_Agent_Tool_Trace.json").exists())


if __name__ == "__main__":
    unittest.main()
