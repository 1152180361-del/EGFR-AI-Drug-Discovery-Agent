import unittest

import pandas as pd

from scripts.integrate_admet_ai_multiobjective_v1 import (
    OBJECTIVES,
    pareto_analysis,
    validate_candidate_alignment,
)


class TestAdmetAiMultiobjectiveV1(unittest.TestCase):

    def setUp(self):
        self.profile = pd.DataFrame({
            "candidate_id": ["A", "B"],
            "zinc_id": ["ZINC0001", "ZINC0002"],
            "smiles": ["CCO", "CCN"],
        })

        self.admet = pd.DataFrame({
            "candidate_id": ["A", "B"],
            "zinc_id": ["ZINC0001", "ZINC0002"],
            "smiles": ["OCC", "CCN"],
        })

    def test_canonical_smiles_alignment_passes(self):
        profile, admet = validate_candidate_alignment(
            self.profile, self.admet, "smiles"
        )
        self.assertEqual(len(profile), 2)
        self.assertEqual(len(admet), 2)

    def test_zinc_mismatch_is_rejected(self):
        admet = self.admet.copy()
        admet.loc[0, "zinc_id"] = "ZINC9999"

        with self.assertRaisesRegex(ValueError, "ZINC ID mismatch"):
            validate_candidate_alignment(
                self.profile, admet, "smiles"
            )

    def test_smiles_mismatch_is_rejected(self):
        admet = self.admet.copy()
        admet.loc[0, "smiles"] = "CCN"

        with self.assertRaisesRegex(ValueError, "SMILES mismatch"):
            validate_candidate_alignment(
                self.profile, admet, "smiles"
            )

    def test_candidate_set_mismatch_is_rejected(self):
        admet = self.admet.iloc[:1].copy()

        with self.assertRaisesRegex(ValueError, "Candidate ID sets differ"):
            validate_candidate_alignment(
                self.profile, admet, "smiles"
            )

    def test_admet_objectives_change_pareto_dominance(self):
        frame = pd.DataFrame({
            "candidate_id": ["A", "B", "C"],
            "baseline_score": [10.0, 8.0, 6.0],
            "pk_risk_score": [3.0, 1.0, 2.0],
            "complexity_score": [8.0, 5.0, 6.0],
            "admet_ai_safety_max_score": [0.9, 0.2, 0.5],
            "admet_ai_tox21_max_score": [0.8, 0.2, 0.5],
            "admet_ai_cyp_inhibition_max_score": [0.8, 0.2, 0.5],
        })

        result = pareto_analysis(
            frame, list(OBJECTIVES.keys())
        )

        front = set(
            result.loc[result["pareto_front"], "candidate_id"]
        )

        self.assertEqual(front, {"A", "B"})
        self.assertFalse(
            bool(
                result.set_index("candidate_id").loc[
                    "C", "pareto_front"
                ]
            )
        )


if __name__ == "__main__":
    unittest.main()
