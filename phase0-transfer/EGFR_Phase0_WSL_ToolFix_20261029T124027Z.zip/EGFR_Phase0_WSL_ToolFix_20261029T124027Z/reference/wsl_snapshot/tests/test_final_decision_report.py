"""Offline tests for final EGFR computational decision report; no Ollama or file writes."""

import unittest

import pandas as pd

from scripts.audit_pareto_robustness import SCENARIOS, pareto_independent
from scripts.build_egfr_final_decision_report import (
    build_decision_matrix,
    render_report,
    score_decomposition,
)


class TestEGFRFinalDecisionReport(unittest.TestCase):
    def setUp(self):
        # Synthetic fixture mirrors the original DecisionEngine rules, not a new model.
        rows = [
            # id, track, rank, pic50, tanimoto, ATP, MET, baseline, PK, complexity
            ("A", "SUPPORTED_A", 1, 6.856, 0.58, 0.714, 5.608, 13, 1, 5.5),
            ("B", "EXPLORATORY_OOD", 2, 7.29, 0.39, 0.8, 5.0, 10, 0, 8.0),
            ("C", "EXPLORATORY_OOD", 3, 7.108, 0.29, 0.8, 3.0, 9, 0, 9.5),
            ("D", "SUPPORTED_A", 4, 6.94, 0.544, 0.6, 6.0, 9, 0, 9.0),
            ("E", "SUPPORTED_A", 5, 6.87, 0.574, 0.5, 6.0, 9, 0, 6.0),
        ]
        profiles = []
        structure = []
        for i, (cid, track, rank, pic50, tan, atp, met, base, pk, cx) in enumerate(rows):
            zinc = f"ZINC{i+1:012d}"
            profiles.append({
                "candidate_id": cid, "zinc_id": zinc, "smiles": "CCO" + "C" * i,
                "consensus_rank": rank, "qsar_predicted_pIC50": pic50,
                "max_training_tanimoto": tan, "baseline_score": base,
                "pk_risk_score": pk, "complexity_score": cx,
                "molecular_weight": 300 + i, "logP": 1.5, "TPSA": 70.0,
                "drug_likeness_rule": "PASS", "pk_descriptor_risk": "LOW_PK_RISK",
                "synthetic_complexity_proxy": "MODERATE",
            })
            structure.append({
                "phase4C_candidate_id": cid, "zinc_id": zinc,
                "candidate_track": track, "consensus_rank": rank,
                "qsar_predicted_pIC50": pic50, "max_training_tanimoto": tan,
                "key_ATP_contact_coverage": atp, "MET793_distance": met,
            })
        self.profiles = pd.DataFrame(profiles)
        self.structure = pd.DataFrame(structure)
        self.comparison = pareto_independent(self.profiles, SCENARIOS["full"])

    def build(self, profiles=None, comparison=None, structure=None):
        return build_decision_matrix(
            self.profiles if profiles is None else profiles,
            self.comparison if comparison is None else comparison,
            self.structure if structure is None else structure,
            expected_count=5,
        )

    def test_full_matrix_and_score_reconstruction(self):
        matrix, audit = self.build()
        self.assertEqual(len(matrix), 5)
        self.assertEqual(matrix["baseline_recalculated"].tolist(), [13, 10, 9, 9, 9])
        self.assertTrue(audit["baseline_rules_reproduced"])
        self.assertTrue(audit["source_identity_verified"])

    def test_expected_pareto_and_review_group(self):
        matrix, metadata = self.build()
        front = set(matrix.loc[matrix.pareto_front, "candidate_id"])
        self.assertEqual(front, {"A", "B", "E"})
        self.assertEqual(
            matrix.set_index("candidate_id").loc["A", "review_queue"],
            "BASELINE_LEADER_ALL_SCENARIOS",
        )
        self.assertEqual(len(metadata["pareto_scenarios"]), 5)

    def test_reject_altered_saved_baseline_score(self):
        altered = self.comparison.copy()
        altered.loc[0, "baseline_score"] = 99
        with self.assertRaisesRegex(ValueError, "baseline_score mismatch"):
            self.build(comparison=altered)

    def test_reject_altered_profile_baseline(self):
        altered = self.profiles.copy()
        altered.loc[0, "baseline_score"] = 99
        # The frozen comparison no longer matches before baseline reconstruction.
        with self.assertRaisesRegex(ValueError, "baseline_score mismatch"):
            self.build(profiles=altered)

    def test_reject_misassigned_zinc_identity(self):
        altered = self.structure.copy()
        altered.loc[0, "zinc_id"] = "ZINC_FAKE"
        with self.assertRaisesRegex(ValueError, "ZINC identity mismatch"):
            self.build(structure=altered)

    def test_reject_mismatched_structural_predicted_pic50(self):
        altered = self.structure.copy()
        altered.loc[0, "qsar_predicted_pIC50"] = 4.5
        with self.assertRaisesRegex(ValueError, "qsar_predicted_pIC50"):
            self.build(structure=altered)

    def test_reject_duplicate_structural_candidate_id(self):
        altered = self.structure.copy()
        altered.loc[0, "phase4C_candidate_id"] = "B"
        with self.assertRaisesRegex(ValueError, "Duplicate structure"):
            self.build(structure=altered)

    def test_reject_missing_structure_evidence(self):
        altered = self.structure.drop(columns=["MET793_distance"])
        with self.assertRaisesRegex(ValueError, "Missing structure evidence columns"):
            self.build(structure=altered)

    def test_reject_invalid_atp_coverage(self):
        altered = self.structure.copy()
        altered.loc[0, "key_ATP_contact_coverage"] = 2.1
        with self.assertRaisesRegex(ValueError, "Invalid ATP coverage"):
            self.build(structure=altered)

    def test_render_report_is_evidence_cautious(self):
        matrix, metadata = self.build()
        text = render_report(matrix, metadata)
        self.assertIn("final computational candidate review", text)
        self.assertIn("NOT validated EGFR inhibitors", text)
        self.assertIn("Experimental", text.replace("experimental", "Experimental"))
        self.assertIn("Baseline", text)

    def test_independently_reproduced_score_change_is_caught(self):
        malformed = self.structure.copy()
        malformed.loc[0, "MET793_distance"] = 3.0
        # Rebuild an isolated aligned score frame so score_decomposition sees the error.
        joined = self.profiles.merge(
            malformed, left_on="candidate_id", right_on="phase4C_candidate_id",
            suffixes=("", "_structure"),
        )
        with self.assertRaisesRegex(ValueError, "Baseline score mismatch"):
            score_decomposition(joined)


if __name__ == "__main__":
    unittest.main()
