# EGFR Phase 0：WSL安全应用与本地真实验收

本包是代码补丁与证据交接，不是项目重建或整包覆盖。云端已通过专项127项、全量226项；真实Ollama仍BLOCKED。应用本包后的WSL测试与真实E2E尚未运行，不把云端计数贴为本机结果。

不下载模型，不开放服务端口，不训练，不重算全局快照，不改变评分/排名，不提交/推送，不执行Phase1–5。

## 1. 文件与基线

- patches/cloud-this-turn.patch：本轮云端修复前→修复后，7个源码/测试文件。
- patches/wsl-context-to-final.patch：上传的WSL快照→最终受保护版本，13个文件（5应用源码、8测试）。包含PK shadow隔离、已有SMILES/Trace防护，见MODIFIED_FILES.md。
- payload/：这13个文件的最终全文，供审查；不要复制覆盖项目。
- reference/：WSL原快照与云端修改前副本，均保留。
- cloud-evidence/：云端真实测试、失败日志、逐项状态、补丁与原始证据。里面的/workspace路径仅为云端记录，不是WSL命令。
- transfer-manifest.json / SHA256SUMS：逐文件基线、目标和包内SHA-256。

run_agent.py不在用户上传的WSL快照中；只能对照已知云端修复前SHA。不同则BLOCKED，需要原文件人工审查，不自动猜测。

## 2. 包装器与日志约定

用户本地原scripts/run_and_copy.sh未交接。这里提供独立的同名包装器，放在解压目录scripts/中；不安装或覆盖项目里的原脚本，也不声称两者参数接口相同。以下所有终端执行均经过包内scripts/run_and_copy.sh。

每条命令使用唯一目录保存完整stdout.log、stderr.log、combined.log、exit-code.txt、command.json与流SHA；命令失败原样返回非零，不被复制/tee的成功掩盖。支持clip.exe、wl-copy或xclip自动复制；不可用/失败明确记录，不声称已复制。云端无剪贴板程序的记录为UNAVAILABLE。

下载ZIP及外层.sha256，用文件管理器解压到独立目录，不解压到项目根覆盖。将下面路径变量改为真实位置；这些变量赋值不执行项目命令。PY选择已有WSL环境，不运行pip/conda安装。云端RF核验对应scikit-learn1.9.1。

    B=/home/xie/EGFR_Phase0_WSL_ToolFix_20261029T124027Z
    P=/home/xie/EGFR_AIDD_Pipeline
    PY=/home/xie/miniforge3/envs/rdkit_aidd/bin/python
    V=/home/xie/EGFR_Phase0_validation_20261029T124027Z

V必须是尚不存在的独立目录；已有则换新名字，不能清理重用。

## 3. 先核验与检查，不写项目文件

    bash "$B/scripts/run_and_copy.sh" --label verify-package --log-root "$B/wsl-command-logs" -- python3 "$B/scripts/transfer.py" verify

    bash "$B/scripts/run_and_copy.sh" --label inspect-project --log-root "$B/wsl-command-logs" -- python3 "$B/scripts/transfer.py" inspect --project "$P"

只有READY/ALREADY_APPLIED才可继续。任何CONFLICT都必须停止应用，保留本地版本、包内payload和检查日志，先审查差异。不能以补丁大致能应用为由放宽哈希，也不使用--reject/--3way制造半应用结果。

## 4. 备份并应用

    bash "$B/scripts/run_and_copy.sh" --label apply-patch --log-root "$B/wsl-command-logs" -- python3 "$B/scripts/transfer.py" apply --project "$P" --backup-root /home/xie/EGFR_Phase0_backups

应用器先验证所有基线，git apply --check；外部唯一备份保存原文件、未暂存diff、暂存diff和status；再次核对后，一次git apply。不改Git index，不reset/clean，不提交推送。自动选择每个文件匹配的WSL或云端已知基线。目标已相同则不写。receipt.json记录实际备份位置和应用文件。

不要手动覆盖payload。回滚前必须确认应用后的文件未再次编辑；只审查备份内applied.patch的逆补丁，不以HEAD覆盖整个工作区。本包不自动回滚或删除文件。

## 5. 本地运行环境和专项测试

    bash "$B/scripts/run_and_copy.sh" --label runtime --log-root "$B/wsl-command-logs" --cwd "$P" -- "$PY" "$B/scripts/check_runtime.py"

若环境不兼容先记录BLOCKED，选择原来兼容的现有环境，不下载/换模型。

    bash "$B/scripts/run_and_copy.sh" --label targeted --log-root "$B/wsl-command-logs" --cwd "$P" -- "$PY" -m pytest tests/test_scope_operation_boundaries.py tests/test_function_calling_argument_recovery.py tests/test_agent_flow_v2.py tests/test_tool_scope_resolver_v2.py tests/test_candidate_evaluation_fc.py tests/test_pk_dmpnn_function_calling.py tests/test_cli_failure_audit.py tests/test_agent_trace_v2.py -q --continue-on-collection-errors --tb=short -rs '--junitxml={LOG_DIR}/targeted.xml'

这是自动化测试，含脚本化LLM和夹具，不是真实E2E。{LOG_DIR}由包装器展开为本次唯一日志目录，不覆盖旧JUnit。

## 6. 准备独立验证副本

    bash "$B/scripts/run_and_copy.sh" --label prepare-validation --log-root "$B/wsl-command-logs" -- python3 "$B/scripts/transfer.py" prepare --project "$P" --destination "$V"

只复制本地真实Python源码、测试、配置及清单内21份既有原模型/数据/研究夹具；不复制.git、.env、Conda环境、缓存或无关大文件。不存在/固定资产摘要冲突会BLOCKED，不创建占位物。

两个latest报告允许不同于云端历史版本，记录实际本地摘要后复制，绝不替换成历史报告“让测试通过”。固定历史Trace/研究输入仍严格核对。根目录test_*.py若不是已审阅的安全guard版本，会BLOCKED；应交回原文件审查，不能绕过收集或把pytest tests/称作完整根目录回归。

## 7. 全量与真实Ollama：只在V中执行

    bash "$B/scripts/run_and_copy.sh" --label full --log-root "$V/evidence" --cwd "$V" -- "$PY" -m pytest . -q --continue-on-collection-errors --tb=short -rs '--junitxml={LOG_DIR}/full.xml'

    bash "$B/scripts/run_and_copy.sh" --label native-function-calling --log-root "$V/evidence" --cwd "$V" -- "$PY" "$B/scripts/native_function_calling_local.py"

    bash "$B/scripts/run_and_copy.sh" --label native-agent --log-root "$V/evidence" --cwd "$V" -- env OLLAMA_API_BASE=http://127.0.0.1:11434 OLLAMA_MODEL=qwen2.5:7b "$PY" -m egfr_agent.run_agent

    bash "$B/scripts/run_and_copy.sh" --label native-multiobjective --log-root "$V/evidence" --cwd "$V" -- env OLLAMA_API_BASE=http://127.0.0.1:11434 OLLAMA_MODEL=qwen2.5:7b "$PY" scripts/run_egfr_multiobjective_agent.py

这里127.0.0.1是WSL本机，不是Codex云端。真实检查只GET本地version/tags并调用现有qwen2.5:7b，无pull/install；测试请求全局快照和两条中英文否定请求。两个正式入口均实际运行，不用直接工具或FakeLLM替代。所有新增Trace、报告、失败审计仅在V中，原项目报告/排名保持原样。

任一步非零都保留真实异常；环境/资产阻塞不能算PASS。原生预检失败后仍可执行两个正式入口以记录各自异常，但不能删掉失败步骤。不要把成功复制输出当命令成功。

## 8. 汇总和回传

    bash "$B/scripts/run_and_copy.sh" --label collect-results --log-root "$V/evidence" --cwd "$V" -- python3 "$B/scripts/collect_wsl_results.py" --validation "$V"

输出实际WSL台账和结果ZIP（日志、JUnit、JSON/Markdown报告、哈希；不含权重、CSV、.env或缓存），同时核对原项目21项输入未变。将结果ZIP和.sha256交回审查。

必须核对授权范围、参数错误是否实际被纠正、工具最多一次、输入身份、Trace与同次报告一致、生产评分/排名未变。若LLM未产生参数错误，只能证明正常合法调用，真实“错误后恢复”路径仍NOT_VERIFIED，不能人为伪造错误响应冒充真实模型。

WSL测试数量以本地JUnit/stdout为准；目录不同不能照抄云端226。任何FAIL、SKIP、收集错误都要说明。收集器即便所有入口exit0，也只标记待证据审查，不自动宣告Phase0完成。PK物理单位/实验来源、历史checkpoint身份等原科学限制继续保留。
