from pathlib import Path
import ast
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

bundle = Path("/workspace/EGFR_Phase0_WSL_ToolFix_20261029T124027Z")
record_root = Path("/workspace/recovery/wsl-toolfix-export-20261029T124027Z")
fixtures = Path(tempfile.mkdtemp(prefix="patch-rehearsal-", dir=record_root))
wrapper = bundle / "scripts/run_and_copy.sh"
log_root = record_root / "rehearsal-command-logs"
manifest = json.loads((bundle / "transfer-manifest.json").read_text())
outcomes = []


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(label, argv, expected=0):
    command = ["bash", str(wrapper), "--label", label, "--log-root", str(log_root),
               "--", *map(str, argv)]
    result = subprocess.run(command, capture_output=True, text=True)
    sys.stdout.write(result.stdout)
    sys.stderr.write(result.stderr)
    assert result.returncode == expected, (label, result.returncode, expected)
    folder = next(p for p in log_root.iterdir()
                  if json.loads((p / "command.json").read_text())["label"] == label)
    metadata = json.loads((folder / "command.json").read_text())
    assert metadata["exit_code"] == expected
    for filename, item in metadata["streams"].items():
        assert sha(folder / filename) == item["sha256"]
    outcomes.append({"check": label, "status": "PASS",
                     "expected_exit_code": expected, "actual_exit_code": result.returncode,
                     "log_directory": str(folder)})
    return folder


def baseline(name, conflict=False):
    project = fixtures / name
    project.mkdir()
    for entry in manifest["files"]:
        primary = entry["bases"][0]
        if primary["sha256"] is None:
            continue
        wsl = bundle / "reference/wsl_snapshot" / entry["path"]
        cloud = bundle / "reference/cloud_before" / entry["path"]
        source = wsl if wsl.exists() else cloud
        assert sha(source) == primary["sha256"]
        target = project / entry["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    # A scratch repository for patch mechanics only. No project reconstruction,
    # model/data placeholders, Git commits, or changes to the original checkout.
    init = subprocess.run(["git", "init", "-q", str(project)], capture_output=True)
    assert init.returncode == 0
    (project / "unrelated-local-note.txt").write_text("Preserve this local work.\n")
    stage = subprocess.run(["git", "add", "egfr_agent/tool_scope.py"],
                           cwd=project, capture_output=True)
    assert stage.returncode == 0
    if conflict:
        path = project / "egfr_agent/tool_scope.py"
        path.write_text(path.read_text() + "\n# independent WSL local edit\n")
    return project


for path in (bundle / "scripts").glob("*.py"):
    ast.parse(path.read_text())
run("shell-syntax", ["bash", "-n", wrapper])
run("bundle-integrity", [sys.executable, bundle / "scripts/transfer.py", "verify"])
project = baseline("known-wsl-snapshot")
original_index = (project / ".git/index").read_bytes()
original_note = (project / "unrelated-local-note.txt").read_bytes()
run("known-baseline-inspect",
    [sys.executable, bundle / "scripts/transfer.py", "inspect", "--project", project])
run("known-baseline-apply",
    [sys.executable, bundle / "scripts/transfer.py", "apply", "--project", project,
     "--backup-root", fixtures / "backups"])
assert (project / ".git/index").read_bytes() == original_index
assert (project / "unrelated-local-note.txt").read_bytes() == original_note
assert all(sha(project / row["path"]) == row["target_sha256"]
           for row in manifest["files"])
receipts = list((fixtures / "backups").glob("*/receipt.json"))
assert len(receipts) == 1
receipt = json.loads(receipts[0].read_text())
assert receipt["git_index_unchanged"]
for row in receipt["files"]:
    if row["actual_sha256"] is not None:
        original = receipts[0].parent / "original" / row["path"]
        assert sha(original) == row["actual_sha256"]
run("idempotent-no-write",
    [sys.executable, bundle / "scripts/transfer.py", "apply", "--project", project,
     "--backup-root", fixtures / "backups"])
assert len(list((fixtures / "backups").glob("*/receipt.json"))) == 1
conflicted = baseline("local-conflict", conflict=True)
before = {str(p.relative_to(conflicted)): sha(p) for p in conflicted.rglob("*")
          if p.is_file() and ".git" not in p.relative_to(conflicted).parts}
run("conflict-stops-all-files",
    [sys.executable, bundle / "scripts/transfer.py", "apply", "--project", conflicted,
     "--backup-root", fixtures / "conflict-backups"], expected=2)
after = {str(p.relative_to(conflicted)): sha(p) for p in conflicted.rglob("*")
         if p.is_file() and ".git" not in p.relative_to(conflicted).parts}
assert before == after and not (fixtures / "conflict-backups").exists()
damaged = fixtures / "damaged-bundle"
shutil.copytree(bundle, damaged)
first = manifest["files"][0]
payload = damaged / first["payload"]
payload.write_text(payload.read_text() + "\n# transfer corruption simulation\n")
run("damaged-payload-rejected",
    [sys.executable, damaged / "scripts/transfer.py", "verify"], expected=2)
streams = run(
    "wrapper-preserves-streams-and-exit7",
    [sys.executable, "-c",
     "import sys; print('OUT alpha'); print('ERR beta', file=sys.stderr); raise SystemExit(7)"],
    expected=7,
)
assert (streams / "stdout.log").read_text() == "OUT alpha\n"
assert (streams / "stderr.log").read_text() == "ERR beta\n"
assert {"OUT alpha", "ERR beta"} <= set((streams / "combined.log").read_text().splitlines())
expanded = run("unique-log-placeholder",
               [sys.executable, "-c", "import sys; print(sys.argv[1])", "{LOG_DIR}/file.xml"])
assert (expanded / "stdout.log").read_text().strip() == str(expanded / "file.xml")
result = {
    "status": "PASS_EXPORT_MECHANICS_ONLY",
    "checks": outcomes,
    "known_wsl_snapshot_patch_applied_in_scratch": True,
    "staged_index_and_unrelated_local_work_preserved": True,
    "conflict_atomicity_confirmed": True,
    "native_ollama_requests_this_export": 0,
    "real_wsl_project_accessed": False,
    "real_wsl_e2e_executed": False,
    "original_project_source_modified": False,
    "clipboard_in_cloud": "UNAVAILABLE_NOT_CLAIMED_COPIED",
}
(record_root / "export-rehearsal.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
