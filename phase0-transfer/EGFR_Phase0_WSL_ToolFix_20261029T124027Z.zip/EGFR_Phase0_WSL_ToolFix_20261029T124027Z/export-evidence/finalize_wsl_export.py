from pathlib import Path
import ast
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

b = Path("/workspace/EGFR_Phase0_WSL_ToolFix_20261029T124027Z")
r = Path("/workspace/EGFR-AI-Drug-Discovery-Agent")
rec = Path("/workspace/recovery/wsl-toolfix-export-20261029T124027Z")
out = b / "export-evidence"
out.mkdir(exist_ok=True)


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()


def preserve_copy(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        assert sha(source) == sha(destination), str(destination)
    else:
        with source.open("rb") as src, destination.open("xb") as dst:
            shutil.copyfileobj(src, dst)


for name in ("export-rehearsal.json", "preparer-rehearsal.json"):
    preserve_copy(rec / name, out / name)
for name in ("rehearsal-command-logs", "preparer-command-logs"):
    for path in (rec / name).rglob("*"):
        if path.is_file():
            preserve_copy(path, out / name / path.relative_to(rec / name))
for metadata in (rec / "command-logs").glob("*/command.json"):
    value = json.loads(metadata.read_text())
    if value.get("label") != "finalize-export-v2":
        for path in metadata.parent.iterdir():
            if path.is_file():
                preserve_copy(path, out / "export-command-logs" / metadata.parent.name / path.name)
before = json.loads((rec / "workspace-before-export-check.json").read_text())
changed = [name for name, h in before.items()
           if not (r / name).is_file() or sha(r / name) != h]
assert not changed, changed
for args, filename in (
        (["status", "--porcelain=v1"], "git-status-before.txt"),
        (["diff", "--binary"], "git-diff-before.patch"),
        (["diff", "--cached", "--binary"], "git-index-before.patch")):
    assert subprocess.check_output(["git", *args], cwd=r) == (rec / filename).read_bytes()
status = {
    "original_repository_files_hash_checked": len(before),
    "original_files_changed": changed, "git_status_and_diffs_unchanged": True,
    "cloud_ollama_requests_this_export": 0, "local_wsl_accessed": False,
    "wsl_patch_applied_to_real_project": False, "real_wsl_e2e": "NOT_VERIFIED",
    "cloud_automated_results_inherited": {"targeted": 127, "full": 226},
    "export_checks_only": "PASS", "git_committed_or_pushed": False,
}
(out / "repository-preservation.json").write_text(json.dumps(status, indent=2) + "\n")
(b / "EXPORT_STATUS.md").write_text(
    "# 交付状态（2026-10-29，Asia/Shanghai）\n\n"
    "本轮仅导出补丁包，云端Ollama请求0次。原仓库629份既有文件字节、Git status、"
    "未暂存diff和暂存diff保持不变；不提交推送。\n\n"
    "|事项|状态|边界|\n|---|---|---|\n"
    "|云端专项127/全量226|此前PASS|不是本轮重跑，不是WSL结果|\n"
    "|补丁/哈希/冲突/备份/幂等/暂存保护/包装器|PASS|隔离目录演练|\n"
    "|21份真实资产准备副本|PASS|复制与哈希；未运行新科学推理或训练|\n"
    "|缺少真实入口的收集器|正确BLOCKED/exit2|不伪造验收|\n"
    "|实际WSL应用/专项/全量/真实原生调用/两个入口|NOT_VERIFIED|待本地执行|\n"
    "|云端原生E2E|历史BLOCKED，本轮停止尝试|不要求公开端口|\n"
    "|剪贴板|云端UNAVAILABLE；WSL未验证|支持clip.exe等，不伪报复制|\n"
    "|Phase0|尚未完整验收|不能以补丁导出替代真实验证|\n\n"
    "本地原scripts/run_and_copy.sh未提供，包内独立包装器不覆盖它。首次云端只读定位未走"
    "包装器，已说明；随后导出终端命令统一通过包装器。\n\n"
    "打包历史错误均保留：初次因把旧静态审查的__pycache__计入候选而断言失败，"
    "已改为只按原manifest选25文件；一次归档脚本遇到旧包装器日志无label字段，"
    "已兼容处理。这些是导出脚本诊断，不是应用回归失败，未修改原仓库，最终包没有缓存。\n\n"
    "不含模型权重、训练/全局CSV、.env、密钥文件或缓存。SHA256SUMS核验全部静态交付文件，"
    "外层ZIP.sha256核验整个包。先解压至独立目录，通过verify/inspect再应用，不能复制payload覆盖。\n"
)
preserve_copy(Path("/tmp/test_wsl_toolfix_export.py"),
              out / "test_wsl_toolfix_export.py")
preserve_copy(Path("/tmp/finalize_wsl_export.py"),
              out / "finalize_wsl_export.py")
paths = [path for path in b.rglob("*") if path.is_file()]
for path in paths:
    assert not path.is_symlink()
    assert "__pycache__" not in path.relative_to(b).parts
    assert path.name != ".env" and path.suffix not in {".pyc", ".pt", ".joblib", ".csv"}
for path in (b / "scripts").glob("*.py"):
    ast.parse(path.read_text())
patterns = [
    r"gh[pousr]_[A-Za-z0-9]{20,}",
    r"-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----",
    r"""(?i)(?:api[_-]?key|access[_-]?token|password|secret)\s*[:=]\s*["'][A-Za-z0-9_+/.=-]{16,}""",
]
hits = [str(path.relative_to(b)) for path in paths
        if any(re.search(pattern, path.read_text(errors="replace")) for pattern in patterns)]
assert not hits, hits
(out / "sensitive-scan.json").write_text(json.dumps({
    "patterns_checked": len(patterns), "matches": 0,
    "not_a_proof_of_all_possible_secrets": True,
}, indent=2) + "\n")
paths = sorted(path for path in b.rglob("*")
               if path.is_file() and path.name != "SHA256SUMS")
(b / "SHA256SUMS").write_text(
    "".join(sha(path) + "  " + str(path.relative_to(b)) + "\n" for path in paths))
archive = Path(str(b) + ".zip")
with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for path in sorted(b.rglob("*")):
        if path.is_file():
            handle.write(path, str(Path(b.name) / path.relative_to(b)))
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    for line in (b / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        assert hashlib.sha256(handle.read(b.name + "/" + name)).hexdigest() == expected
checksum = Path(str(archive) + ".sha256")
checksum.write_text(sha(archive) + "  " + archive.name + "\n")
summary = {
    "archive": str(archive), "bytes": archive.stat().st_size, "sha256": sha(archive),
    "checksum_file": str(checksum), "files_in_zip": len(paths) + 1,
    "packaged_application_files": 5, "packaged_new_or_modified_tests": 8,
    "cloud_ollama_requests": 0, "original_repository_unchanged": True,
}
(rec / "delivery.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
