"""Evidence-constrained Ollama tool calling for the EGFR project.

The precomputed ZINC table, live single-SMILES inference and precomputed
structure evidence are distinct sources and must not be conflated.
"""

import json
import re
import math

import pandas as pd

from .llm_client import OllamaClient
from .tool_scope import EGFRToolScopeResolver


class EGFRFunctionCaller:
    TOOL_SCHEMAS = [
        {
            "type": "function",
            "function": {
                "name": "qsar_prediction",
                "description": (
                    "Read existing global ZINC QSAR screening predictions. "
                    "This does not perform new molecular inference."
                ),
                "parameters": {
                    "type": "object", "properties": {},
                    "additionalProperties": False,
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "qsar_inference",
                "description": (
                    "Predict EGFR pIC50 from the exact molecular SMILES "
                    "provided by the user. Do not invent or modify SMILES."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "smiles": {"type": "string", "description": "User supplied SMILES"}
                    },
                    "required": ["smiles"],
                    "additionalProperties": False,
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "structure_analysis",
                "description": (
                    "Read existing EGFR candidate docking and pose metrics. "
                    "No new docking for a user-supplied SMILES is performed."
                ),
                "parameters": {
                    "type": "object", "properties": {},
                    "additionalProperties": False,
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "candidate_evaluation",
                "description": (
                    "Run the deterministic five-part EGFR new-candidate "
                    "evaluation using the exact user-supplied SMILES. "
                    "The protected Python workflow invokes existing QSAR, "
                    "PK, ADMET, synthesis-accessibility and applicability-"
                    "domain evaluators, and writes JSON/Markdown reports. "
                    "It does not perform docking or retraining."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "smiles": {
                            "type": "string",
                            "description":
                                "Exact SMILES explicitly supplied by the user.",
                        }
                    },
                    "required": ["smiles"],
                    "additionalProperties": False,
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "pk_dmpnn_prediction",
                "description": (
                    "Predict microsomal clearance using five fixed "
                    "Chemprop D-MPNN checkpoints and the exact SMILES "
                    "provided by the user. This is an isolated shadow "
                    "evaluation and does not change production ranking."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "smiles": {
                            "type": "string",
                            "description": "Exact user-supplied SMILES.",
                        }
                    },
                    "required": ["smiles"],
                    "additionalProperties": False,
                },
            },
        },
    ]

    SOURCE_LABELS = {
        "qsar_prediction": "precomputed_global_zinc_qsar_snapshot",
        "qsar_inference": "real_time_qsar_model_inference",
        "structure_analysis": "precomputed_egfr_candidate_evidence",
        "candidate_evaluation": "deterministic_five_part_candidate_evaluation",
        "pk_dmpnn_prediction": "shadow_chemprop_dmpnn_microsomal_clearance_five_seed_ensemble",
    }

    MAX_ROUNDS = 6
    MAX_REPROMPTS = 2

    def __init__(self, registry):
        self.registry = registry
        self.client = OllamaClient()
        self.scope_resolver = EGFRToolScopeResolver()
        self.schema_by_name = {
            item["function"]["name"]: item for item in self.TOOL_SCHEMAS
        }
        # Some offline legacy evaluators register only the tools used by a case.
        # A missing tool becomes an error only if that tool is authorized.

    @staticmethod
    def _parse_arguments(value):
        if value is None or value == "":
            return {}
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except json.JSONDecodeError as exc:
                raise RuntimeError("Invalid tool arguments JSON.") from exc
        if not isinstance(value, dict):
            raise RuntimeError("Tool arguments must be an object.")
        return value

    @classmethod
    def _validate_arguments(cls, name, raw_arguments, user_request):
        arguments = cls._parse_arguments(raw_arguments)
        expected = (
            {"smiles"}
            if name in {"qsar_inference", "candidate_evaluation", "pk_dmpnn_prediction"}
            else set()
        )
        unexpected = set(arguments) - expected
        if unexpected:
            raise RuntimeError(
                f"Unexpected tool arguments for {name}: {sorted(unexpected)}"
            )
        if name in {"qsar_inference", "candidate_evaluation", "pk_dmpnn_prediction"}:
            smiles = arguments.get("smiles")
            if not isinstance(smiles, str) or not smiles.strip():
                raise RuntimeError(f"{name} requires smiles.")
            if len(smiles) > 10000:
                raise RuntimeError("SMILES too long.")
            if smiles != smiles.strip():
                raise RuntimeError(
                    "SMILES must not have surrounding whitespace."
                )
            # Substrings are not molecule identity: CC must not match CCO,
            # and CCO must not match one component of CCO.CCN.
            token_chars = r"A-Za-z0-9@+\-\[\]()=#\\/%:*"
            exact_token = (
                r"(?<![" + token_chars + r".])" + re.escape(smiles)
                + r"(?![" + token_chars + r"]|\.(?=[A-Za-z0-9\[]))"
            )
            if not re.search(exact_token, user_request):
                raise RuntimeError(
                    "Rejected SMILES not found verbatim in user request. "
                    "Use the user's exact SMILES rather than an LLM guess."
                )
        return arguments

    @classmethod
    def _summarize_frame(cls, name, result):
        source = cls.SOURCE_LABELS[name]

        if isinstance(result, dict):
            if name == "pk_dmpnn_prediction":
                status = result.get("status")
                if status not in {"OK", "ERROR"}:
                    raise RuntimeError(
                        "PK D-MPNN returned an invalid status."
                    )

                input_smiles = result.get("input_smiles")
                if not isinstance(input_smiles, str):
                    raise RuntimeError(
                        "PK D-MPNN omitted input_smiles."
                    )

                if status == "OK":
                    if result.get("target") != "Clearance_Microsome_AZ":
                        raise RuntimeError(
                            "PK D-MPNN returned an unexpected target."
                        )

                    if result.get("model_seeds") != [42, 43, 44, 45, 46]:
                        raise RuntimeError(
                            "PK D-MPNN returned an unexpected seed set."
                        )

                    if result.get("n_models") != 5:
                        raise RuntimeError(
                            "PK D-MPNN did not return five models."
                        )

                    numeric_fields = (
                        "mean_log10_prediction",
                        "sample_sd_log10",
                        "predicted_clearance_mL_min_g",
                    )
                    for field in numeric_fields:
                        value = result.get(field)
                        if (
                            isinstance(value, bool)
                            or not isinstance(value, (int, float))
                            or not math.isfinite(value)
                        ):
                            raise RuntimeError(
                                f"PK D-MPNN returned invalid {field}."
                            )

                    if result["predicted_clearance_mL_min_g"] <= 0:
                        raise RuntimeError(
                            "PK D-MPNN clearance must be positive."
                        )

                return {
                    "source": source,
                    "rows_returned": 1,
                    "result_type": "pk_dmpnn_shadow_prediction",
                    "status": status,
                    "input_smiles": input_smiles,
                    "target": result.get("target"),
                    "mean_log10_prediction":
                        result.get("mean_log10_prediction"),
                    "sample_sd_log10": result.get("sample_sd_log10"),
                    "predicted_clearance_mL_min_g":
                        result.get("predicted_clearance_mL_min_g"),
                    "result": result,
                    "scientific_limitations": result.get(
                        "scientific_limitations",
                        [
                            "Predicted clearance is not an experimental "
                            "measurement.",
                            "Between-seed variation is not calibrated "
                            "predictive uncertainty.",
                            "Production PK scoring and ranking are unchanged.",
                        ],
                    ),
                }

            if name == "candidate_evaluation":
                status = result.get("status")
                if status not in {"OK", "PARTIAL", "ERROR"}:
                    raise RuntimeError(
                        "Candidate evaluation returned an invalid status."
                    )

                input_smiles = result.get("input_smiles")
                if not isinstance(input_smiles, str):
                    raise RuntimeError(
                        "Candidate evaluation did not return input_smiles."
                    )
                if status != "ERROR" and not input_smiles:
                    raise RuntimeError(
                        "Candidate evaluation returned an empty SMILES."
                    )

                nested_tools = result.get("tools", {})
                if status in {"OK", "PARTIAL"}:
                    if not isinstance(nested_tools, dict):
                        raise RuntimeError(
                            "Candidate evaluation returned invalid tool results."
                        )
                    required = {
                        "qsar_rf",
                        "pk_descriptor_heuristic",
                        "admet_descriptor_heuristic",
                        "synthesis_complexity_heuristic",
                        "applicability_domain",
                    }
                    missing = required - set(nested_tools)
                    if missing:
                        raise RuntimeError(
                            "Candidate evaluation omitted required evaluators: "
                            + ", ".join(sorted(missing))
                        )

                tool_statuses = {}
                if isinstance(nested_tools, dict):
                    for tool_name, block in nested_tools.items():
                        if isinstance(block, dict):
                            tool_statuses[tool_name] = block.get(
                                "status", "UNKNOWN"
                            )
                        else:
                            tool_statuses[tool_name] = "INVALID_RESULT"

                return {
                    "source": source,
                    "rows_returned": 1,
                    "result_type": "candidate_evaluation_report",
                    "status": status,
                    "evaluation_status": result.get("evaluation_status"),
                    "input_smiles": input_smiles,
                    "tool_statuses": tool_statuses,
                    "report_paths": result.get("report_paths", {}),
                    "result": result,
                    "scientific_limitations": result.get(
                        "scientific_limitations",
                        [
                            "Computational predictions are not experimental "
                            "validation.",
                            "This workflow does not perform new docking or "
                            "model training.",
                        ],
                    ),
                }

            if name != "qsar_inference":
                raise TypeError(f"{name} should return a DataFrame.")

            if (
                "predicted_pIC50" not in result
                or "smiles" not in result
            ):
                raise RuntimeError(
                    "QSAR inference returned incomplete results."
                )

            return {
                "source": source,
                "rows_returned": 1,
                "result_type": "single_molecule_prediction",
                "result": result,
                "scientific_limitations": (
                    "Predicted potency only; not experimental validation, "
                    "calibrated confidence or docking evidence."
                ),
            }

        if not isinstance(result, pd.DataFrame):
            raise TypeError(f"{name} did not return a DataFrame.")
        if result.empty:
            raise RuntimeError(f"{name} returned empty evidence.")

        return {
            "source": source,
            "rows_returned": int(len(result)),
            "result_type": "precomputed_evidence_table",
            "columns": list(result.columns),
            "sample_rows": json.loads(
                result.head(5).to_json(orient="records")
            ),
            "scientific_limitations": (
                "Precomputed computational evidence; not a new docking "
                "calculation or experimental validation."
            ),
        }

    def run(self, user_request):
        scope = self.scope_resolver.resolve(user_request)
        allowed_names = list(scope["allowed_tools"])
        allowed_set = set(allowed_names)
        missing_tools = allowed_set - set(self.registry)
        if missing_tools:
            raise RuntimeError(
                f"Registered tools missing: {sorted(missing_tools)}"
            )

        # The structure reader cannot dock the live QSAR input. Fail closed
        # rather than rank precomputed, unrelated EGFR_CAND compounds.
        if {"qsar_inference", "structure_analysis"} <= allowed_set:
            raise ValueError(
                "Cannot combine live SMILES inference with precomputed "
                "candidate structure evidence for one compound. "
                "New-SMILES docking is not implemented."
            )

        system_prompt = (
            "You control evidence-constrained EGFR computational tools.\\n"
            f"Only authorized tools for this request: "
            f"{json.dumps(allowed_names)}\\n"
            "qsar_prediction reads an existing global ZINC snapshot and "
            "does not run new inference.\\n"
            "qsar_inference predicts only the exact SMILES supplied by the "
            "user; never invent or modify it.\\n"
            "structure_analysis reads precomputed candidate structure "
            "evidence; it does not run new docking.\\n"
            "candidate_evaluation is one protected composite tool. It "
            "deterministically invokes the existing QSAR, PK, ADMET, "
            "synthesis-accessibility and applicability-domain evaluators "
            "for the same exact user-supplied SMILES, and writes JSON/"
            "Markdown reports.\\n"
            "The composite evaluation performs no docking, model training, "
            "experimental validation or unvalidated composite scoring.\\n"
            "pk_dmpnn_prediction predicts microsomal clearance using "
            "the exact user-supplied SMILES and five fixed Chemprop "
            "D-MPNN checkpoints. It is an isolated shadow evaluation "
            "and must not change production PK scoring or ranking.\\n"
            "Call each authorized tool at most once. Do not call excluded "
            "tools. The Python decision engine owns existing-candidate ranking."
        )
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_request},
        ]
        executed = {}
        requested_by_model = []
        reprompts = 0
        call_log = [{
            "event": "scope_resolved",
            "authorization_method": scope["authorization_method"],
            "allowed_tools": allowed_names,
            "prohibited_tools": scope["prohibited_tools"],
        }]

        print("\nTOOL SCOPE GUARD")
        print("Allowed:", allowed_names)
        print("Unavailable for this request:", scope["prohibited_tools"])

        for round_number in range(1, self.MAX_ROUNDS + 1):
            remaining = [name for name in allowed_names if name not in executed]
            schemas = [self.schema_by_name[name] for name in remaining]
            response = self.client.chat(messages, tools=schemas if schemas else None)
            message = response.get("message")
            if not isinstance(message, dict):
                raise RuntimeError("Invalid Ollama assistant message.")
            messages.append(message)
            calls = message.get("tool_calls") or []
            if not isinstance(calls, list):
                raise RuntimeError("Invalid tool_calls format.")

            if not calls:
                missing = [name for name in allowed_names if name not in executed]
                if missing:
                    if reprompts >= self.MAX_REPROMPTS:
                        raise RuntimeError(
                            "LLM did not invoke the authorized required tools: "
                            + ", ".join(missing)
                        )
                    reprompts += 1
                    call_log.append({
                        "round": round_number,
                        "event": "coverage_reprompt",
                        "missing_tools": missing,
                    })
                    messages.append({
                        "role": "user",
                        "content": (
                            "Task incomplete. Call these authorized tools now: "
                            + ", ".join(missing)
                            + ". For qsar_inference, use the user's exact SMILES."
                        ),
                    })
                    continue
                return {
                    "model": self.client.model,
                    "mode": "ollama_native_tool_calling",
                    "rounds": round_number,
                    "required_tools": allowed_names,
                    "executed_tools": list(executed),
                    "model_requested_tools": requested_by_model,
                    "scope": scope,
                    "results": executed,
                    "call_log": call_log,
                    "llm_summary": message.get("content") or "",
                }

            # Validate the full batch before executing any tool.
            validated = []
            for call in calls:
                if not isinstance(call, dict):
                    raise RuntimeError("Invalid tool call object.")
                function = call.get("function")
                if not isinstance(function, dict):
                    raise RuntimeError("Tool call missing function.")
                name = function.get("name")
                if name not in allowed_set:
                    raise RuntimeError("Rejected unapproved LLM tool: " + str(name))
                args = self._validate_arguments(
                    name, function.get("arguments", {}), user_request
                )
                validated.append((name, args))

            for name, arguments in validated:
                requested_by_model.append(name)
                if name in executed:
                    call_log.append({
                        "round": round_number, "tool": name,
                        "status": "duplicate_blocked",
                    })
                    messages.append({
                        "role": "tool", "tool_name": name,
                        "content": json.dumps({
                            "status": "not_reexecuted",
                            "reason": "Tool already executed.",
                        }),
                    })
                    continue

                print("\nNATIVE FUNCTION CALL:", name)
                if name in {"qsar_inference", "candidate_evaluation", "pk_dmpnn_prediction"}:
                    wrapper = self.registry[name]
                    if hasattr(wrapper, "run_with_args"):
                        result = wrapper.run_with_args(**arguments)
                    else:
                        result = wrapper.tool.run(**arguments)
                else:
                    result = self.registry[name].run()

                if name == "qsar_inference":
                    if (
                        not isinstance(result, dict)
                        or result.get("smiles") != arguments["smiles"]
                    ):
                        raise RuntimeError("QSAR inference returned a different SMILES identity.")
                    value = result.get("predicted_pIC50")
                    if (
                        isinstance(value, bool)
                        or not isinstance(value, (int, float))
                        or not math.isfinite(value)
                    ):
                        raise RuntimeError("QSAR inference returned invalid predicted_pIC50.")

                if name == "candidate_evaluation":
                    if (
                        not isinstance(result, dict)
                        or result.get("input_smiles") != arguments["smiles"]
                    ):
                        raise RuntimeError(
                            "Candidate evaluation returned a different "
                            "SMILES identity."
                        )

                if name == "pk_dmpnn_prediction":
                    if (
                        not isinstance(result, dict)
                        or result.get("input_smiles") != arguments["smiles"]
                    ):
                        raise RuntimeError(
                            "PK D-MPNN returned a different SMILES identity."
                        )

                summary = self._summarize_frame(name, result)
                payload = json.dumps(summary, ensure_ascii=False, allow_nan=False)
                executed[name] = result
                call_status = "executed"
                if name == "candidate_evaluation":
                    if result.get("status") == "ERROR":
                        call_status = "returned_error"
                    elif result.get("status") == "PARTIAL":
                        call_status = "partial"

                if (
                    name == "pk_dmpnn_prediction"
                    and isinstance(result, dict)
                    and result.get("status") == "ERROR"
                ):
                    call_status = "returned_error"

                call_log.append({
                    "round": round_number,
                    "tool": name,
                    "status": call_status,
                    "source": summary["source"],
                    "rows_returned": summary["rows_returned"],
                    "arguments": (
                        arguments
                        if name in {"qsar_inference", "candidate_evaluation", "pk_dmpnn_prediction"}
                        else {}
                    ),
                })
                messages.append({
                    "role": "tool", "tool_name": name,
                    "content": payload,
                })
                print("SOURCE:", summary["source"])
                print("ROWS:", summary["rows_returned"])
                if isinstance(result, pd.DataFrame):
                    print(result.head(3).to_string(index=False))
                else:
                    print(json.dumps(result, ensure_ascii=False, indent=2))

        raise RuntimeError(
            f"Function-calling loop exceeded {self.MAX_ROUNDS} rounds."
        )
