#!/usr/bin/env python3
"""Opt-in EGFR multiobjective Agent; preserves original Agent and scores."""
import argparse
import hashlib
import json
import math
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from egfr_agent.decision_engine import EGFRDecisionEngine
from egfr_agent.function_calling import EGFRFunctionCaller
from egfr_agent.tool_registry import TOOLS
from egfr_agent.tool_scope import EGFRToolScopeResolver

REQUEST = (
    "Analyze EGFR QSAR activity and docking evidence for existing candidates, "
    "then assess ADMET, PK and synthesis developability."
)
OUT = ROOT / "results/agent_developability"


def authorize_request(request):
    if not isinstance(request, str) or not request.strip():
        raise ValueError("Empty or invalid request")
    t = request.lower()
    if re.search(
        r"\b(?:no|without|skip|avoid|omit|do not|don't)\b[^.\n]{0,45}"
        r"\b(?:admet|pk|synthesis|developability)\b"
        r"|(?:不要|不需要|跳过|排除)[^。；，\n]{0,20}"
        r"(?:admet|pk|药代|合成|开发性)", t
    ):
        raise ValueError("Explicitly excluded developability step")
    if not re.search(
        r"\b(?:admet|pk|synthesis|developability|multi[- ]objective)\b"
        r"|多目标|可开发性|合成可行性|药代", t
    ):
        raise ValueError("Multiobjective assessment was not requested")
    scope = EGFRToolScopeResolver().resolve(request)
    allowed = set(scope["allowed_tools"])
    if not {"qsar_prediction", "structure_analysis"} <= allowed:
        raise ValueError("Request must authorize existing QSAR and docking evidence")
    if "qsar_inference" in allowed:
        raise ValueError("Cannot associate new SMILES with precomputed docking")
    return scope


def _ids(df, col):
    if not isinstance(df, pd.DataFrame) or df.empty or col not in df:
        raise ValueError(f"Empty table or absent {col}")
    v = df[col].astype(str).str.strip()
    if df[col].isna().any() or v.eq("").any() or v.duplicated().any():
        raise ValueError(f"Missing or duplicate values in {col}")
    return set(v)


def check_alignment(state, profiles, comparison):
    ranking = state["ranking"]
    structure = state["function_calling"]["results"]["structure_analysis"]
    names = _ids(ranking, "candidate")
    if not (names == _ids(structure, "phase4C_candidate_id")
            == _ids(profiles, "candidate_id")
            == _ids(comparison, "candidate_id")):
        raise ValueError("Candidate sets differ across stages")
    if len(names) != 10 or state["candidate"] not in names:
        raise ValueError("Expected ten candidates and a valid primary candidate")
    for df, id_col, score_col in (
        (ranking, "candidate", "score"),
        (profiles, "candidate_id", "baseline_score"),
        (comparison, "candidate_id", "baseline_score"),
    ):
        score = pd.to_numeric(df[score_col], errors="raise")
        if not all(math.isfinite(float(v)) for v in score):
            raise ValueError("Nonfinite baseline score")
    expected = ranking.set_index("candidate")["score"]
    for df in (profiles, comparison):
        actual = df.set_index("candidate_id")["baseline_score"]
        for cid in names:
            if not math.isclose(float(expected[cid]), float(actual[cid]),
                                abs_tol=1e-9):
                raise ValueError(f"{cid}: baseline score changed")
    source_zinc = structure.set_index("phase4C_candidate_id")["zinc_id"]
    actual_zinc = profiles.set_index("candidate_id")["zinc_id"]
    for cid in names:
        if str(source_zinc[cid]).strip() != str(actual_zinc[cid]).strip():
            raise ValueError(f"{cid}: ZINC ID mismatch")
    if profiles["smiles"].isna().any() or (
        profiles["smiles"].astype(str).str.strip().eq("")
    ).any():
        raise ValueError("Missing verified SMILES")
    for col in ("pareto_front", "pk_risk_score", "complexity_score",
                "dominated_by_count"):
        if col not in comparison:
            raise ValueError(f"Missing objective column: {col}")
    flags = comparison["pareto_front"].astype(str).str.lower()
    if not flags.isin(["true", "false"]).all() or not flags.eq("true").any():
        raise ValueError("Invalid Pareto classifications")
    return True


def run(request=REQUEST):
    scope = authorize_request(request)
    # Optional full-workflow helpers are not needed for offline validation.
    # Resolve them before any LLM, evidence pipeline or output mutation.
    from scripts.run_candidate_developability import run as profile_candidates
    from scripts.compare_candidate_objectives import main as compare_objectives
    os.chdir(ROOT)

    # Existing native function caller runs ONLY the old QSAR/structure tools.
    function_result = EGFRFunctionCaller(TOOLS).run(request)
    if not {"qsar_prediction", "structure_analysis"} <= set(
        function_result.get("executed_tools", [])
    ):
        raise RuntimeError("Authorized evidence tools did not both execute")
    structure = function_result["results"]["structure_analysis"]
    ranking = EGFRDecisionEngine().analyze(structure.copy())
    state = {
        "candidate": str(ranking.iloc[0]["candidate"]),
        "ranking": ranking,
        "function_calling": function_result,
    }

    # The three descriptor tools are invoked by a deterministic orchestrator,
    # not by LLM-native function calling. Candidate/SMILES matches are checked
    # inside the existing profiling script.
    profile_candidates()
    compare_objectives()
    profile_file = OUT / "EGFR_candidate_developability.csv"
    comparison_file = OUT / "EGFR_objective_comparison.csv"
    profiles = pd.read_csv(profile_file, dtype={"zinc_id": str})
    comparison = pd.read_csv(comparison_file, dtype={"zinc_id": str})
    check_alignment(state, profiles, comparison)

    front = comparison.loc[
        comparison["pareto_front"].astype(str).str.lower().eq("true"),
        "candidate_id",
    ].tolist()
    lines = [
        "# EGFR Multiobjective Agent — independent report", "",
        f"Request: {request}", "",
        f"Original baseline primary candidate: **{state['candidate']}**", "",
        f"Exploratory Pareto front: **{', '.join(front)}**", "",
        "| Candidate | Baseline score | PK proxy | Complexity proxy | Pareto |",
        "|---|---:|---:|---:|---|",
    ]
    for row in comparison.itertuples(index=False):
        lines.append(
            f"| {row.candidate_id} | {row.baseline_score:g} | "
            f"{row.pk_risk_score:g} | {row.complexity_score:g} | "
            f"{'Yes' if row.pareto_front else 'No'} |"
        )
    lines += [
        "", "## Scientific and execution boundaries", "",
        "- The original decision score and candidate priority are unchanged.",
        "- QSAR/structure were authorized native LLM calls, reading prior evidence.",
        "- ADMET/PK/synthesis calls were deterministic Python orchestration.",
        "- PK scores are descriptor proxies, not clearance or half-life.",
        "- Synthesis complexity is not a demonstrated synthesis route.",
        "- Toxicity labels are unvalidated descriptor proxies.",
        "- Pareto status is a heuristic comparison, not evidence of efficacy.",
        "- No experimental activity, pharmacokinetics or toxicity was measured.",
        "- Original EGFRAgent report, memory and latest trace were not overwritten.",
        "",
    ]

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    uid = f"{stamp}_{uuid4().hex[:8]}"
    folder = ROOT / "reports/agent_runs"
    folder.mkdir(parents=True, exist_ok=True)
    report_path = folder / f"EGFR_Multiobjective_Report_{uid}.md"
    trace_path = folder / f"EGFR_Multiobjective_Trace_{uid}.json"
    audit = {
        "request": request,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "model": function_result["model"],
        "scope": scope,
        "native_executed_tools": function_result["executed_tools"],
        "native_call_log": function_result["call_log"],
        "deterministic_tools": [
            "admet_analysis", "pk_prediction", "synthesis_assessment"
        ],
        "baseline_primary": state["candidate"],
        "baseline_score_preserved": True,
        "pareto_front_candidates": front,
        "source_sha256": {
            "profiles": hashlib.sha256(profile_file.read_bytes()).hexdigest(),
            "comparison": hashlib.sha256(comparison_file.read_bytes()).hexdigest(),
        },
        "candidate_results": json.loads(comparison.to_json(orient="records")),
        "scientific_status": "exploratory_heuristic_no_experimental_validation",
    }
    report_path.write_text("\n".join(lines), encoding="utf-8")
    trace_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2),
                          encoding="utf-8")
    print("\nPASS: multiobjective Agent run completed")
    print("Baseline primary:", state["candidate"])
    print("Pareto front:", front)
    print("Report:", report_path)
    print("Trace:", trace_path)
    return {"baseline": state, "profiles": profiles, "comparison": comparison,
            "report_path": str(report_path), "trace_path": str(trace_path)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("request", nargs="?", default=REQUEST)
    run(parser.parse_args().request)
