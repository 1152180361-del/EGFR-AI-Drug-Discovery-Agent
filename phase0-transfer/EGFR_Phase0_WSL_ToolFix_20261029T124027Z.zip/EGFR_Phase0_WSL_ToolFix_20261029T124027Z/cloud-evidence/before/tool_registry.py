from .tools import (
    QSARTool,
    QSARInferenceTool,
    StructureTool,
    ADMETTool,
    PKTool,
    SynthesisTool,
    CandidateEvaluationTool,
)



class ToolWrapper:


    def __init__(
        self,
        name,
        description,
        tool
    ):

        self.name = name
        self.description = description
        self.tool = tool



    def run(self):

        return self.tool.run()



    def run_with_args(self, **kwargs):

        return self.tool.run(
            **kwargs
        )





TOOLS = {



    "qsar_prediction":

    ToolWrapper(

        "qsar_prediction",

        "Read precomputed ZINC QSAR screening evidence",

        QSARTool()

    ),



    "qsar_inference":

    ToolWrapper(

        "qsar_inference",

        "Real time QSAR prediction from SMILES",

        QSARInferenceTool()

    ),



    "structure_analysis":

    ToolWrapper(

        "structure_analysis",

        "Docking and ATP pocket structural evidence",

        StructureTool()

    ),



    "admet_analysis":

    ToolWrapper(

        "admet_analysis",

        "Descriptor based ADMET developability evaluation",

        ADMETTool()

    ),



    "pk_prediction":

    ToolWrapper(

        "pk_prediction",

        "Descriptor based pharmacokinetic risk estimation",

        PKTool()

    ),



    "synthesis_assessment":

    ToolWrapper(

        "synthesis_assessment",

        "Synthetic accessibility estimation",

        SynthesisTool()

    ),




    "candidate_evaluation":

    ToolWrapper(

        "candidate_evaluation",

        "Deterministic five-part new-candidate evaluation",

        CandidateEvaluationTool()

    ),

    # PK D-MPNN is deliberately absent: use the isolated shadow tool directly.

}





def list_tools():

    return list(
        TOOLS.keys()
    )
