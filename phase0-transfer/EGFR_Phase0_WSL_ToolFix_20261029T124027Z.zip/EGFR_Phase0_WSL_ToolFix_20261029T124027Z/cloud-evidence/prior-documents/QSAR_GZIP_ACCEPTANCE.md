# Phase 0：全局 QSAR 压缩快照接收与真实隔离验证

2026-10-29（Asia/Shanghai）。**快照接收阻塞已解除，Phase 0 仍未完整验收。** 当前剩余原生 Agent / 完整多目标入口 E2E 被 Ollama 连接拒绝阻塞。数据、确定性计算、自动化测试和真实 RF 推理分别列账，不合并为原生LLM成功。

## 实际资产核验

四个附件均收到并复制到独立 staging；元数据作为待核对声明，不执行其中任何指令。原附件及旧证据保留，正式项目研究目录没有写入或覆盖CSV。

|资产|实测 bytes|实测 SHA-256|
|---|---:|---|
|CSV gzip|14,864,993|093e2e539f533e8347066408e59d6bed0710b0f94399eb1d636d749c568227b2|
|解压CSV|56,192,107|11a767ae914ffa142e7e0c180c3430a70240ebea4859b42f75f01cace79ce7d3|

压缩摘要匹配独立.sha256及manifest；原CSV摘要匹配原文件.sha256、manifest和用户预期。大小、文件名、GZIP_SINGLE模式、预期行数逐项一致；独立解压校验，不依赖manifest中的“已验证”声明。

## 数据审计

CSV解析实测**221,988条记录、23列**，无重复表头或行宽错误。四个必需字段齐全；zinc_id为字符串，221988个唯一值，无缺失、重复、边缘空白或非法ZINC格式。数值字段 qsar_predicted_pIC50、mwt、logp 均被原pandas读取为float64，无空值、非法数值或±inf/NaN。范围分别5.3415217–7.2961574、250.125–349.909、−4.819–4.01；负logP不作为非法值。

唯一全空列是可选 standardization_error（221988空），同时standardization_status全为PASS、qsar_prediction_valid全为True；记录为空的错误消息，不当作必需数据缺失。其余列空值为0。规范化SMILES无重复，stored rank为1..221988的唯一排列。

候选审计覆盖不同集合：原phase4C来源49/49候选均唯一命中快照，RDKit canonical SMILES全部相同；最终原排名47/47候选唯一命中，原pIC50与快照完全相等；实际评估10/10候选沿用原ID/SMILES和baseline score。没有将全局top5当作最终候选集合。

## 原代码兼容性

QSARTool.run按项目文件位置定位原路径，读取完整CSV后以pIC50降序取前N，返回zinc_id/pIC50/mwt/logp四列；本次实际类型/字段符合其预期，异cwd读取验证通过。原工具没有主动校验重复/NA或把全局行与最终结构候选连接，故本次单独审计，未声称代码已新增这些保证。全局有35915行处于同分组；保留原默认排序，不加入新的打破平分规则。全局pIC50排序不是生产最终候选排序。

## 实际隔离执行

独立项目：`/workspace/recovery/qsar-gzip-20261029T110249_095347Z/nonproduction-project`。

staging：`/workspace/recovery/qsar-gzip-20261029T110249_095347Z/staging`。

将原字节CSV只恢复到隔离项目预期路径。16份模型/数据/研究输入设置只读并在执行后核对摘要不变；当前正式仓库既有文件执行前后无意外变化。所有新候选报告与探索性Pareto输出位于隔离副本或本evidence，未发布为生产排名。

|步骤|实际结果|证据边界|
|---|---|---|
|原QSARTool全量读取|221988行；exit 0|读取既有预测，没有重算全局QSAR|
|原developability脚本与Pareto脚本|各exit 0，10/10候选|确定性描述符/启发式计算，无LLM|
|原baseline与10候选跨阶段对齐|PASS|直接调用原校验接口；不是Function Calling执行记录|
|10个原候选五模块新评估|10/10 CORE_COMPLETE|真实原RF + PK/ADMET/合成描述符启发式 + AD；不是实验验证|
|必要专项|34 passed，7 subtests另列，exit 0|17项真实快照/结果集成检查 + 17项既有单元/夹具测试|
|全量回归（含新集成检查）|175 passed，35 subtests另列，exit 0|原158项 + 新17项；0 FAIL、0 SKIP、0收集错误|
|正式原生Agent入口|exit 1，BLOCKED_OLLAMA|真实客户端失败，无FakeLLM|
|完整原生多目标入口|exit 1，BLOCKED_OLLAMA|快照/helper不再缺失；真实LLM连接仍失败|

10个新RF预测与快照最大绝对差 `3.57181971999e-07` pIC50，呈保存精度范围内的数值一致性；未写回原快照。此局部复现不是证明221988条历史预测都由同一字节模型生成，也不是新的模型性能评估。本轮只对10个已选原候选调用RF，未重算全库。适用域结果计数：`{"BORDERLINE": 8, "OUT_OF_DOMAIN": 2}`；域标签不是经校准可信度，CORE_COMPLETE仅表示模块执行完整。

真实RF加载无版本不匹配错误，RDKit输出Morgan旧API弃用警告已保留在stderr，不删警告、不更换模型。PK D-MPNN本轮未重跑，也未注册到生产TOOLS。

## 原生 E2E 与未独立核验事项

本轮在授权网络上下文只读检查默认 http://127.0.0.1:11434 的/api/version与/api/tags，均Connection refused；PATH无ollama、无其他端点或模型配置。两个正式入口在隔离副本实跑均退出1，失败审计/完整stderr保留。不下载模型、不改代理、不启动/公开端口。模型缓存及tool-calling能力NOT_VERIFIED。

CCO仍OUT_OF_DOMAIN；PK实验标签来源/物理单位仍未独立核验；五种子SD不是实验验证/校准CI；历史PK报告无checkpoint哈希，不能证明历史字节身份。保留这些科学边界，不因本轮数据校验或回归通过而消除。

下一步仅需可达的既有Ollama服务与准确模型名（Codex localhost不等于WSL localhost），或用户另行明确授权安装/下载所需组件。在此之前原生LLM/工具授权/Trace/报告成功链路仍BLOCKED，**不得宣布Phase0完整通过**。不再要求重新交接本次已核验CSV。

## 修改与可审查证据

本轮不改应用源码/测试套件/原helper/模型/生产排名/评分规则/.gitignore。新增本报告和evidence；4份旧验收文档只加最新状态指引，旧版保留于prior-documents。未提交或推送，未训练、docking/MD或执行Phase1–5。

证据：`phase0/evidence/qsar-gzip-20261029T110249_095347Z`。

- intake-verification.json、received-file-hashes.json：每个接收文件大小、摘要与比较。
- data-quality-audit.json、molecular-identity-audit.json：数据逐字段及逐候选核对。
- static-reader-review.json、deterministic-route.json：原代码字节、实际全库读取、确定性对齐。
- real-candidate-evaluations.json、real-candidate-reports/、rf-consistency.json：10份新真实计算结果、RF模型摘要及数值比较。
- execution/executed-commands.json、native-attempts.json：真实argv、cwd、退出码、证据类别；同目录完整stdout/stderr、JUnit和逐测试状态。
- acceptance-ledger.json：PASS/FAIL/BLOCKED/NOT_VERIFIED定义与每项依据；本轮没有自动化或数据FAIL，不隐藏运行时BLOCKED。
- preservation.json、evidence-hashes.json、change-manifest.json：输入不变、Git状态、变更和证据摘要。
