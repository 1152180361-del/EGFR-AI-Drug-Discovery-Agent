> 最新验收见 [QSAR_GZIP_ACCEPTANCE.md](QSAR_GZIP_ACCEPTANCE.md)：原全局CSV已实测核验221988行，49候选身份/47候选pIC50对齐，10候选新真实五模块成功，专项34/全量175通过；原生Ollama E2E仍BLOCKED，Phase0未完整验收。下文保留历史状态。

> 最新状态见 [QSAR_SNAPSHOT_ACCEPTANCE.md](QSAR_SNAPSHOT_ACCEPTANCE.md)：本轮CSV附件超过32 MiB传输上限，实际数据审计仍阻塞；专项21/全量158通过不代表快照或原生E2E通过，Ollama仍Connection refused。下文为保留的历史证据。

> 最新补充包结果见 [HELPERS_RECOVERY_ACCEPTANCE.md](HELPERS_RECOVERY_ACCEPTANCE.md)：两份原helper已核验恢复，独立副本确定性阶段成功、全量158通过；原生Ollama E2E及全局QSAR快照仍阻塞，Phase0未完整验收。下列缺helper描述属于历史状态。

> 本轮剩余阻塞复查见 [REMAINING_BLOCKERS_REVIEW.md](REMAINING_BLOCKERS_REVIEW.md)：原生Ollama仍不可达，两份原脚本仍未找到；下列真实推理与150项测试为已通过的基线，本轮未重跑。

# Phase 0：WSL 原资产接收与真实验证（2026-10-29，Asia/Shanghai）

**当前结论：资产接收、真实直接工具推理与全量回归通过；尚不宣布 Phase 0 完整验收。** 原生 Ollama Agent E2E 仍不可达；可选完整多目标研究流水线还缺两份原脚本。Phase 1–5 未执行。

## 1. 资产接收证据

附件 `EGFR_PHASE0_WSL_ASSETS.tar.gz`：22212170 bytes；解压后108812385 bytes。独立 `.sha256` 与实际包 SHA-256 一致。确切摘要、每个文件大小和 SHA-256 保存在 `evidence/wsl-assets-intake/intake-verification.json`。

- 23个项目文件与 transfer-metadata/asset-hashes.json 全部逐文件核对通过，无缺失、重复、未登记项目文件、路径穿越、符号/硬链接或特殊设备。
- 独立 staging 位置记在 `/workspace/recovery/latest-wsl-assets-intake.txt`；原附件、staging和元数据均保留。
- 五份脚本及报告/Trace进行了敏感模式扫描，没有命中；扫描只记录检测器、路径、行号与REDACTED，不输出候选秘密原文。未发现不等于对任意隐藏秘密的绝对证明。
- 初始仓库不存在同名资产冲突。只用排他创建恢复23条缺失路径；另外从旧交付ZIP恢复已知SHA的原 `reports/EGFR_AI_Agent_Report.md`，没有拿10月28日latest Trace顶替10月13日固定Trace。
- 五份后期原脚本、train/validation/test、五个checkpoint、决策/证据/排名CSV、SMILES映射、人工review矩阵、历史Trace与shadow JSON现均已可访问。
- 原先“缺权重/五份脚本/8项夹具”的报告是历史状态，不代表本轮恢复后状态。

新收到的模型/数据/历史证据在验证后哈希未变；原有模型、数据、报告、评分代码、忽略规则未变。唯一有意修正的收到源码是可选多目标runner的导入位置，其原字节仍保存在staging和source-before-fix备份。明细见 `post-validation-asset-hashes.json`、`restored-assets.json`、`preservation-checks.json`。

## 2. 运行时与模型兼容性

原离线venv用scikit-learn1.8.0，初次全量在加载1.9.1权重时出现2条版本警告，因此没有把那次运行视为可靠兼容性验证。随后建立独立环境，不改变系统Python或原离线环境：

|环境|实际验证|
|---|---|
|RF/AD/测试：`/workspace/egfr-rf-venv/bin/python`|Python3.11.17、sklearn1.9.1、joblib1.6.0、numpy2.4.6、pandas3.0.6、scipy1.17.1、RDKit2026.3.6|
|PK：`/workspace/egfr-pk-venv/bin/chemprop`|Chemprop2.3.1、torch2.14.1+cpu、lightning/pytorch-lightning2.6.6、pandas3.1.0；CPU推理，无CUDA|

RF包版本与收到的WSL版本记录一致；Python补丁版为3.11.17，而WSL rdkit_aidd记录3.11.16，因此不是声称逐位相同的Conda环境。PK使用同版本CPU构建，未复制WSL Conda前缀。均从受信任软件包索引安装，保留TLS校验，没有关闭签名/校验。

RF真实加载为RandomForestRegressor、300棵树、2048输入维度，无sklearn版本警告；第一棵树根节点的加权训练样本数4089，与JSON的训练数量一致（这不是独立证明原训练数据来源）。交接的train/validation/test分别3271/409/409行，均有standardized_smiles。生产RF在完整curated集训练，AD使用train子集，两者不能混称。

两个环境的冻结依赖：`requirements-rf-received.txt`、`requirements-pk-received.txt`。`install-model-runtimes.sh`已执行并重复验证，两个环境dependency check通过。初次重复安装因沙箱网络访问被拒，授权网络执行后通过；未通过关闭TLS或改变版本让安装成功。当前模型验证不应再使用旧 `/workspace/egfr-phase0-venv`。

## 3. 本次新真实推理（无mock、无固定预测、无复用历史成功）

执行：

```bash
EGFR_CHEMPROP_BIN=/workspace/egfr-pk-venv/bin/chemprop \
/workspace/egfr-rf-venv/bin/python phase0/verify_real_inference.py \
  --output-dir phase0/evidence/<新的目录>
```

脚本调用真实原模型/原五种子checkpoint，写新的时间戳与run_id，并独立复算PK均值、样本SD、反变换。最终执行证据在 `evidence/wsl-assets-real-final/`。不是经Ollama规划的完整Agent运行。

|输入/任务|本次结果|
|---|---|
|CCO RF|predicted_pIC50 = 5.859233543078105|
|Gefitinib参考SMILES RF|predicted_pIC50 = 7.5956883120158345|
|CCO五模块|OK / CORE_COMPLETE；五个模块均成功、输入身份保留；AD为OUT_OF_DOMAIN|
|Gefitinib五模块|OK / CORE_COMPLETE；五个模块均成功、输入身份保留；AD为IN_DOMAIN|
|Gefitinib五种子PK|OK；五个真实Chemprop进程成功；聚合校验通过|

PK种子预测（clint_log10）：

|seed|本次真实预测|
|---|---:|
|42|1.32226290|
|43|1.25540940|
|44|1.25872920|
|45|1.31807540|
|46|1.22484100|

log10均值 **1.27586358**；样本标准差（n−1）**0.042573462307780335**；10**mean = **18.873983889214735**，工具标注单位mL/min/g。这是log空间均值的反变换（原空间几何均值），不是原空间算术均值。

这组新预测与收到的历史shadow报告在保存精度上完全一致；不是从历史报告读入预测。五个新checkpoint的SHA各不相同且与用户提供的交接摘要一致。历史shadow JSON没有保存checkpoint哈希，所以不能独立证明历史那次使用的字节必然与当前相同。比较记录见较早本轮的 `evidence/wsl-assets-real-inference/additional-real-inference.json`；最终复跑数据见real-final。

单位/log10语义由代码及历史报告一致标注；原始实验标签/变换来源未随包提供，物理来源未独立审计。不把计算结果描述为实验验证，不把种子SD或AD标签当校准置信度。CCO域外，不能因RF有数值便推断可靠活性。Gefitinib SMILES沿用用户参考，未由权威数据库另行核验。工具输出硬编码历史test_spearman不是本轮模型性能指标；本轮未执行Phase1评估。

## 4. 回归与必要代码修复

原资产恢复后的首次旧环境测试：143 passed、1 collection error、2条sklearn版本警告。原5个收集错误中的4个已因原脚本交接解决；8项skip全部因真实夹具到位而恢复运行。

剩余错误来自 `run_egfr_multiobjective_agent.py` 顶层导入未交接的 `scripts/run_candidate_developability.py` 与 `scripts/compare_candidate_objectives.py`。这两个函数仅在可选完整run()中使用，离线授权/身份对齐测试不使用它们。

最小修复：将两条导入移动到run()授权之后、LLM/流水线及工作目录变化之前；没有实现占位函数，没有改分数/Pareto方向/生产顺序。缺原helper时实际完整run仍失败关闭。新增回归确保缺helper时不构造/调用LLM。源脚本和测试修改前副本保留，可审查补丁另列。

最终使用兼容RF环境执行：

|检查|结果|退出码|
|---|---|---|
|专项Scope/Flow/Candidate/Trace/CLI/PK/资产清单|71 passed，15 subtests passed|0|
|tests全量|150 passed，0 failed，0 skipped，0 collection errors；28 subtests passed|0|
|仓库根目录全量|150 passed，0 failed，0 skipped，0 collection errors；28 subtests passed|0|
|反序Trace/CLI/Flow/Scope|40 passed，13 subtests passed|0|

逐测试JSON/JUnit和堆栈在 `evidence/wsl-assets-regression/`，包含每个方法的结果及归类；mock测试与真实工具推理在不同证据目录，未把它们混计为真实推理。旧Trace的7项一致性检查及真实候选决策检查均实际运行通过，不是移除skip装饰器强行绕过，也没有重新写原候选排名。

`git diff --check`通过；本轮没有Git提交、推送、改仓库选择、重训、新docking或MD。PK shadow仍不在生产TOOLS，独立实际推理没有把它注册回来。

## 5. 仍为BLOCKED/未验证的项目

|项目|状态与具体证据|下一步|
|---|---|---|
|原生Ollama Agent端到端|BLOCKED：真实运行CLI退出1，默认本地端点不可达；失败审计已生成；原latest报告/Trace哈希未变。访问官方registry.ollama.ai返回ProxyError，未下载或伪造LLM模型|提供可访问的原Ollama服务/模型，或允许所需模型registry网络后安装原模型并验证工具调用。不能用FakeLLM/直接工具smoke顶替|
|可选完整多目标研究流水线|BLOCKED：还缺run_candidate_developability.py和compare_candidate_objectives.py。纯函数测试已通过不代表完整run已执行|从WSL交接这两份原脚本；先静态审查次级依赖，不伪造原科研逻辑、不运行其生产写出流程|
|PK标签物理单位/来源|未独立核验：只有代码/历史报告标注，无原标签来源|保留科学限制；按后续获准的审计范围提供原标签说明/版本元数据；不据此升级生产模型|

分别参见 `evidence/wsl-assets-intake/native-agent-e2e.json`、`ollama-availability-check.json`、`dependency-gaps.json`、`acceptance-ledger.json`。真实CLI失败不是pytest失败：自动回归全部通过，但原生Agent E2E仍BLOCKED。

环境配置草稿已更新安装/启动说明、EGFR_CHEMPROP_BIN，并仅新增registry.ollama.ai自定义域名，保留原预设；保存不等于运行时网络已生效或环境已发布，尚未把网络阻塞报告为解决。首次访问registry成功后若出现模型blob重定向，只补充实际观察到的必要域名，不放开全网。

## 6. 交付与阶段边界

- 接收/哈希/敏感扫描/冲突/恢复明细：`evidence/wsl-assets-intake/`。
- 最终真实调用JSON/Markdown与源码模型哈希：`evidence/wsl-assets-real-final/`；每个candidate结果含不可变JSON/Markdown报告路径。
- 全量及专项逐测试结果：`evidence/wsl-assets-regression/`。
- 可复用环境：`install-model-runtimes.sh`和两份冻结requirements；`install-cloud.sh`现委托此入口。
- 本轮有意代码修改：可选runner两条lazy imports、对应依赖隔离测试、真实验证脚本增加CCO/Gefitinib双输入、安装入口。恢复的五份原研究脚本另计为资产恢复，不声称均由本轮编写。
- 下一步仅恢复剩余原生E2E及必要依赖，复核完整验收条件。Phase1–5规划保留，未经确认不执行。

**自动测试与本次直接真实推理均通过，不等于完整Phase0已经验收。**
