> 最新验收见 [QSAR_GZIP_ACCEPTANCE.md](QSAR_GZIP_ACCEPTANCE.md)：原全局CSV已实测核验221988行，49候选身份/47候选pIC50对齐，10候选新真实五模块成功，专项34/全量175通过；原生Ollama E2E仍BLOCKED，Phase0未完整验收。下文保留历史状态。

> 最新状态见 [QSAR_SNAPSHOT_ACCEPTANCE.md](QSAR_SNAPSHOT_ACCEPTANCE.md)：本轮CSV附件超过32 MiB传输上限，实际数据审计仍阻塞；专项21/全量158通过不代表快照或原生E2E通过，Ollama仍Connection refused。下文为保留的历史证据。

> 最新补充包结果见 [HELPERS_RECOVERY_ACCEPTANCE.md](HELPERS_RECOVERY_ACCEPTANCE.md)：两份原helper已核验恢复，独立副本确定性阶段成功、全量158通过；原生Ollama E2E及全局QSAR快照仍阻塞，Phase0未完整验收。下列缺helper描述属于历史状态。

> 本轮剩余阻塞复查见 [REMAINING_BLOCKERS_REVIEW.md](REMAINING_BLOCKERS_REVIEW.md)：原生Ollama仍不可达，两份原脚本仍未找到；下列真实推理与150项测试为已通过的基线，本轮未重跑。

> 最新资产接收后的结论见 [WSL_ASSETS_ACCEPTANCE.md](WSL_ASSETS_ACCEPTANCE.md)：本次全量150通过、真实RF/五种子PK/五模块均成功；原生Ollama Agent E2E仍BLOCKED，尚未完整验收。以下为交接前历史记录。

# Phase 0 当前验收报告（2026-10-29，Asia/Shanghai）

**结论：未达到完整验收条件。** 工作区可访问，本轮修复生产 PK shadow 隔离；真实 RF、PK 五种子与完整五模块推理仍被 Codex 中缺失原资产阻塞。WSL 的文件存在情况仅来自用户报告，不与 Codex 共享路径。本轮没有提交、推送、改变仓库选择、训练模型、启动 docking 或改写生产排名与研究结论。

## 本轮开始状态与保存

正式目录 `/workspace/EGFR-AI-Drug-Discovery-Agent`，分支 `work`，HEAD `2016d6ba4394001e238715764698f1379f61e04b`，远端 `github.com/1152180361-del/EGFR-AI-Drug-Discovery-Agent.git`。开始时已有未提交的前轮修复和恢复文件，本轮保留全部内容。

开始前保存了所有现存源码/文档/报告的 SHA-256、Git diff、状态和本轮将修改文件的原副本：路径记在 `/workspace/recovery/phase0-latest-audit-dir.txt`。原交付包、补丁、PPT 恢复归档和 EGFR 原干净 checkout 归档仍保留。

## 有证据支持的修复

发现 PKDMPNNTool 模块说明宣称“未注册到生产 Agent”，但实际生产 `egfr_agent/tool_registry.py::TOOLS` 含 `pk_dmpnn_prediction`，旧测试要求它注册，构成代码/文档/隔离要求不一致。

- 移除生产注册表的 shadow 实例及共享 tools 包的隐式导出。独立 `egfr_agent.tools.pk_dmpnn_tool.PKDMPNNTool` 未修改，可由 shadow 脚本直接使用。
- `EGFRFunctionCaller` 保留 shadow Schema/授权解析，供显式构造的隔离调用者使用；生产注册表不含该工具，生产请求在任何 LLM/工具调用前失败关闭。五模块组合不包含 D-MPNN，不隐式扩大权限。
- 将旧注册测试改为严格检查不存在生产实例，新增调用前拒绝及组合列表隔离测试。这是按本次隔离要求加强约束，未放宽科学断言。
- 增加 PK 的样本 SD（n−1）核算断言、反变换溢出失败、部分种子结果不能返回 OK 的测试。测试中的临时 mock checkpoint/输出仅用于逻辑回归，不属于真实资产或科学结果；没有向真实模型路径写入任何模拟权重。
- 新增只读资产/哈希审计脚本与真实推理尝试脚本；回归 runner 改为新目录保存 JUnit 和逐测试分类，不覆盖旧测试证据。

## 实际回归

|本次运行|结果|底层退出码|
|---|---|---|
|专项 Scope / Flow / Candidate / Trace / CLI / PK / 资产清单|71 passed，15 subtests passed|0|
|tests/ 全量|104 passed，1 failed，8 skipped，5 collection errors；23 subtests passed|1|
|仓库根目录全量|104 passed，1 failed，8 skipped，5 collection errors；23 subtests passed|1|
|Trace / CLI / Flow / Scope 反序|40 passed，13 subtests passed|0|

Python 3.12.14，独立 `/workspace/egfr-phase0-venv`；pip check 通过。此环境不是用户 WSL Python/Miniforge 环境。子测试不并入测试方法数。

本次 `evidence/acceptance-final/regression/full-final-cases.json` 包含 **118 条逐项记录**：104 passed、1 failed、8 skipped、5 errors，并为每项记录归类及建议。原始 JUnit/XML、堆栈和底层命令同时保存。外层 runner 退出 1；没有将环境失败变成 PASS。

### 仍存在的失败与分类

|未通过项|分类与证据|处理方式|
|---|---|---|
|TestQSARInferenceTool.test_valid_smiles_prediction|环境/资产缺失：RF joblib 不存在|提供原模型和可信哈希/版本后重跑，不重训代替|
|5 个测试收集错误|源码交接不完整：缺后期研究脚本|恢复原实现；不按测试中的少量输出伪造研究模块|
|7 项历史 Trace 一致性 skip|研究 fixture 缺失；另有旧 Trace 配 latest 报告的过期配对风险|补同次运行 Trace/报告/CSV，再验证配对并审查测试|
|1 项真实候选决策 skip|研究证据 CSV 缺失|补原始候选证据；当前不能声称真实排序已复现|

5 个缺失模块：`scripts/integrate_admet_ai_multiobjective_v1.py`、`run_egfr_admet_multiobjective_agent.py`、`run_egfr_multiobjective_agent.py`、`audit_pareto_robustness.py`、`build_egfr_final_decision_report.py`（均在 scripts/）。其中 final report 测试首先在导入 audit_pareto_robustness 时失败；其第二个导入同样缺失。详细 node ID 见逐项 JSON。

## 模型资产核验：当前 Codex

完整清单：`evidence/acceptance-final/asset-inventory.json`，精确 checkpoint 路径与用户给定预期尺寸均已记录。

|资产|当前结果|哈希/历史匹配|
|---|---|---|
|RF joblib（用户 WSL：105455297 bytes）|正式 checkout 缺失|无法计算 SHA-256；用户尚未提供权重参考哈希|
|RF JSON metadata|正式 checkout 缺失；旧交接副本两处可访问|两份均 1031 bytes，SHA-256 `6d402eece4354085a4a8a6f614f9c31733abe8e2fc52df0507503463ccaeb20e`，与上传快照记录一致；它不是权重哈希|
|五个固定 seed 42–46 checkpoint（用户 WSL：各286979 bytes）|五个均不在当前工作区|无法计算或与历史比对；同尺寸不证明五种子身份|
|egfr_train.csv|缺失|无法验证适用域参考集|
|历史 PK JSON `EGFR_PK_DMPNN_shadow_20261028T173741_666852Z.json`|当前不可访问|未核实历史五种子结果、权重哈希或运行版本，不复用为本次结果|
|Chemprop|默认 `/home/agent/miniforge3/envs/admet_ai/bin/chemprop` 缺失，PATH 无 chemprop|当前没有测得2.3.1；2.3.1是用户的WSL报告|
|WSL路径|`/home/xie/EGFR_AIDD_Pipeline`、`/home/xie/miniforge3/envs/admet_ai/bin/chemprop` 在本机不存在|不推断WSL本地不存在|
|Ollama|PATH无可执行程序，未配置专用模型/端点|完整 Agent E2E 不可据离线测试验收|

没有复制一个 JSON sidecar 来假装 RF 资产完整，也没有创建虚假模型文件。大小、文件存在和 SHA-256 匹配是不同结论；没有可信权重摘要时，不报告“已匹配”。资产审计没有反序列化模型。

## 本次真实工具调用

所有记录是本次新生成，不使用 mock 或固定预测值，也不重用历史成功报告。命令及新时间戳见 `evidence/acceptance-final/commands.json`，实际日志和 JSON 在 `evidence/acceptance-final/real-inference/`。

|要求|实际结果|是否完成真实模型推理|
|---|---|---|
|Gefitinib 五种子 PK|ERROR，环境检查报告 Chemprop executable 不可用；独立清单同时报告五个 checkpoint 缺失|否，未产生各种子预测、均值或 SD|
|CCO RF smoke|ERROR，Missing QSAR model|否，没有模型加载或真实预测值；仅生成失败审计报告|
|Gefitinib 五模块组合|PARTIAL：PK/ADMET/合成描述符成功，RF 和 AD 失败|完整评估未完成；成功部分是描述符计算，不是模型/实验验证|

PK 代码聚合使用五个 log10 值的算术均值、样本 SD，然后 10**mean（原单位的几何均值，非五个原单位预测的算术均值）。上述公式和失败行为有单元测试；**实际 checkpoint 的标签变换和 mL/min/g 单位来源尚未验证**，不能只依据代码返回的 unit 字符串宣布正确。

Gefitinib 参考 SMILES 沿用前轮，未在本轮通过权威数据库独立核验。QSAR 返回的历史 scaffold-aware/0.8439 是硬编码元数据，不是本轮性能结果。即使补齐权重并推理成功，也只能报告计算预测，不能宣称实验活性。

## 代码/文档/报告一致性边界

本轮核心权限、SMILES token 与输出身份、参数整批预检、组合工具状态、Trace 归档、CLI 故障与历史不覆盖测试均执行。原报告与 Trace 仍各自保留不可变路径，latest 文件并非跨文件事务；历史 fixture 未补齐，不能用当前单元测试代替历史研究一致性。

架构文档已修正 shadow 入口与生产注册表之间的关系。旧 STATUS.md/RESUMED_STATUS.md 的计数保留为历史，当前以本文件和新证据目录为准。没有在本轮更改生产评分代码或判断历史研究指标真伪。

## 验收条件逐项结论

- 已完成：本次可访问性/分支/未提交工作检查；生产 shadow 隔离修复；相关回归；逐测试分类；资产清单、可计算的 metadata 哈希和交付整理。
- 测试通过但科学验证未完成：PK 五种子聚合与异常处理、权限/身份/Trace 逻辑；通过含 mock 的单元测试不等于真实预测验证。
- 外部阻塞：原 RF/PK 权重、训练/研究 CSV、后期脚本、历史报告及 Chemprop/Ollama环境。
- 仍失败：1 失败、5 收集错误、8 跳过，均未删除或无条件跳过。
- Phase 0：**不通过完整验收**。需按 ASSET_TRANSFER_AND_NEXT_STEPS.md 补齐原资产后继续。
- Phase 1–5：保留 PROJECT_ROADMAP.md 与 PHASE1_PLAN_DRAFT.md；未执行。后续依次为模型评估可信度、受控多步骤架构、领域RAG、生成/多目标筛选、实验反馈；每阶段需用户确认，生产升级须另列风险与回滚。
