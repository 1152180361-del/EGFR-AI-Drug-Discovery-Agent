from pathlib import Path
import json,os,subprocess,datetime,shutil
import requests
s=json.loads(Path('/workspace/recovery/latest-toolfix.json').read_text());iso=Path(s['isolated_project']);e=Path(s['evidence'])/'final-run';(e/'native-audits').mkdir(exist_ok=True)
check={'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'endpoint':'http://127.0.0.1:11434','requested_model':'qwen2.5:7b','ollama_binary':shutil.which('ollama'),'service_checks':{},'model_downloaded':False,'proxy_configuration_changed':False,'public_service_exposed':False}
for suffix in ('/api/version','/api/tags'):
 try:
  resp=requests.get(check['endpoint']+suffix,timeout=8);item={'status':'PASS' if resp.ok else 'BLOCKED','http_status':resp.status_code}
  if resp.ok:
   data=resp.json()
   if suffix.endswith('tags'):item['requested_model_present']=any(x.get('name')=='qwen2.5:7b' for x in data.get('models',[]))
   else:item['version']=data.get('version')
  check['service_checks'][suffix]=item
 except requests.RequestException as ex:check['service_checks'][suffix]={'status':'BLOCKED','error_type':type(ex).__name__,'connection_refused':'Connection refused' in str(ex),'operation_not_permitted':'Operation not permitted' in str(ex)}
(e/'ollama-availability.json').write_text(json.dumps(check,indent=2)+'\n');print(json.dumps(check,indent=2),flush=True)
script=e/'native_function_calling_check.py'
script.write_text('''from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from egfr_agent.function_calling import EGFRFunctionCaller
from egfr_agent.tool_registry import TOOLS
s=json.loads(Path('/workspace/recovery/latest-toolfix.json').read_text());e=Path(s['evidence'])/'final-run';records=[]
queries=['Analyze EGFR QSAR activity and docking evidence for existing candidates','Do not predict SMILES: CCO and analyze docking poses','不要预测SMILES: CCO，同时分析 docking poses']
for i,query in enumerate(queries):
 caller=EGFRFunctionCaller(TOOLS)
 try:
  result=caller.run(query)
  records.append({'query':query,'status':'PASS_REAL_NATIVE_FUNCTION_CALLING','executed_tools':result['executed_tools']})
 except Exception as exc:
  status='BLOCKED_OLLAMA' if 'Ollama connection failed' in str(exc) else 'FAIL_REAL_NATIVE_FUNCTION_CALLING'
  records.append({'query':query,'status':status,'error_type':type(exc).__name__,'error':str(exc)})
 (e/'native-audits'/f'function-calling-{i+1}.json').write_text(json.dumps(caller.last_audit,indent=2,ensure_ascii=False)+'\\n')
(e/'native-function-calling-results.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\\n')
print(json.dumps(records,indent=2,ensure_ascii=False))
raise SystemExit(0 if all(x['status']=='PASS_REAL_NATIVE_FUNCTION_CALLING' for x in records) else 1)
''')
py='/workspace/egfr-rf-venv/bin/python';env={**os.environ,'OLLAMA_API_BASE':'http://127.0.0.1:11434','OLLAMA_MODEL':'qwen2.5:7b','EGFR_CHEMPROP_BIN':'/workspace/egfr-pk-venv/bin/chemprop','PYTHONPATH':str(iso)}
records=[]
for name,cmd in [('native-function-calling',[py,str(script)]),('native-agent',[py,'-m','egfr_agent.run_agent']),('native-multiobjective',[py,'scripts/run_egfr_multiobjective_agent.py'])]:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:p=subprocess.run(cmd,cwd=iso,capture_output=True,text=True,timeout=180,env=env);code=p.returncode;out=p.stdout;err=p.stderr
 except subprocess.TimeoutExpired as ex:code=124;out=(ex.stdout or b'').decode(errors='replace') if isinstance(ex.stdout,bytes) else (ex.stdout or '');err='Native command exceeded 180s process deadline; NOT success.\n'
 (e/'execution'/f'{name}.stdout.log').write_text(out);(e/'execution'/f'{name}.stderr.log').write_text(err)
 status='BLOCKED_OLLAMA' if 'Ollama connection failed' in out+err else ('SUCCESS_REQUIRES_TRACE_REVIEW' if code==0 else 'FAIL_OR_TIMEOUT_REQUIRES_REVIEW')
 records.append({'name':name,'argv':cmd,'cwd':str(iso),'environment_overrides':{k:env[k] for k in ('OLLAMA_API_BASE','OLLAMA_MODEL','EGFR_CHEMPROP_BIN')},'started_utc':start,'exit_code':code,'status':status,'fake_llm_used':False,'direct_tool_substitute_used':False,'stdout':str(e/'execution'/f'{name}.stdout.log'),'stderr':str(e/'execution'/f'{name}.stderr.log')})
 (e/'execution/native-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,code,status,flush=True)
for p in (iso/'reports/failures').glob('*.json'):shutil.copy2(p,e/'native-audits'/p.name)
