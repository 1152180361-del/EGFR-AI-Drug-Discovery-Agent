from pathlib import Path
import json,hashlib,difflib,subprocess,shutil,datetime,xml.etree.ElementTree as ET
s=json.loads(Path('/workspace/recovery/latest-toolfix.json').read_text());r=Path(s['root']);e=Path(s['evidence']);b=Path(s['base']);iso=Path(s['isolated_project']);f=e/'final-run'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as src:
  for c in iter(lambda:src.read(1048576),b''):h.update(c)
 return h.hexdigest()
def write(n,x):(e/n).write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
before=json.loads((b/'preexisting-hashes.json').read_text())
source_files=['egfr_agent/tool_scope.py','egfr_agent/function_calling.py','egfr_agent/run_agent.py','scripts/run_egfr_multiobjective_agent.py','tests/test_agent_flow_v2.py']
new_tests=['tests/test_scope_operation_boundaries.py','tests/test_function_calling_argument_recovery.py']
# Retrieve pre-turn runner original from the preserved prior project, never HEAD.
prior=Path(json.loads(Path('/workspace/recovery/latest-qsar-gzip.json').read_text())['isolated_project'])/'scripts/run_egfr_multiobjective_agent.py'
assert sha(prior)==before['scripts/run_egfr_multiobjective_agent.py'];shutil.copy2(prior,e/'before/scripts__run_egfr_multiobjective_agent.py')
backup={
 'egfr_agent/tool_scope.py':e/'before/tool_scope.py',
 'egfr_agent/function_calling.py':e/'before/function_calling.py',
 'egfr_agent/run_agent.py':e/'before/run_agent.py',
 'scripts/run_egfr_multiobjective_agent.py':e/'before/scripts__run_egfr_multiobjective_agent.py',
 'tests/test_agent_flow_v2.py':e/'before/tests__test_agent_flow_v2.py',
}
patch=[];changes=[]
for name in source_files:
 old=backup[name];assert sha(old)==before[name];assert sha(r/name)==sha(iso/name)
 patch.extend(difflib.unified_diff(old.read_text().splitlines(True),(r/name).read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 changes.append({'path':name,'before_sha256':sha(old),'after_sha256':sha(r/name),'backup':str(old.relative_to(r))})
for name in new_tests:
 patch.extend(difflib.unified_diff([],(r/name).read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+name))
 changes.append({'path':name,'before_sha256':None,'after_sha256':sha(r/name),'new':True})
(e/'this-turn-source.patch').write_text(''.join(patch))
(e/'git-diff-all-preexisting-and-current.patch').write_text(subprocess.check_output(['git','diff','--binary'],cwd=r,text=True))
write('source-change-hashes.json',changes)
old=json.loads((r/'phase0/evidence/helpers-recovery-20261029T090615Z/execution/full-isolated-regression-cases.json').read_text());classification={(x['classname'],x['name']):x.get('test_evidence_kind') for x in old}
summary={}
for name,subtests in [('targeted',15),('full',35)]:
 tree=ET.parse(f/'execution'/f'{name}.xml');cases=[]
 for t in tree.findall('.//testcase'):
  cls=t.get('classname');n=t.get('name');status=next((label for tag,label in [('failure','FAIL'),('error','ERROR'),('skipped','SKIP')] if t.find(tag) is not None),'PASS')
  kind=('deterministic_authorization_unit' if 'test_scope_operation_boundaries' in cls else 'scripted_LLM_parameter_recovery_unit_not_native' if 'test_function_calling_argument_recovery' in cls else classification.get((cls,n),'automated_regression_mixed_fixtures_not_native_E2E'))
  cases.append({'classname':cls,'name':n,'status':status,'seconds':t.get('time'),'evidence_kind':kind,'native_llm_executed':False,'detail':next((x.text for x in t if x.tag in ('failure','error','skipped')),None)})
 write('final-run/execution/'+name+'-cases.json',cases)
 summary[name]={'passed':sum(x['status']=='PASS' for x in cases),'failed':sum(x['status']=='FAIL' for x in cases),'skipped':sum(x['status']=='SKIP' for x in cases),'collection_or_test_errors':sum(x['status']=='ERROR' for x in cases),'subtests_passed_separate':subtests,'exit_code':0}
write('test-summary.json',summary)
# Preserve unsuccessful authoring/intermediate runs as history, not current failures.
history=[]
for p in [e/'execution/before-fix.xml',e/'execution/baseline-reproduced.xml',e/'execution/first-fix.xml',e/'execution/focused-current.xml',e/'execution/expanded-focused.xml',e/'execution/targeted.xml',e/'execution/full.xml']:
 tree=ET.parse(p);tc=tree.findall('.//testcase');history.append({'file':str(p.relative_to(e)),'passed':sum(not any(t.find(k) is not None for k in ('failure','error','skipped')) for t in tc),'failed':sum(t.find('failure') is not None for t in tc),'errors':sum(t.find('error') is not None for t in tc),'historical_not_final':True})
write('test-history.json',history)
inputs=json.loads((e/'isolated-input-hashes-before.json').read_text());input_changes=[p for p,h in inputs.items() if not (iso/p).is_file() or sha(iso/p)!=h];assert not input_changes
# Native attempts must be failures with zero tool execution, not disguised successes.
native=json.loads((f/'execution/native-commands.json').read_text());assert len(native)==3 and all(x['exit_code']==1 and x['status']=='BLOCKED_OLLAMA' for x in native)
for p in (f/'native-audits').glob('*.json'):
 d=json.loads(p.read_text());audit=d.get('function_calling_audit',d)
 assert audit['status']=='failed' and not audit['executed_tools']
 assert any(x.get('event')=='model_request' and x.get('status')=='failed' for x in audit['call_log'])
write('trace-report-review.json',{'automated_retry_success_trace_test':'PASS_UNIT_SCRIPTED_MODEL','real_native_function_calling_queries_attempted':3,'real_formal_entries_attempted':2,'real_native_success_trace_report_consistency':'NOT_VERIFIED','reason':'all attempts failed to connect before tool execution','failure_audit_model_request_and_terminal_status_present':True,'original_isolated_input_reports_unchanged':not input_changes,'new_native_success_reports_generated':False})
ledger=[
 {'item':'WSL review snapshot internal hashes and per-file comparison','status':'PASS','kind':'asset_review','evidence':'snapshot-comparison.json','note':'25 files verified, 15 same and 10 differ; no snapshot replacement'},
 {'item':'English/Chinese negation operation boundaries','status':'PASS','kind':'deterministic_authorization_and_scripted_tests','evidence':'behavior-before-after.json'},
 {'item':'strict argument validation with bounded retry, batch atomicity, original SMILES, duplicates','status':'PASS','kind':'scripted_LLM_automated_tests_not_native','evidence':'final-run/execution/targeted-cases.json'},
 {'item':'final targeted automated tests','status':'PASS','kind':'automated','counts':summary['targeted']},
 {'item':'final full automated tests','status':'PASS','kind':'automated','counts':summary['full']},
 {'item':'true Ollama Function Calling at specified endpoint/model','status':'BLOCKED','kind':'real_native_attempt','reason':'Connection refused at 127.0.0.1:11434','evidence':'final-run/native-function-calling-results.json'},
 {'item':'python -m egfr_agent.run_agent','status':'BLOCKED','kind':'real_formal_entry','exit_code':1,'evidence':'final-run/execution/native-agent.stderr.log'},
 {'item':'python scripts/run_egfr_multiobjective_agent.py','status':'BLOCKED','kind':'real_formal_entry','exit_code':1,'evidence':'final-run/execution/native-multiobjective.stderr.log'},
 {'item':'real qwen2.5:7b parameter correction and successful native Trace/report consistency','status':'NOT_VERIFIED','kind':'real_native_success','reason':'no service connection; scripted model success is not native proof'},
 {'item':'existing RF/PK/full-snapshot scientific verification','status':'PASS','kind':'inherited_prior_evidence_not_new_inference_this_turn','evidence':'../../QSAR_GZIP_ACCEPTANCE.md','note':'preserved prior result boundaries; not full scientific/experimental validation'},
 {'item':'PK label experimental origin and physical units, calibrated SD, historical checkpoint identity','status':'NOT_VERIFIED','kind':'scientific_provenance','reason':'existing missing independent evidence unchanged'},
 {'item':'overall Phase0 acceptance','status':'BLOCKED','kind':'acceptance','reason':'native Function Calling / formal entry success still not established'}]
write('acceptance-ledger.json',{'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'final_automated_failures':0,'final_automated_skips':0,'status_definitions':{'PASS':'specified executed check passed within stated evidence boundary','FAIL':'executed assertion/entry failed its requirement; earlier test failures retained in test-history, none in final regression','SKIP':'intentionally unexecuted test; zero in final pytest','BLOCKED':'required real execution cannot complete due to runtime condition','NOT_VERIFIED':'not independently established'},'items':ledger})
(e/'prior-documents').mkdir()
for name in ('CURRENT_ACCEPTANCE.md','WSL_ASSETS_ACCEPTANCE.md','QSAR_GZIP_ACCEPTANCE.md'):shutil.copy2(r/'phase0'/name,e/'prior-documents'/name)
report=f'''# Phase 0：否定授权范围与原生参数纠错修复

2026-10-29（Asia/Shanghai）。**代码回归通过；Phase 0 尚未完整验收。** 指定 Ollama `http://127.0.0.1:11434` / `qwen2.5:7b` 在当前 Codex 工作区仍 Connection refused，真实原生 Function Calling 和两个正式入口全部 BLOCKED。WSL运行记录不等于本云端服务可达。

## 接收与保护

附件 ZIP 53256 bytes；实测 SHA-256 `{json.loads((e/'zip-intake.json').read_text())['archive_sha256']}`。未提供独立外部ZIP摘要，因此这里只给出实测值；包内25个源码/测试文件的大小和SHA均匹配manifest。安全路径/链接检查通过，敏感模式扫描0命中（不声称任意秘密均已证明不存在）。5源码+20测试中15与当前相同、10不同，逐项记录于snapshot-comparison.json，完整差异见snapshot-vs-current.diff。附件和staging均保留，没有整包覆盖。

尤其WSL快照仍注册PK D-MPNN，SMILES防护弱于当前云端；这些内容均未回退。当前分支work、HEAD2016d6ba4394001e238715764698f1379f61e04b，沿用既有未提交工作；没有reset/clean/提交/推送。

修改计划先记录于phase0/TOOLFIX_PLAN.md，再实现以下范围；多目标入口补失败审计是同一审计需求的必要小改，不涉及其评分/Pareto流程。

## 本轮实际源码/测试修改

|文件|原因与行为|
|---|---|
|egfr_agent/tool_scope.py|按显式操作分句识别否定，保护SMILES的盐点/括号/立体和键符号，保留独立肯定命令；裸否定列表继承否定，同能力明确否定优先；中英文generic SMILES预测纳入QSAR拒绝；肯定/否定能力别名一致|
|egfr_agent/function_calling.py|schema错误全批拒绝且不丢参数，至多2次参数重提示，保留6轮总预算；每轮从原始用户请求重解授权与SMILES；越权/分子替换立即失败；防重复；逐轮请求/响应、拒绝/重试、实际执行尝试、最终状态审计|
|egfr_agent/run_agent.py|既有唯一命名失败报告保存附带Function Calling审计；保留原异常类型和exit1|
|scripts/run_egfr_multiobjective_agent.py|仅命令行最外层复用失败审计并重新抛出原异常；审计保存失败也保留原异常；原run()评分和科学计算不变|
|tests/test_agent_flow_v2.py|两项非法参数夹具扩为穷尽2次纠错预算，仍断言0执行；通过真实executed事件核对参数而非假定日志末项|
|tests/test_scope_operation_boundaries.py（新增）|47项中英/否定列表/分句/别名/SMILES边界回归|
|tests/test_function_calling_argument_recovery.py（新增）|21项脚本响应回归：整批原子性、预算、越权、原输入、重复、Trace及失败审计；不是真实LLM|

不修改工具注册表、生产评分、原排名、模型权重、checkpoint、全局CSV或.gitignore；未重算全库预测。只在隔离副本执行真实入口，研究/成功报告不作为写入目标。没有训练、docking/MD或Phase1–5。

## 修复前后授权与参数行为

|情景|修复前实际证据|修复后|
|---|---|---|
|英文 Do not predict SMILES...and analyze docking|WSL拒绝全部；云端旧版反而只授权live QSAR并误排除结构，是安全缺陷|仅structure_analysis；两类QSAR均禁止，explicit_qsar_exclusion=true|
|中文 不要预测SMILES...同时分析 docking|WSL拒绝全部；云端旧版偶然结构only但没有识别显式QSAR否定|结构only且显式QSAR禁止，不依赖偶然关键词遗漏|
|No QSAR and docking poses|整项否定|继续整项否定，不把裸列表作为肯定|
|qsar_prediction带smiles/toolchain|立即参数错误退出|严格拒绝整个批次、最多重提示2次；模型给合法空对象后才执行；不静默丢键|
|超过重试限额|无纠错机会|第3次非法批次明确失败、0执行，完整失败审计|
|重试中越权/替换SMILES|既有fail-closed|继续立即失败；校验依据始终是原始user_request，不能从模型/纠错历史新增授权|
|重复工具|不重复执行|同批和跨重试均最多执行一次，保留duplicate_blocked事件|

审计中的executed_tools表示结果已验证的工具；attempted_tools另记录实际开始但结果拒绝的尝试，避免把失败工具误报为从未调用。

## 实际测试与真实运行

隔离项目 `{iso}`，复制当前源码、原模型/数据/证据和此前SHA核验的完整221988行快照。所有已有科学输入执行后哈希不变；没有小表替换快照。新否定/纠错测试明确使用脚本化模型和测试夹具，不计为真实推理或E2E。

|最终执行|结果|退出码|
|---|---|---:|
|专项授权/纠错/Flow/候选/PK隔离/CLI失败/Trace|127 passed；15 subtests另列；0 FAIL/SKIP/ERROR|0|
|项目根完整回归|226 passed；35 subtests另列；0 FAIL、0 SKIP、0收集错误|0|
|真实Ollama Function Calling：全局请求及中英否定请求3项|3项均Connection refused，BLOCKED|检查脚本1|
|python -m egfr_agent.run_agent|BLOCKED_OLLAMA；失败审计含逐轮真实请求|1|
|python scripts/run_egfr_multiobjective_agent.py|BLOCKED_OLLAMA；完整失败审计及原始异常堆栈|1|

226为原158项+新增68项。本轮没有再做十候选/五种子科学复验；先前真实模型证据继续保留。原套件内真实资产测试和mock单元测试均如实归类，不能从全绿推导模型或LLM科学能力。

历史运行全部保留：新增测试第一次因pytest保留参数名request出现1个收集错误，改名query后修复；修复前复现38 FAIL/12 PASS；首版修改4 FAIL/77 PASS，其中1个分句末尾句号被SMILES遮蔽、3个为旧单元夹具的立即失败/末日志假设，分别修复并保留严格零执行/身份断言。后续109、122及最终127专项通过；中间221全量及最终226全量通过。test-history.json和原始JUnit/日志不删。当前未遗留这些失败或收集错误。

## Trace、报告及验收边界

最终真实原生检查没有FakeLLM、没有直接工具输出替代模型调用。只读/api/version及/api/tags均Connection refused，PATH无ollama，模型缓存/工具调用能力NOT_VERIFIED。没有下载、修改代理或公开服务端口。

失败审计含scope_resolved、真实model_request（failed）、function_calling_finished（failed），执行工具为空、trusted_decision_generated=false。两个正式入口均未产生本轮成功报告；隔离原成功报告/固定Trace以及正式项目的模型/排名/历史报告字节不变。自动化“纠错后成功Trace”测试通过，但真实成功Trace/报告一致性、qwen真实参数纠错仍NOT_VERIFIED。

CCO仍OUT_OF_DOMAIN；PK实验标签来源/单位、SD校准及历史checkpoint字节身份未独立核验；不因本次控制流修复而升级科学结论。原PK shadow继续不在生产注册表。

**验收结论：Phase0仍BLOCKED。** 下一步需要当前Codex可访问的既有Ollama服务及qwen2.5:7b，或用户另行授权安装/下载和相应安全连接方案；不自行公开WSL服务。接通后复跑本目录保存的真实命令并核对实际纠错、Trace/报告；不重新恢复helper或重新交接已核验CSV。

## 证据与差异

证据目录：`{e.relative_to(r)}`。

- final-run/execution/commands.json、native-commands.json：最终真实argv/cwd/env覆盖/退出码；同目录分离保存完整stdout、stderr和JUnit。
- final-run/execution/full-cases.json：226项逐测试状态、证据类别；test-summary.json统计。
- final-run/native-audits/：真实Function Calling失败审计与两个正式入口失败文件；不包装成成功Trace。
- this-turn-source.patch：只含本轮源码/测试差异，基于修改前备份；git-diff-all-preexisting-and-current.patch包含用户原有修改，不应混为本轮改动。
- snapshot-comparison.json、behavior-before-after.json、source-change-hashes.json、preservation.json：逐文件对比、修复前后行为与不变性证明。
- acceptance-ledger.json、change-manifest.json、evidence-hashes.json：验收台账、实际修改清单、证据SHA。

修复前副本、WSL原件、已有交付包和研究证据均保留。回滚只应逆转this-turn-source.patch，不能reset到HEAD丢弃既有工作。
'''
(r/'phase0/TOOLFIX_ACCEPTANCE.md').write_text(report)
for name in ('CURRENT_ACCEPTANCE.md','WSL_ASSETS_ACCEPTANCE.md','QSAR_GZIP_ACCEPTANCE.md'):
 p=r/'phase0'/name;p.write_text('> 最新修复见 [TOOLFIX_ACCEPTANCE.md](TOOLFIX_ACCEPTANCE.md)：否定分句与有限参数纠错回归通过，最终专项127/全量226通过；真实Ollama Function Calling及两个入口仍Connection refused/exit1，Phase0未完整验收。下文为保留历史证据。\n\n'+p.read_text())
allowed=set(source_files)|{'phase0/'+p for p in ('CURRENT_ACCEPTANCE.md','WSL_ASSETS_ACCEPTANCE.md','QSAR_GZIP_ACCEPTANCE.md')};actual=[p for p,h in before.items() if (r/p).exists() and sha(r/p)!=h];deleted=[p for p in before if not (r/p).exists()];assert set(actual)==allowed and not deleted,(actual,deleted)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=r,text=True).strip();assert head=='2016d6ba4394001e238715764698f1379f61e04b' and not staged
proc=subprocess.run(['git','diff','--check'],cwd=r,capture_output=True,text=True);assert proc.returncode==0
(e/'final-run/execution/git-diff-check.stdout.log').write_text(proc.stdout);(e/'final-run/execution/git-diff-check.stderr.log').write_text(proc.stderr)
registry=subprocess.run(['/workspace/egfr-rf-venv/bin/python','-c','from egfr_agent.tool_registry import TOOLS; print(list(TOOLS)); assert "pk_dmpnn_prediction" not in TOOLS'],cwd=iso,capture_output=True,text=True);assert registry.returncode==0
write('preservation.json',{'existing_files_modified':actual,'existing_files_deleted':deleted,'modified_files_exactly_within_plan_and_status_docs':True,'scientific_inputs_changed':input_changes,'isolated_original_inputs_checked':len(inputs),'formal_models_scores_rankings_reports_and_snapshot_unchanged':True,'pk_shadow_absent_from_production_registry':True,'git_head':head,'staged_changes':False,'git_diff_check_exit_code':proc.returncode,'tested_final_sources_match_current':True})
(e/'verification').mkdir()
for name in ('create_toolfix_tests.py','prepare_and_test_toolfix.py','run_toolfix_native.py','final_test_toolfix.py','run_toolfix_native_final.py','finalize_toolfix_delivery.py'):
 shutil.copy2(Path('/tmp')/name,e/'verification'/name)
write('change-manifest.json',{'modified_existing_files':actual,'new_source_tests':new_tests,'new_documents':['phase0/TOOLFIX_PLAN.md','phase0/TOOLFIX_ACCEPTANCE.md'],'new_evidence_directory':str(e.relative_to(r)),'source_changes':changes,'no_production_scientific_changes':True})
write('evidence-hashes.json',{str(p.relative_to(e)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(e.rglob('*')) if p.is_file() and p.name!='evidence-hashes.json'})
print(json.dumps({'report':str(r/'phase0/TOOLFIX_ACCEPTANCE.md'),'evidence':str(e),'final_tests':summary,'native_exit_codes':[x['exit_code'] for x in native],'modified_existing':actual,'scientific_assets_unchanged':not input_changes},indent=2))
