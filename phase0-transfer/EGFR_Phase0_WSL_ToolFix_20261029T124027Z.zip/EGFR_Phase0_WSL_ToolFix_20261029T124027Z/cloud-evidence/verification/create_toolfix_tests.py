from pathlib import Path
import json,shutil
s=json.loads(Path('/workspace/recovery/latest-toolfix.json').read_text());r=Path(s['root']);e=Path(s['evidence'])
(r/'phase0/TOOLFIX_PLAN.md').write_text('''# Phase 0 tool scope / argument recovery plan

2026-10-29. Scope confirmed against current dirty worktree, not the WSL snapshot as replacement source. All 25 incoming source/test hashes verified; 15 equal and 10 differ. Incoming PK registration and weaker identity guards must not overwrite current isolation/fixes. Snapshot original bytes and differences retained in evidence.

1. Add failing regression cases for English/Chinese operation-scoped negation and bounded argument correction. Reproduce before changing application files.
2. Modify egfr_agent/tool_scope.py only for deterministic operation boundaries, protected SMILES punctuation, implicit shared negative lists, and negated live-SMILES shorthand. Explicit denial wins; independent affirmative operation can authorize its own capability. Do not delete negative text or grant tools from a bare SMILES.
3. Modify egfr_agent/function_calling.py: explicit no-argument contract; schema errors retry at most twice globally and within six rounds; validate whole batch before execution; re-resolve original request scope on every round; unauthorized names and molecule substitution remain fatal; never silently drop arguments or execute a tool twice. Log actual model request/response, schema rejection/retry and terminal state.
4. Modify egfr_agent/run_agent.py only to include attached Function Calling audit in existing unique failure artifacts; success Trace and multiobjective Trace already persist call_log. No score, model, production registry or candidate data changes.
5. Add two regression files; update existing parameter-rejection fixtures to exhaust the new bounded recovery budget while still asserting zero execution. Trace assertions select actual executed events instead of assuming the last event is a tool execution.
6. Run targeted then full tests in an independent project copy with previously verified original full snapshot/models/assets. Run true Ollama native Function Calling and both formal entries at 127.0.0.1:11434 / qwen2.5:7b without installing models or changing network. Keep connection failure BLOCKED.
7. Record raw logs, exit codes, per-test outcomes, before/after patch, preserved inputs/hashes, and remaining scientific limitations. No commits/pushes or Phase1-5.

Risk/rollback: new conservative negation boundaries can deny ambiguous lists; regression matrix covers them. A schema retry must not execute any part of a rejected batch; test atomicity and duplicate protection. Rollback is a reviewable reverse patch of this turn only; pre-turn modified originals are preserved, never reset to Git HEAD. No user production output is an execution target.
''')
for f in ('tests/test_agent_flow_v2.py','egfr_agent/run_agent.py'):
 dst=e/'before'/f.replace('/','__');shutil.copy2(r/f,dst)
(r/'tests/test_scope_operation_boundaries.py').write_text('''"""Deterministic authorization regression; no LLM/model execution."""
import pytest
from egfr_agent.tool_scope import EGFRToolScopeResolver

@pytest.mark.parametrize('request,allowed', [
 ('Do not predict SMILES: CCO and analyze docking poses', ['structure_analysis']),
 ('不要预测SMILES: CCO，同时分析 docking poses', ['structure_analysis']),
 ('Do not analyze docking and predict SMILES: CCO', ['qsar_inference']),
 ('不要分析对接，同时预测SMILES: CCO', ['qsar_inference']),
 ('No QSAR and analyze docking poses', ['structure_analysis']),
 ('QSAR is not required and analyze docking poses', ['structure_analysis']),
 ('不要预测活性；请分析结构', ['structure_analysis']),
 ('Analyze docking poses and do not predict SMILES: CCO', ['structure_analysis']),
 ('Do not predict SMILES: [Na+].[Cl-] but analyze docking poses', ['structure_analysis']),
 ('Do not predict SMILES: F/C=C/F and analyze docking poses', ['structure_analysis']),
 ('Do not predict SMILES: N[C@@H](C)O and analyze docking poses', ['structure_analysis']),
 ('Do not predict SMILES: c1:c:c:c:c:c:1 and analyze docking poses', ['structure_analysis']),
 ('Do not run candidate evaluation; analyze docking poses', ['structure_analysis']),
 ('不要进行候选分子完整评估，同时分析对接', ['structure_analysis']),
 ('Do not run PK D-MPNN; analyze docking poses', ['structure_analysis']),
])
def test_independent_affirmative_operation_survives_negation(request,allowed):
 result=EGFRToolScopeResolver().resolve(request)
 assert result['allowed_tools']==allowed
 assert all(t in result['prohibited_tools'] for t in EGFRToolScopeResolver.ALL_TOOLS if t not in allowed)

@pytest.mark.parametrize('separator',[', ','，','; ','；','. ','。','\\n',' and ',' but ',' then '])
def test_negated_live_smiles_followed_by_explicit_analysis(separator):
 result=EGFRToolScopeResolver().resolve('Do not predict SMILES: CCO'+separator+'analyze docking poses')
 assert result['allowed_tools']==['structure_analysis']
 assert result['explicit_qsar_exclusion']
 assert not result['explicit_structure_exclusion']

@pytest.mark.parametrize('request',[
 'Do not predict SMILES: CCO', '不要预测SMILES: CCO',
 'Do not predict QSAR and docking poses', 'No QSAR, docking poses',
 '不要预测活性和分析对接', 'No QSAR and no docking poses',
 'Do not predict SMILES: CCO and docking poses',
 'SMILES: CCO.CCN', 'SMILES: c1ccccc1',
 'Do not predict SMILES: CCO; predict activity for SMILES: CCN',
])
def test_negative_or_ambiguous_requests_fail_closed(request):
 with pytest.raises(ValueError):EGFRToolScopeResolver().resolve(request)

def test_long_negative_phrase_is_not_a_window_based_permission_bypass():
 request='Do not '+('carefully '*15)+'predict SMILES: CCO and analyze docking poses'
 assert EGFRToolScopeResolver().resolve(request)['allowed_tools']==['structure_analysis']
''')
(r/'tests/test_function_calling_argument_recovery.py').write_text('''"""Scripted model responses test Python guards only; never native E2E evidence."""
import copy,json
from pathlib import Path
import pandas as pd
import pytest
from unittest.mock import patch
from egfr_agent.function_calling import EGFRFunctionCaller
from egfr_agent.run_agent import save_failure_audit

class ScriptedClient:
 model='scripted-unit-test-not-ollama'
 def __init__(self,responses,check=None):self.responses=list(responses);self.requests=[];self.check=check
 def chat(self,messages,tools=None):
  if self.check:self.check(len(self.requests))
  self.requests.append(copy.deepcopy({'messages':messages,'tools':tools}))
  assert self.responses,'Unexpected request after scripted response budget'
  return {'message':self.responses.pop(0)}
class RecordingTool:
 def __init__(self):self.calls=[]
 def run(self):self.calls.append({});return pd.DataFrame([{'zinc_id':'UNIT_FIXTURE','value':1.0}])
 def run_with_args(self,**args):self.calls.append(args);return {'smiles':args['smiles'],'predicted_pIC50':6.0}
def call(name,args=None):return {'function':{'name':name,'arguments':{} if args is None else args}}
def response(*calls):return {'role':'assistant','content':'','tool_calls':list(calls)}
def setup(responses,check=None):
 tools={name:RecordingTool() for name in ('qsar_prediction','structure_analysis','qsar_inference')}
 caller=EGFRFunctionCaller(tools);caller.client=ScriptedClient(responses,check);return caller,tools

def test_no_argument_error_reprompts_without_discarding_fields():
 caller,tools=setup([response(call('qsar_prediction',{'smiles':'CCO','toolchain':'legacy'})),response(call('qsar_prediction')),response()])
 result=caller.run('Retrieve QSAR predictions')
 assert tools['qsar_prediction'].calls==[{}]
 assert result['executed_tools']==['qsar_prediction']
 assert any(x.get('event')=='argument_validation_failed' for x in result['call_log'])
 assert any(x.get('event')=='argument_retry' for x in result['call_log'])
 requests=[x for x in result['call_log'] if x.get('event')=='model_request']
 assert len(requests)==3 and len(requests[0]['request']['messages'])==2
 assert requests[0]['response']['message']['tool_calls'][0]['function']['arguments']=={'smiles':'CCO','toolchain':'legacy'}
 assert caller.last_audit['status']=='completed'
 assert 'accept no arguments' in caller.client.requests[0]['messages'][0]['content']

def test_rejected_batch_executes_nothing_even_with_valid_sibling():
 holder={}
 def check(index):
  if index==1:assert all(not t.calls for t in holder['tools'].values())
 caller,tools=setup([response(call('structure_analysis'),call('qsar_prediction',{'toolchain':'x'})),response(call('structure_analysis'),call('qsar_prediction')),response()],check)
 holder['tools']=tools
 result=caller.run('Analyze QSAR activity and docking poses')
 assert set(result['executed_tools'])=={'qsar_prediction','structure_analysis'}
 assert tools['qsar_prediction'].calls==tools['structure_analysis'].calls==[{}]

@pytest.mark.parametrize('arguments',[{'smiles':'CCO','toolchain':'x'},'{broken json',42])
def test_argument_retry_exhaustion_fails_closed_with_complete_audit(arguments):
 caller,tools=setup([response(call('qsar_prediction',arguments)) for _ in range(3)])
 with pytest.raises(RuntimeError,match='argument.*retry|Argument.*retry') as failure:caller.run('Retrieve QSAR predictions')
 assert all(not x.calls for x in tools.values())
 audit=failure.value.function_calling_audit
 assert audit['status']=='failed' and len(caller.client.requests)==3
 assert sum(x.get('event')=='argument_retry' for x in audit['call_log'])==2
 assert sum(x.get('event')=='argument_validation_failed' for x in audit['call_log'])==3

def test_unauthorized_tool_during_retry_is_immediately_fatal():
 caller,tools=setup([response(call('qsar_prediction',{'smiles':'CCO'})),response(call('structure_analysis'))])
 with pytest.raises(RuntimeError,match='unapproved'):caller.run('Retrieve QSAR predictions')
 assert all(not x.calls for x in tools.values())
 assert len(caller.client.requests)==2

def test_unauthorized_sibling_cannot_hide_behind_argument_error():
 caller,tools=setup([response(call('qsar_prediction',{'smiles':'CCO'}),call('structure_analysis'))])
 with pytest.raises(RuntimeError,match='unapproved'):caller.run('Retrieve QSAR predictions')
 assert all(not x.calls for x in tools.values())
 assert len(caller.client.requests)==1

def test_smiles_in_correction_history_never_becomes_original_user_authority():
 caller,tools=setup([response(call('qsar_inference',{'smiles':'CCN','toolchain':'x'})),response(call('qsar_inference',{'smiles':'CCN'}))])
 with pytest.raises(RuntimeError,match='not found verbatim'):caller.run('Predict SMILES: CCO')
 assert all(not x.calls for x in tools.values())

def test_missing_smiles_can_be_corrected_only_to_original_input():
 caller,tools=setup([response(call('qsar_inference')),response(call('qsar_inference',{'smiles':'CCO'})),response()])
 caller.run('Predict SMILES: CCO')
 assert tools['qsar_inference'].calls==[{'smiles':'CCO'}]

def test_executed_tool_stays_single_execution_across_recovery_rounds():
 caller,tools=setup([response(call('qsar_prediction')),response(call('structure_analysis',{'toolchain':'x'})),response(call('qsar_prediction'),call('structure_analysis'),call('structure_analysis')),response()])
 result=caller.run('Analyze QSAR and docking poses')
 assert tools['qsar_prediction'].calls==tools['structure_analysis'].calls==[{}]
 assert sum(x.get('status')=='duplicate_blocked' for x in result['call_log'])==2
 assert [s['function']['name'] for s in caller.client.requests[1]['tools']]==['structure_analysis']

def test_original_scope_revalidated_on_model_rounds():
 caller,tools=setup([response(call('qsar_prediction',{'smiles':'CCO'})),response(call('qsar_prediction')),response()])
 with patch.object(caller.scope_resolver,'resolve',wraps=caller.scope_resolver.resolve) as resolve:
  caller.run('Retrieve QSAR predictions')
 assert resolve.call_count>=len(caller.client.requests)
 assert all(c.args==('Retrieve QSAR predictions',) for c in resolve.call_args_list)

@pytest.mark.parametrize('query',['Do not predict SMILES: CCO and analyze docking poses','不要预测SMILES: CCO，同时分析 docking poses'])
def test_negated_smiles_never_advertised_or_executed(query):
 caller,tools=setup([response(call('structure_analysis')),response()])
 result=caller.run(query)
 assert result['executed_tools']==['structure_analysis']
 assert not tools['qsar_prediction'].calls and not tools['qsar_inference'].calls
 assert [s['function']['name'] for s in caller.client.requests[0]['tools']]==['structure_analysis']

def test_failure_audit_persists_retries_without_success_report(tmp_path,monkeypatch):
 monkeypatch.chdir(tmp_path)
 caller,tools=setup([response(call('qsar_prediction',{'toolchain':'x'})) for _ in range(3)])
 with pytest.raises(RuntimeError) as error:caller.run('Retrieve QSAR predictions')
 path=save_failure_audit('Retrieve QSAR predictions',error.value,'agent_execution')
 record=json.loads(path.read_text())
 assert record['function_calling_audit']['status']=='failed'
 assert len([x for x in record['function_calling_audit']['call_log'] if x.get('event')=='model_request'])==3
 assert not record['trusted_decision_generated']
 assert not Path('reports/EGFR_AI_Agent_Report.md').exists()
''')
print('Plan and regression tests created; application source not changed yet.')
