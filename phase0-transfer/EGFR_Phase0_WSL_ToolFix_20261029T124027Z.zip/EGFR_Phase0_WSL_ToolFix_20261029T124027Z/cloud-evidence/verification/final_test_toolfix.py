from pathlib import Path
import json,shutil,subprocess,datetime,os
s=json.loads(Path('/workspace/recovery/latest-toolfix.json').read_text());r=Path(s['root']);iso=Path(s['isolated_project']);e=Path(s['evidence'])/'final-run';(e/'execution').mkdir(parents=True)
for folder in ('egfr_agent','scripts','tests'):shutil.copytree(r/folder,iso/folder,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
records=[]
for name,files in [('targeted',['tests/test_scope_operation_boundaries.py','tests/test_function_calling_argument_recovery.py','tests/test_agent_flow_v2.py','tests/test_tool_scope_resolver_v2.py','tests/test_candidate_evaluation_fc.py','tests/test_pk_dmpnn_function_calling.py','tests/test_cli_failure_audit.py','tests/test_agent_trace_v2.py']),('full',['.'])]:
 argv=['/workspace/egfr-rf-venv/bin/python','-m','pytest',*files,'-q','--continue-on-collection-errors','--tb=short','-rs',f'--junitxml={e}/execution/{name}.xml'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(argv,cwd=iso,capture_output=True,text=True,timeout=180,env={**os.environ,'EGFR_CHEMPROP_BIN':'/workspace/egfr-pk-venv/bin/chemprop'})
 (e/'execution'/f'{name}.stdout.log').write_text(p.stdout);(e/'execution'/f'{name}.stderr.log').write_text(p.stderr);records.append({'name':name,'argv':argv,'cwd':str(iso),'started_utc':start,'exit_code':p.returncode,'kind':'automated_mixed_scripted_model_and_real_assets_not_native_E2E','stdout':str(e/'execution'/f'{name}.stdout.log'),'stderr':str(e/'execution'/f'{name}.stderr.log')});(e/'execution/commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,p.stdout[-1200:],p.stderr[-300:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
# Preserve earlier native evidence; a new final-run location records current code.
source=Path('/tmp/run_toolfix_native.py').read_text().replace("e=Path(s['evidence'])","e=Path(s['evidence'])/'final-run'")
Path('/tmp/run_toolfix_native_final.py').write_text(source)
