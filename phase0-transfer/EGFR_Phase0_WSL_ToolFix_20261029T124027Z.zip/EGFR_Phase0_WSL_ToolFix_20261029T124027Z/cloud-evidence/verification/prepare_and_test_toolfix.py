from pathlib import Path
import json,shutil,hashlib,subprocess,datetime,os
s=json.loads(Path('/workspace/recovery/latest-toolfix.json').read_text());r=Path(s['root']);e=Path(s['evidence']);iso=Path(s['isolated_project'])
old=Path(json.loads(Path('/workspace/recovery/latest-qsar-gzip.json').read_text())['isolated_project'])
shutil.copytree(old,iso,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','failures','agent_developability','candidate_evaluations'))
for folder in ('egfr_agent','scripts','tests','examples'):shutil.copytree(r/folder,iso/folder,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
for p in (r/'phase0').glob('*.py'):shutil.copy2(p,iso/'phase0'/p.name)
for p in r.glob('test_*.py'):shutil.copy2(p,iso/p.name)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1048576),b''):h.update(x)
 return h.hexdigest()
# Track every original isolated scientific/report input before executing.
skip={'.git','__pycache__','.pytest_cache'}
inputs={str(p.relative_to(iso)):sha(p) for folder in ('models','data','experiments','docking','results','reports') for p in (iso/folder).rglob('*') if p.is_file() and not any(x in skip for x in p.parts)}
(e/'isolated-input-hashes-before.json').write_text(json.dumps(inputs,indent=2)+'\n')
cmds=[('targeted',[ 'tests/test_scope_operation_boundaries.py','tests/test_function_calling_argument_recovery.py','tests/test_agent_flow_v2.py','tests/test_tool_scope_resolver_v2.py','tests/test_candidate_evaluation_fc.py','tests/test_pk_dmpnn_function_calling.py','tests/test_cli_failure_audit.py','tests/test_agent_trace_v2.py']),('full',['.'])]
records=[]
for name,selection in cmds:
 cmd=['/workspace/egfr-rf-venv/bin/python','-m','pytest',*selection,'-q','--continue-on-collection-errors','--tb=short','-rs',f'--junitxml={e}/execution/{name}.xml'];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(cmd,cwd=iso,capture_output=True,text=True,timeout=180,env={**os.environ,'EGFR_CHEMPROP_BIN':'/workspace/egfr-pk-venv/bin/chemprop'})
 (e/'execution'/f'{name}.stdout.log').write_text(p.stdout);(e/'execution'/f'{name}.stderr.log').write_text(p.stderr)
 records.append({'name':name,'argv':cmd,'cwd':str(iso),'started_utc':start,'exit_code':p.returncode,'execution_kind':'automated_regression_mixed_scripted_models_and_real_asset_tests_not_native_E2E','stdout':str(e/'execution'/f'{name}.stdout.log'),'stderr':str(e/'execution'/f'{name}.stderr.log')})
 (e/'execution/commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,p.stdout[-2500:],p.stderr[-500:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
