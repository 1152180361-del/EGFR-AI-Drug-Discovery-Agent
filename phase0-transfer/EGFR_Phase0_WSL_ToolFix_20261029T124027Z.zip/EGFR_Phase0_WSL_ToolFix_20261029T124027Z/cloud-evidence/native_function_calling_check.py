from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from egfr_agent.function_calling import EGFRFunctionCaller
from egfr_agent.tool_registry import TOOLS
s=json.loads(Path('/workspace/recovery/latest-toolfix.json').read_text());e=Path(s['evidence']);records=[]
queries=['Analyze EGFR QSAR activity and docking evidence for existing candidates','Do not predict SMILES: CCO and analyze docking poses','不要预测SMILES: CCO，同时分析 docking poses']
for i,query in enumerate(queries):
 caller=EGFRFunctionCaller(TOOLS)
 try:
  result=caller.run(query)
  records.append({'query':query,'status':'PASS_REAL_NATIVE_FUNCTION_CALLING','executed_tools':result['executed_tools']})
 except Exception as exc:
  status='BLOCKED_OLLAMA' if 'Ollama connection failed' in str(exc) else 'FAIL_REAL_NATIVE_FUNCTION_CALLING'
  records.append({'query':query,'status':status,'error_type':type(exc).__name__,'error':str(exc)})
 (e/'native-audits'/f'function-calling-{i+1}.json').write_text(json.dumps(caller.last_audit,indent=2,ensure_ascii=False)+'\n')
(e/'native-function-calling-results.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(records,indent=2,ensure_ascii=False))
raise SystemExit(0 if all(x['status']=='PASS_REAL_NATIVE_FUNCTION_CALLING' for x in records) else 1)
