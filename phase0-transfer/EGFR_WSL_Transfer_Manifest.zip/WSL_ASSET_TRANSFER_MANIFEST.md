# WSL → Codex Phase 0 资产交接清单

生成日期：2026-10-29（Asia/Shanghai）。本轮仅文档与打包清单；暂停源码修改，不导入缺失研究模块、不执行推理、训练或新回归，不恢复/覆盖任何模型或报告。

## 范围与当前状态

WSL 项目根：`/home/xie/EGFR_AIDD_Pipeline`；Codex 根：`/workspace/EGFR-AI-Drug-Discovery-Agent`。下表路径均相对 **WSL 项目根**，运行环境另以 `$HOME` 为基准。两者不共享文件。当前 `work` 分支，HEAD `2016d6ba4394001e238715764698f1379f61e04b`，保留已有未提交修改及交付包；没有提交、推送、修改忽略规则或仓库选择。

依据 CURRENT_ACCEPTANCE.md、ASSET_TRANSFER_AND_NEXT_STEPS.md、reviewable-source-changes.json，以及当前工具/测试的只读路径审查。历史统计仍为专项71通过、全量104通过/1失败/8跳过/5收集错误，本轮未重跑，不产生新的PASS声明。

“真实推理”列指 Gefitinib PK、CCO RF、Gefitinib五模块三个直接工具验证；“完整回归”列指当前 pytest（包括被skip的研究集成），**不把使用mock的PK单测当作真实checkpoint验证**。另外注明完整Ollama Agent E2E/历史来源审计的条件需求。

本清单覆盖当前可读代码的直接及已知间接依赖。五份缺失研究脚本的源码尚不可读，其二级导入/顶层数据读取不能完全确定；交接源码后还需只读审查依赖，不能承诺仅交这五份脚本就一定全绿，也不要求打包整个研究项目兜底。

## 文件清单

全部以下路径已在正式Codex checkout逐项检查。未知大小不猜测；“已有SHA”区分已测旧交接版本与当前WSL文件。每一行都标明是否需要原WSL资产。

### 1.真实推理与模型核验

| WSL项目相对路径 | 用途 | 真实推理必需 | 完整回归必需 | 预期大小 | 可靠SHA-256 | 来源/恢复与当前状态 | 缺失阻塞 |
|---|---|---|---|---|---|---|---|
| `models/egfr_qsar_production_rf.joblib` | 生产RF真实加载与预测 | 是：CCO RF、Gefitinib组合 | 是：test_qsar_inference_tool.py::test_valid_smiles_prediction | 105455297 bytes（用户WSL报告，非本机测量） | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | 唯一RF测试失败；真实RF及完整五模块评估 |
| `models/egfr_qsar_production_rf.json` | 模型表示、训练/选择来源元数据；不含权重 | 执行不读取；模型核验必需 | 否：当前pytest不直接读取 | 1031 bytes（已测旧交接版） | 已有上传版哈希 H1；当前WSL版本待比对 | 当前checkout缺失；可从A0/A1恢复；不要以旧元数据冒充当前权重身份 | 模型资产来源核验；不直接导致当前pytest失败 |
| `data/processed/egfr_train.csv` | AD训练化学空间参考；列standardized_smiles | 是：Gefitinib五模块中的适用域 | 否：当前真实CLI回归允许PARTIAL | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | applicability_domain_tool导入失败，完整五模块不能完成；不是RF推理必须输入 |
| `experiments/pk_upgrade_v2/runs/dmpnn_scaffold_seed42_v1/checkpoints/model_0/best.pt` | PK固定seed 42的原始checkpoint | 是：Gefitinib真实五种子PK | 否：现有PK单测使用临时mock | 286979 bytes（用户WSL报告） | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | 该seed真实推理及完整五种子集成；其余seed不能替代 |
| `experiments/pk_upgrade_v2/runs/model_seed_check_42_46_v1/models/dmpnn_seed43/model_0/best.pt` | PK固定seed 43的原始checkpoint | 是：Gefitinib真实五种子PK | 否：现有PK单测使用临时mock | 286979 bytes（用户WSL报告） | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | 该seed真实推理及完整五种子集成；其余seed不能替代 |
| `experiments/pk_upgrade_v2/runs/model_seed_check_42_46_v1/models/dmpnn_seed44/model_0/best.pt` | PK固定seed 44的原始checkpoint | 是：Gefitinib真实五种子PK | 否：现有PK单测使用临时mock | 286979 bytes（用户WSL报告） | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | 该seed真实推理及完整五种子集成；其余seed不能替代 |
| `experiments/pk_upgrade_v2/runs/model_seed_check_42_46_v1/models/dmpnn_seed45/model_0/best.pt` | PK固定seed 45的原始checkpoint | 是：Gefitinib真实五种子PK | 否：现有PK单测使用临时mock | 286979 bytes（用户WSL报告） | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | 该seed真实推理及完整五种子集成；其余seed不能替代 |
| `experiments/pk_upgrade_v2/runs/model_seed_check_42_46_v1/models/dmpnn_seed46/model_0/best.pt` | PK固定seed 46的原始checkpoint | 是：Gefitinib真实五种子PK | 否：现有PK单测使用临时mock | 286979 bytes（用户WSL报告） | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | 该seed真实推理及完整五种子集成；其余seed不能替代 |

### 2.完整回归所需研究源码

| WSL项目相对路径 | 用途 | 真实推理必需 | 完整回归必需 | 预期大小 | 可靠SHA-256 | 来源/恢复与当前状态 | 缺失阻塞 |
|---|---|---|---|---|---|---|---|
| `scripts/integrate_admet_ai_multiobjective_v1.py` | 恢复原研究模块供离线测试导入；不授权执行其生产主流程 | 否：三项真实工具smoke不依赖它 | 是：原模块导入 | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | test_admet_ai_multiobjective_v1.py 收集失败；模块二级依赖待源码交接后只读审查 |
| `scripts/run_egfr_admet_multiobjective_agent.py` | 恢复原研究模块供离线测试导入；不授权执行其生产主流程 | 否：三项真实工具smoke不依赖它 | 是：原模块导入 | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | test_admet_multiobjective_agent.py 收集失败；模块二级依赖待源码交接后只读审查 |
| `scripts/run_egfr_multiobjective_agent.py` | 恢复原研究模块供离线测试导入；不授权执行其生产主流程 | 否：三项真实工具smoke不依赖它 | 是：原模块导入 | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | test_multiobjective_agent_extension.py 收集失败；模块二级依赖待源码交接后只读审查 |
| `scripts/audit_pareto_robustness.py` | 恢复原研究模块供离线测试导入；不授权执行其生产主流程 | 否：三项真实工具smoke不依赖它 | 是：原模块导入 | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | test_pareto_robustness.py、test_final_decision_report.py 收集失败；模块二级依赖待源码交接后只读审查 |
| `scripts/build_egfr_final_decision_report.py` | 恢复原研究模块供离线测试导入；不授权执行其生产主流程 | 否：三项真实工具smoke不依赖它 | 是：原模块导入 | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | test_final_decision_report.py（前一导入错误掩盖了此项） 收集失败；模块二级依赖待源码交接后只读审查 |

### 3.完整回归与历史研究夹具

| WSL项目相对路径 | 用途 | 真实推理必需 | 完整回归必需 | 预期大小 | 可靠SHA-256 | 来源/恢复与当前状态 | 缺失阻塞 |
|---|---|---|---|---|---|---|---|
| `results/zinc15_screening/phase5_final_candidate_decision_matrix.csv` | 原候选决策矩阵，必须保留原值 | 否：新SMILES三个工具smoke不读取；原候选结构E2E需要 | 是：StructureTool真实集成 | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | test_decision_input_validation.py::test_real_candidate_evidence及7项TestAgentTraceConsistency；第三份CSV未被skip装饰器预检查，但进入run后仍必读 |
| `results/zinc15_screening/phase4E_final_candidate_evidence_matrix.csv` | 原结构/适用域/RF标记等证据 | 否：新SMILES三个工具smoke不读取；原候选结构E2E需要 | 是：StructureTool真实集成 | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | test_decision_input_validation.py::test_real_candidate_evidence及7项TestAgentTraceConsistency；第三份CSV未被skip装饰器预检查，但进入run后仍必读 |
| `results/zinc15_screening/phase5_final_candidate_ranking_v3_hinge_priority.csv` | StructureTool.run无条件读取的第三份排名表；不重新计算排名 | 否：新SMILES三个工具smoke不读取；原候选结构E2E需要 | 是：StructureTool真实集成 | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | test_decision_input_validation.py::test_real_candidate_evidence及7项TestAgentTraceConsistency；第三份CSV未被skip装饰器预检查，但进入run后仍必读 |
| `reports/agent_runs/EGFR_Agent_Trace_20261013T154711_232634Z_987406c0.json` | 测试固定的10月13日不可变Trace | 否：新推理不复用它 | 是：7项TestAgentTraceConsistency | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | 历史授权/调用/决策/证据/报告/科学边界7项测试保持skip；不得拿10月28日latest替换 |
| `reports/EGFR_AI_Agent_Report.md` | 与10月13日固定Trace同次的科学报告 | 否：新报告应重新生成 | 是：历史一致性7项，尤其test_06 | 5768 bytes（已测旧交接版） | 已有上传版哈希 H2；与Trace配对仍待核验 | 当前checkout缺失；可从A0/A1恢复旧版；时间戳相近不能单独证明同次正确配对 | 当前缺报告；旧报告恢复后仍需对应Trace/证据；WSL latest若已变，需原归档版，不能覆盖改写 |
| `reports/EGFR_Pose_Review_Matrix.csv` | 原人工复核状态；旧Markdown含详细review表 | 否：新SMILES预测不读取 | 是：重现已打包旧报告的test_06_report_and_review_consistency | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | 矩阵缺失时render_pose_review仅输出unavailable，无法复现旧报告的review段；不要运行--init伪造矩阵 |

### 4.SMILES来源择需补齐

| WSL项目相对路径 | 用途 | 真实推理必需 | 完整回归必需 | 预期大小 | 可靠SHA-256 | 来源/恢复与当前状态 | 缺失阻塞 |
|---|---|---|---|---|---|---|---|
| `results/zinc15_screening/zinc15_phase4C_candidates.csv` | 优先的真实候选SMILES查找表 | 新SMILESsmoke否；原候选结构E2E需要一个覆盖充分的来源 | 条件必需：至少一组来源覆盖StructureTool全部输出候选 | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；WSL原表；优先前两份小表，不默认打包250k表 | StructureTool._restore_smiles报Cannot recover real SMILES；影响上述8项研究集成测试。不能只补top1，test_real_candidate_evidence使用全部候选 |
| `docking/3W32/phase4C/reports/phase4C_ligand_preparation.csv` | 第二来源，补齐候选SMILES/身份；仅传准备报告，不传全套docking | 新SMILESsmoke否；原候选结构E2E需要一个覆盖充分的来源 | 条件必需：至少一组来源覆盖StructureTool全部输出候选 | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；WSL原表；优先前两份小表，不默认打包250k表 | StructureTool._restore_smiles报Cannot recover real SMILES；影响上述8项研究集成测试。不能只补top1，test_real_candidate_evidence使用全部候选 |
| `data/processed/external/zinc15_250k_standardized.csv` | 大型第三后备来源；只有前两表不能覆盖全部待评估候选时才考虑 | 新SMILESsmoke否；原候选结构E2E需要一个覆盖充分的来源 | 条件必需：至少一组来源覆盖StructureTool全部输出候选 | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；WSL原表；优先前两份小表，不默认打包250k表 | StructureTool._restore_smiles报Cannot recover real SMILES；影响上述8项研究集成测试。不能只补top1，test_real_candidate_evidence使用全部候选 |

### 5.历史shadow与科学来源

| WSL项目相对路径 | 用途 | 真实推理必需 | 完整回归必需 | 预期大小 | 可靠SHA-256 | 来源/恢复与当前状态 | 缺失阻塞 |
|---|---|---|---|---|---|---|---|
| `reports/pk_dmpnn_shadow/EGFR_PK_DMPNN_shadow_20261028T173741_666852Z.json` | 核对历史五种子、聚合、版本/哈希是否记录 | 新推理否；本轮历史审计需要 | 否：当前pytest不读取 | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；必须从WSL/原始制品获取 | 无法把历史成功绑定到当前checkpoint；不阻塞mock单测，不得把它当本次推理结果 |

### 6.可选来源审计/条件E2E（不阻塞本轮三项工具smoke）

| WSL项目相对路径 | 用途 | 真实推理必需 | 完整回归必需 | 预期大小 | 可靠SHA-256 | 来源/恢复与当前状态 | 缺失阻塞 |
|---|---|---|---|---|---|---|---|
| `data/processed/egfr_validation.csv` | 保存的QSAR验证划分；只读来源核对 | 否；全局snapshot仅条件E2E需要 | 否：当前pytest不直接依赖（snapshot路径测试使用临时夹具） | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；WSL；默认不打包，选定验证范围后单独加入 | 不造成当前1失败/8跳过/5收集错误；缺失限制来源审查或指定snapshot E2E，不在本轮执行Phase1指标审计 |
| `data/processed/egfr_test.csv` | 保存的QSAR测试划分；只读来源核对 | 否；全局snapshot仅条件E2E需要 | 否：当前pytest不直接依赖（snapshot路径测试使用临时夹具） | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；WSL；默认不打包，选定验证范围后单独加入 | 不造成当前1失败/8跳过/5收集错误；缺失限制来源审查或指定snapshot E2E，不在本轮执行Phase1指标审计 |
| `data/processed/egfr_scaffold_split.csv` | 合并划分映射，核实所提供train/validation/test版本 | 否；全局snapshot仅条件E2E需要 | 否：当前pytest不直接依赖（snapshot路径测试使用临时夹具） | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；WSL；默认不打包，选定验证范围后单独加入 | 不造成当前1失败/8跳过/5收集错误；缺失限制来源审查或指定snapshot E2E，不在本轮执行Phase1指标审计 |
| `reports/phase2_scaffold_assignments.csv` | 保存的scaffold分配元数据 | 否；全局snapshot仅条件E2E需要 | 否：当前pytest不直接依赖（snapshot路径测试使用临时夹具） | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；WSL；默认不打包，选定验证范围后单独加入 | 不造成当前1失败/8跳过/5收集错误；缺失限制来源审查或指定snapshot E2E，不在本轮执行Phase1指标审计 |
| `reports/phase2_scaffold_split_summary.csv` | 保存的划分样本数摘要 | 否；全局snapshot仅条件E2E需要 | 否：当前pytest不直接依赖（snapshot路径测试使用临时夹具） | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；WSL；默认不打包，选定验证范围后单独加入 | 不造成当前1失败/8跳过/5收集错误；缺失限制来源审查或指定snapshot E2E，不在本轮执行Phase1指标审计 |
| `data/processed/egfr_qsar_modeling.csv` | 生产RF训练脚本的完整建模数据；不应误认AD的egfr_train.csv就是生产模型全部训练集 | 否；全局snapshot仅条件E2E需要 | 否：当前pytest不直接依赖（snapshot路径测试使用临时夹具） | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；WSL；默认不打包，选定验证范围后单独加入 | 不造成当前1失败/8跳过/5收集错误；缺失限制来源审查或指定snapshot E2E，不在本轮执行Phase1指标审计 |
| `results/zinc15_screening/phase4E_visual_review_shortlist.csv` | 人工review上游shortlist；read_review本身不读取，来源核验可选 | 否；全局snapshot仅条件E2E需要 | 否：当前pytest不直接依赖（snapshot路径测试使用临时夹具） | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；WSL；默认不打包，选定验证范围后单独加入 | 不造成当前1失败/8跳过/5收集错误；缺失限制来源审查或指定snapshot E2E，不在本轮执行Phase1指标审计 |
| `results/zinc15_screening/zinc15_221988_qsar_predictions.csv` | 预计算QSAR全局快照；只有验证原snapshot+structure真实Agent路线时必需，可能较大 | 否；全局snapshot仅条件E2E需要 | 否：当前pytest不直接依赖（snapshot路径测试使用临时夹具） | 未知，待WSL stat | 无可靠参考；WSL计算后提供 | 当前checkout缺失；WSL；默认不打包，选定验证范围后单独加入 | 不造成当前1失败/8跳过/5收集错误；缺失限制来源审查或指定snapshot E2E，不在本轮执行Phase1指标审计 |

## 已知大小/哈希的解释与交付包核查

- H1（仅RF JSON metadata）：`6d402eece4354085a4a8a6f614f9c31733abe8e2fc52df0507503463ccaeb20e`，1031 bytes；不是105455297-byte joblib的哈希。
- H2（旧Agent Markdown）：`d2c20634e4daefc7abfe1224ec66626ae743b15760a7090fbde12b22eb6b10f6`，5768 bytes。报告正文时间是2026-10-13T15:47:11+00:00，仍须取得固定Trace及当时CSV/matrix验证配对。
- RF joblib与每个checkpoint的大小来自用户WSL审计，本轮Codex无法测量。它们均没有已提供的可信参考SHA；相同大小不证明相同内容或种子身份。需WSL对原文件计算SHA并附旧可信记录；新算摘要可核对传输一致性，不能单独证明训练来源。

本轮逐ZIP条目检查：

|包|实际检查的本地位置|可恢复|不能恢复|
|---|---|---|---|
|A0|`/workspace/attachments/bceaa44c-352a-4210-a33e-0a41689387b2/EGFR_Codex_Handoff_20261029_134352.zip`|RF JSON metadata、旧Agent Markdown、10月28日latest Trace（不适用于固定10月13日测试）|真实RF/PT权重、研究数据、五份缺失脚本、固定10月13日Trace、指定历史PK报告|
|A1|`/workspace/EGFR_Phase0_Delivery.zip`|RF JSON metadata、旧Agent Markdown、10月28日latest Trace（不适用于固定10月13日测试）|真实RF/PT权重、研究数据、五份缺失脚本、固定10月13日Trace、指定历史PK报告|
|A2|`/workspace/EGFR_Phase0_Resumed_Delivery.zip`|当前源码/修复/证据；其中latest Trace是后续直接工具smoke，不是历史研究Trace|真实RF/PT权重、研究数据、五份缺失脚本、固定10月13日Trace、指定历史PK报告|
|A3|`/workspace/EGFR_Phase0_Acceptance_Audit.zip`|当前源码/修复/证据；其中latest Trace是后续直接工具smoke，不是历史研究Trace|真实RF/PT权重、研究数据、五份缺失脚本、固定10月13日Trace、指定历史PK报告|

重要差异：A0/A1 的 `reports/EGFR_AI_Agent_Tool_Trace.json` 是 run_id `20261028T172049_088935Z_e10daad2`，SHA `ae689175e11e64e6b3b8677b02c79150408deabc3327f5966ac3be888cfb8729`，10804 bytes；它不能改名顶替 `EGFR_Agent_Trace_20261013T154711_232634Z_987406c0.json`。A2/A3的同名latest为6519 bytes、SHA `6240dac1367d5938c74b215f404c3fffa2022fc430361874d7a730e288024a67`，同样不能替代。

A0/A1的两个可恢复文件不放入默认WSL必须清单，避免重复传输。待交接时从包中先恢复到独立staging目录并核对H1/H2，不直接覆盖Codex或WSL现存文件。若WSL当前元数据/报告不同，可以作为可选审计版本另行传输，必须记录版本，不能默认为同一文件。

## Chemprop、RF运行时与Ollama：不是“拷一个可执行文件”

|位置/交接项|用途与需求|已知大小/SHA|当前Codex状态/阻塞|交接方法|
|---|---|---|---|---|
|相对WSL `$HOME`：`miniforge3/envs/admet_ai/bin/chemprop`|真实五种子PK必需；当前mock PK单测不需要|大小/哈希未知；2.3.1仅为用户WSL报告|默认Codex家目录下无该文件，PATH无chemprop；PK在环境检查失败|提供版本与依赖规格，Codex重建兼容运行时；不打包整个Conda目录或仅拷launcher|
|相对WSL `$HOME`：`miniforge3/envs/admet_ai/bin/python`|识别Chemprop运行时的Python/torch/lightning/RDKit等|未知|当前Codex Python3.12.14不等于WSL环境|只读取选定包版本；不转移整个解释器前缀|
|相对WSL `$HOME`：`miniforge3/envs/rdkit_aidd/bin/python`|RF joblib反序列化兼容性与完整五模块|未知；项目历史报告Python3.11.16，不作为本次实测|Codex已有独立离线venv，但没有证明与原权重兼容|提供scikit-learn/joblib/numpy/RDKit等准确版本；不能只依赖当前requirements猜测|
|Ollama服务及实际工具调用模型|只在真实完整Agent E2E需要；三个直接工具smoke/离线pytest无需|模型tag/digest/安装路径待WSL确认；代码默认qwen2.5:7b，不代表WSL实际值|Codex未提供服务/模型；不要打包不明路径的全量模型缓存|交接模型名称、digest、Ollama版本和不含凭据的连接方式；后续选择安装/安全访问，当前不打包整个.ollama|

运行时的可交付物是下面命令**新生成**的`transfer-metadata/runtime-versions.json`，其路径相对交接包，不是伪称WSL已有文件。此文件记录两个环境选定包版本，不记录完整环境变量、pip索引URL或Conda channel凭据。导出规格并不保证所有二进制依赖已重建；收到后核对平台、CPU/CUDA和实际命令。不得把WSL不可迁移前缀复制过来后宣称运行时已可用。

checkpoint标签单位、log10变换/截断、来源版本尚需最小训练元数据支持。现有可读代码没有给出PK原train/validation/test文件的可靠路径，**不编造路径，不默认要求整套PK训练数据**；先从指定历史PK报告/原训练记录确认精确引用，必要时只交对应的小型配置/来源摘录，再决定需要的原数据。该路径未知项是科学来源审计待确认，不是当前mock单测的依赖。

## 数据范围：不把Phase1资产当作当前必交

`egfr_validation.csv`、`egfr_test.csv`、`egfr_scaffold_split.csv`及划分摘要来自当前09_scaffold_split.py的精确路径；列于可选表以保留版本证据，当前RF预测/AD与pytest不读取它们。`egfr_train.csv`却是AD必需。生产RF JSON说明其在完整curated建模集训练，所以不能把AD参考集等同于生产RF全部训练集。

不要求重新生成划分、运行训练脚本、重算指标或重训权重；这些不在本轮执行范围。当前不需要Morgan `.npz`特征、原始ChEMBL下载、完整ZINC库、受体/PDB/SDF/全部docking输出、图片、其他模型或缓存。若要验证全局snapshot的真实Agent路线，才单独传221988条预测快照；恢复真实候选SMILES优先两份小表，不能默认搬250k外部库。

## 可直接用于WSL的打包清单

本目录提供纯文本正向白名单（一行一个项目相对文件，不含通配符/目录）：

|文件|作用|
|---|---|
|`WSL_ASSET_FILES_REQUIRED.txt`|18份原WSL必须交接文件：真实推理输入、缺失源码、研究夹具与历史PK审计；不包括可从已有ZIP恢复的两文件|
|`WSL_ASSET_FILES_SMILES_SOURCES.txt`|三条已知真实SMILES来源；默认只选存在的前两份小表。大库必须显式选择，且仅在覆盖不足时|
|`WSL_ASSET_FILES_OPTIONAL_AUDIT.txt`|可恢复的metadata/报告及可选划分来源/条件snapshot；默认不打包|
|`WSL_ASSET_FILES_RECOVERABLE.txt`|A0/A1可恢复的两文件；供独立staging恢复核对，不应误当作必须从WSL获取|

将本目录这几份TXT复制到WSL独立目录，例如`/tmp/egfr-transfer-lists`。以下命令不运行研究模块、不更改WSL项目。只创建全新的`/tmp`交接目录；若必需资产缺失则停止，不生成看似完整的包。对缺失文件仅报告，不删除、不造占位模型。

五份研究脚本和原报告可能包含写死的连接信息/私人文本，传输前需审阅；文件名白名单无法证明任意源文件内容从未包含秘密。打包程序拒绝`.env`、key/pem、隐藏路径、缓存、目录及符号链接，不自动读取环境/凭据文件。只将核准资产交给Codex，不打包整个项目或home。

### WSL打包命令（复制执行前将清单放到指定目录）

```bash
python - <<'PY'
from pathlib import Path, PurePosixPath
import datetime, hashlib, importlib.metadata, json, os, subprocess, tarfile, tempfile

project = Path('/home/xie/EGFR_AIDD_Pipeline').resolve(strict=True)
list_dir = Path('/tmp/egfr-transfer-lists')
# 默认不含可选审计数据或大型回退库；确有必要才显式改为True。
include_optional_audit = False
include_large_smiles_fallback = False

def read_list(name):
    return [s.strip() for s in (list_dir/name).read_text().splitlines() if s.strip()]

selected = read_list('WSL_ASSET_FILES_REQUIRED.txt')
sources = read_list('WSL_ASSET_FILES_SMILES_SOURCES.txt')
small = [s for s in sources[:2] if (project/s).is_file()]
if not small and not include_large_smiles_fallback:
    raise SystemExit('缺少小型SMILES来源：请检查清单；不能默认打包250k库。')
selected += small
if include_large_smiles_fallback:
    selected += sources[2:]
if include_optional_audit:
    selected += read_list('WSL_ASSET_FILES_OPTIONAL_AUDIT.txt')
selected = list(dict.fromkeys(selected))

blocked_names = {'.git', '.env', '__pycache__', '.cache', '.pytest_cache', 'node_modules'}
files = []
missing = []
for rel in selected:
    parts = PurePosixPath(rel).parts
    if not parts or PurePosixPath(rel).is_absolute() or '..' in parts:
        raise SystemExit('非法相对路径: '+rel)
    if any(p.startswith('.') or p in blocked_names for p in parts) or Path(rel).suffix.lower() in {'.key','.pem','.pyc'}:
        raise SystemExit('拒绝敏感/隐藏/缓存路径: '+rel)
    path = project/rel
    if any((project.joinpath(*parts[:i])).is_symlink() for i in range(1,len(parts)+1)):
        raise SystemExit('拒绝符号链接: '+rel)
    if not path.is_file():
        missing.append(rel)
        continue
    if not path.resolve().is_relative_to(project):
        raise SystemExit('路径逃逸: '+rel)
    files.append((rel,path))
if missing:
    raise SystemExit('必需/显式选择的文件缺失，未打包:\n'+'\n'.join(missing))

# 环境版本导出只用各环境的Python读取metadata，不import模型框架。
probe = """import sys,json,platform,importlib.metadata as m
names=['chemprop','torch','lightning','pytorch-lightning','rdkit','numpy','scipy','pandas','scikit-learn','joblib','requests']
v={}
for name in names:
 try:v[name]=m.version(name)
 except m.PackageNotFoundError:v[name]='not-installed'
print(json.dumps({'python':sys.version,'platform':platform.platform(),'packages':v}))
"""
runtime = {}
for env_name in ['admet_ai','rdkit_aidd']:
    python = Path.home()/'miniforge3/envs'/env_name/'bin/python'
    if not python.is_file():
        raise SystemExit('环境Python不可用，未打包: '+str(python))
    result = subprocess.run([str(python),'-c',probe],capture_output=True,text=True,check=True)
    runtime[env_name] = json.loads(result.stdout)
chemprop = Path.home()/'miniforge3/envs/admet_ai/bin/chemprop'
version = subprocess.run([str(chemprop),'--version'],capture_output=True,text=True,check=True)
runtime['chemprop_version_stdout'] = version.stdout.strip()

# 不导出原进程环境、代理、token、.env或带索引URL的pip配置。
staging = Path(tempfile.mkdtemp(prefix='egfr-phase0-transfer-',dir='/tmp'))
meta = staging/'transfer-metadata'
meta.mkdir()
(meta/'runtime-versions.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
records = []
for rel,path in files:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block)
    records.append({'relative_path':rel,'size_bytes':path.stat().st_size,'sha256':digest.hexdigest()})
(meta/'asset-hashes.json').write_text(json.dumps(records,indent=2))
(meta/'selected-files.txt').write_text('\n'.join(selected)+'\n')
# 用AST只读枚举5份原研究脚本import；不执行它们，不能代替后续完整依赖审查。
import ast
imports={}
for rel,path in files:
    if rel.startswith('scripts/') and path.suffix=='.py':
        tree=ast.parse(path.read_text(encoding='utf-8-sig'),filename=rel)
        imports[rel]=[ast.unparse(node) for node in ast.walk(tree) if isinstance(node,(ast.Import,ast.ImportFrom))]
(meta/'research-script-imports.json').write_text(json.dumps(imports,ensure_ascii=False,indent=2))

archive=staging/'EGFR_PHASE0_WSL_ASSETS.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for rel,path in files:
        tar.add(path,arcname='project/'+rel,recursive=False)
    for path in sorted(meta.iterdir()):
        tar.add(path,arcname='transfer-metadata/'+path.name,recursive=False)
# 校验实际打包的每一文件，防止读取过程中发生变化。
with tarfile.open(archive,'r:gz') as tar:
    for record in records:
        stream=tar.extractfile('project/'+record['relative_path'])
        digest=hashlib.sha256()
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block)
        if digest.hexdigest()!=record['sha256']:
            raise SystemExit('资产在打包时变化，禁止交接该包: '+record['relative_path'])
digest=hashlib.sha256()
with archive.open('rb') as stream:
    for block in iter(lambda:stream.read(1024*1024),b''):
        digest.update(block)
(archive.with_suffix(archive.suffix+'.sha256')).write_text(digest.hexdigest()+'  '+archive.name+'\n')
print('包:',archive)
print('摘要:',archive.with_suffix(archive.suffix+'.sha256'))
print('请核对资产内容及来源后再交接；这不是推理或Phase0验收通过。')
PY
```

打包命令在本轮Codex中未对WSL执行。它不会安装运行时、导出Ollama缓存、运行训练或为缺失文件造内容。若小型SMILES表只覆盖部分候选，即便包生成成功也不意味着研究回归可通过；接收后核对覆盖，再按需请求第二来源。可选表里任一显式选中的缺失文件会使打包停止，不会静默跳过。

`transfer-metadata/runtime-versions.json`、`asset-hashes.json`、`selected-files.txt`和`research-script-imports.json`均是此命令在临时交接目录新生成的metadata；大小与SHA需WSL执行后测量。前者支持真实推理运行时重建，后两者支持传输/依赖核验，均不直接作为pytest夹具，也不是模型科学有效性的证明。

## 接收时的边界与停止点

收到包后先列目录、比较WSL原摘要、隔离staging恢复可恢复文件，再审查源码版本与研究夹具配对；不直接覆盖已有本地工作、不修改生产排名/结论。仅在获得继续指令并恢复资产后再运行推理与回归。当前不执行Phase1指标审计、不生成新模型、不修改源码或Git忽略规则。

本轮结束后等待用户交接资产。Phase0仍未验收，Phase1–5规划保持原样。
